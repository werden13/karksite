-- KARK Website Data Validation and Constraints for MySQL
-- This file contains validation rules, constraints, and data integrity checks
-- Optimized for cPanel MySQL hosting

-- =====================================================
-- DATA VALIDATION FUNCTIONS
-- =====================================================

DELIMITER //

-- Validate email format
CREATE FUNCTION IsValidEmail(email VARCHAR(255))
RETURNS BOOLEAN
READS SQL DATA
DETERMINISTIC
BEGIN
    RETURN email REGEXP '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$';
END //

-- Validate phone number (basic format)
CREATE FUNCTION IsValidPhone(phone VARCHAR(50))
RETURNS BOOLEAN
READS SQL DATA
DETERMINISTIC
BEGIN
    -- Allow various phone formats: +90 555 123 4567, (555) 123-4567, etc.
    RETURN phone REGEXP '^[\\+]?[0-9\\s\\(\\)\\-\\.]{10,}$';
END //

-- Check if user has permission
CREATE FUNCTION UserHasPermission(user_id INT, permission_name VARCHAR(100))
RETURNS BOOLEAN
READS SQL DATA
DETERMINISTIC
BEGIN
    DECLARE permission_count INT DEFAULT 0;
    
    SELECT COUNT(*) INTO permission_count
    FROM kark_users 
    WHERE id = user_id 
        AND role != 'banned'
        AND (
            role = 'major_admin' 
            OR JSON_CONTAINS(permissions, JSON_QUOTE(permission_name))
            OR JSON_CONTAINS(permissions, JSON_QUOTE('all'))
        );
    
    RETURN permission_count > 0;
END //

DELIMITER ;

-- =====================================================
-- CHECK CONSTRAINTS (MySQL 8.0+)
-- =====================================================

-- Note: For older MySQL versions, these will be ignored
-- For cPanel with older MySQL, validation should be done in application code

-- Users table constraints
ALTER TABLE kark_users 
ADD CONSTRAINT chk_users_email CHECK (IsValidEmail(email)),
ADD CONSTRAINT chk_users_username_length CHECK (CHAR_LENGTH(username) >= 3),
ADD CONSTRAINT chk_users_password_length CHECK (CHAR_LENGTH(password) >= 8);

-- Events table constraints
ALTER TABLE kark_events
ADD CONSTRAINT chk_events_date_future CHECK (date >= CURDATE()),
ADD CONSTRAINT chk_events_title_length CHECK (CHAR_LENGTH(title) >= 3);

-- Contact messages constraints
ALTER TABLE kark_contact_messages
ADD CONSTRAINT chk_contact_email CHECK (IsValidEmail(email)),
ADD CONSTRAINT chk_contact_phone CHECK (phone IS NULL OR IsValidPhone(phone)),
ADD CONSTRAINT chk_contact_message_length CHECK (CHAR_LENGTH(message) >= 10);

-- Settings constraints
ALTER TABLE kark_settings
ADD CONSTRAINT chk_settings_key_format CHECK (key REGEXP '^[a-z_]+\\.[a-z_]+$');

-- Donation campaigns constraints
ALTER TABLE kark_donation_campaigns
ADD CONSTRAINT chk_campaign_amounts CHECK (goal_amount IS NULL OR goal_amount > 0),
ADD CONSTRAINT chk_campaign_raised CHECK (raised_amount >= 0),
ADD CONSTRAINT chk_campaign_dates CHECK (end_date IS NULL OR start_date IS NULL OR end_date >= start_date);

-- =====================================================
-- TRIGGERS FOR DATA VALIDATION
-- =====================================================

DELIMITER //

-- Validate user data before insert/update
CREATE TRIGGER tr_validate_user_before_insert
    BEFORE INSERT ON kark_users
    FOR EACH ROW
BEGIN
    -- Ensure email is lowercase
    SET NEW.email = LOWER(NEW.email);
    
    -- Validate email format (for older MySQL versions)
    IF NOT IsValidEmail(NEW.email) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid email format';
    END IF;
    
    -- Ensure username is lowercase and alphanumeric
    SET NEW.username = LOWER(NEW.username);
    IF NEW.username NOT REGEXP '^[a-z0-9_]{3,}$' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Username must be at least 3 characters, lowercase alphanumeric with underscores only';
    END IF;
    
    -- Validate permissions JSON
    IF NEW.permissions IS NOT NULL AND NOT JSON_VALID(NEW.permissions) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid permissions JSON format';
    END IF;
END //

CREATE TRIGGER tr_validate_user_before_update
    BEFORE UPDATE ON kark_users
    FOR EACH ROW
BEGIN
    -- Ensure email is lowercase
    SET NEW.email = LOWER(NEW.email);
    
    -- Validate email format
    IF NOT IsValidEmail(NEW.email) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid email format';
    END IF;
    
    -- Prevent username changes (optional)
    IF NEW.username != OLD.username THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Username cannot be changed';
    END IF;
    
    -- Validate permissions JSON
    IF NEW.permissions IS NOT NULL AND NOT JSON_VALID(NEW.permissions) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid permissions JSON format';
    END IF;
    
    -- Prevent last major_admin from being deleted/banned
    IF OLD.role = 'major_admin' AND NEW.role != 'major_admin' THEN
        IF (SELECT COUNT(*) FROM kark_users WHERE role = 'major_admin' AND id != NEW.id) = 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot remove the last major admin';
        END IF;
    END IF;
END //

-- Validate contact messages
CREATE TRIGGER tr_validate_contact_before_insert
    BEFORE INSERT ON kark_contact_messages
    FOR EACH ROW
BEGIN
    -- Ensure email is lowercase
    SET NEW.email = LOWER(NEW.email);
    
    -- Validate email
    IF NOT IsValidEmail(NEW.email) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid email format';
    END IF;
    
    -- Validate phone if provided
    IF NEW.phone IS NOT NULL AND NOT IsValidPhone(NEW.phone) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid phone number format';
    END IF;
    
    -- Prevent spam (same email, same subject within 5 minutes)
    IF EXISTS (
        SELECT 1 FROM kark_contact_messages 
        WHERE email = NEW.email 
            AND subject = NEW.subject 
            AND created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
    ) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Duplicate message detected. Please wait before sending another message.';
    END IF;
END //

-- Validate events
CREATE TRIGGER tr_validate_event_before_insert
    BEFORE INSERT ON kark_events
    FOR EACH ROW
BEGIN
    -- Ensure title is properly formatted
    SET NEW.title = TRIM(NEW.title);
    
    -- Validate title length
    IF CHAR_LENGTH(NEW.title) < 3 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Event title must be at least 3 characters long';
    END IF;
    
    -- Validate date is not in the past (optional)
    IF NEW.date < NOW() THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Event date cannot be in the past';
    END IF;
END //

-- Validate settings
CREATE TRIGGER tr_validate_setting_before_insert
    BEFORE INSERT ON kark_settings
    FOR EACH ROW
BEGIN
    -- Ensure key follows naming convention
    IF NEW.key NOT REGEXP '^[a-z_]+\\.[a-z_]+$' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Setting key must follow format: category.setting_name (lowercase with underscores)';
    END IF;
    
    -- Validate JSON type settings
    IF NEW.type = 'json' AND NEW.value IS NOT NULL AND NOT JSON_VALID(NEW.value) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid JSON format for setting value';
    END IF;
    
    -- Validate boolean type settings
    IF NEW.type = 'boolean' AND NEW.value NOT IN ('true', 'false', '1', '0') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Boolean setting must be true, false, 1, or 0';
    END IF;
END //

DELIMITER ;

-- =====================================================
-- DATA INTEGRITY CHECKS
-- =====================================================

-- Procedure to check data integrity
DELIMITER //

CREATE PROCEDURE CheckDataIntegrity()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE error_count INT DEFAULT 0;
    
    -- Check for orphaned records
    SELECT COUNT(*) INTO @orphaned_events FROM kark_events e 
    LEFT JOIN kark_users u ON e.created_by = u.id 
    WHERE e.created_by IS NOT NULL AND u.id IS NULL;
    
    SELECT COUNT(*) INTO @orphaned_media FROM kark_media_items m 
    LEFT JOIN kark_users u ON m.created_by = u.id 
    WHERE m.created_by IS NOT NULL AND u.id IS NULL;
    
    SELECT COUNT(*) INTO @orphaned_activities FROM kark_activities a 
    LEFT JOIN kark_users u ON a.created_by = u.id 
    WHERE a.created_by IS NOT NULL AND u.id IS NULL;
    
    -- Check for invalid emails
    SELECT COUNT(*) INTO @invalid_emails FROM kark_users 
    WHERE NOT IsValidEmail(email);
    
    SELECT COUNT(*) INTO @invalid_contact_emails FROM kark_contact_messages 
    WHERE NOT IsValidEmail(email);
    
    -- Check for empty required fields
    SELECT COUNT(*) INTO @empty_usernames FROM kark_users 
    WHERE username IS NULL OR TRIM(username) = '';
    
    SELECT COUNT(*) INTO @empty_event_titles FROM kark_events 
    WHERE title IS NULL OR TRIM(title) = '';
    
    -- Report results
    SELECT 
        'Data Integrity Check Results' as Report,
        @orphaned_events as OrphanedEvents,
        @orphaned_media as OrphanedMedia,
        @orphaned_activities as OrphanedActivities,
        @invalid_emails as InvalidUserEmails,
        @invalid_contact_emails as InvalidContactEmails,
        @empty_usernames as EmptyUsernames,
        @empty_event_titles as EmptyEventTitles;
    
    -- Set error count
    SET error_count = @orphaned_events + @orphaned_media + @orphaned_activities + 
                     @invalid_emails + @invalid_contact_emails + @empty_usernames + @empty_event_titles;
    
    IF error_count > 0 THEN
        SELECT CONCAT('Found ', error_count, ' data integrity issues!') as Warning;
    ELSE
        SELECT 'All data integrity checks passed!' as Success;
    END IF;
END //

DELIMITER ;

-- =====================================================
-- CLEANUP PROCEDURES
-- =====================================================

DELIMITER //

-- Clean up old data
CREATE PROCEDURE CleanupOldData()
BEGIN
    -- Archive old contact messages
    UPDATE kark_contact_messages 
    SET status = 'archived' 
    WHERE status = 'read' AND created_at < DATE_SUB(NOW(), INTERVAL 1 YEAR);
    
    -- Clean old admin logs (keep last 6 months)
    DELETE FROM kark_admin_logs 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 6 MONTH);
    
    -- Clean old sessions
    DELETE FROM kark_sessions 
    WHERE expires < UNIX_TIMESTAMP();
    
    SELECT 'Cleanup completed successfully' as Result;
END //

-- Fix orphaned records
CREATE PROCEDURE FixOrphanedRecords()
BEGIN
    -- Set orphaned events to null creator
    UPDATE kark_events e 
    LEFT JOIN kark_users u ON e.created_by = u.id 
    SET e.created_by = NULL 
    WHERE e.created_by IS NOT NULL AND u.id IS NULL;
    
    -- Set orphaned media to null creator
    UPDATE kark_media_items m 
    LEFT JOIN kark_users u ON m.created_by = u.id 
    SET m.created_by = NULL 
    WHERE m.created_by IS NOT NULL AND u.id IS NULL;
    
    -- Set orphaned activities to null creator
    UPDATE kark_activities a 
    LEFT JOIN kark_users u ON a.created_by = u.id 
    SET a.created_by = NULL 
    WHERE a.created_by IS NOT NULL AND u.id IS NULL;
    
    SELECT 'Orphaned records fixed successfully' as Result;
END //

DELIMITER ;

-- =====================================================
-- USAGE EXAMPLES
-- =====================================================

-- Run data integrity check:
-- CALL CheckDataIntegrity();

-- Clean up old data:
-- CALL CleanupOldData();

-- Fix orphaned records:
-- CALL FixOrphanedRecords();

-- Check if user has permission:
-- SELECT UserHasPermission(1, 'manage_users') as HasPermission;

-- Validate email:
-- SELECT IsValidEmail('test@example.com') as IsValid;

-- END OF FILE