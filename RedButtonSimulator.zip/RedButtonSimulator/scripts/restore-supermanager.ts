import { db } from "../server/db";
import { users } from "../shared/schema";

async function restoreSupermanager() {
  try {
    // Check if supermanager already exists
    const existingUser = await db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, "supermanager")
    });

    if (existingUser) {
      console.log("Supermanager account already exists");
      return;
    }

    // Create the supermanager account
    const [user] = await db.insert(users).values({
      username: "supermanager",
      password: "590096bce2fcbd62841a4bd8405211fceb42a4426e25c41a7f2fa55b59addcaa04528cfc26adf3835a3562ea304fe0147a89f8623592f6e38b6fc1470f30bc0e.b4a1569aaadf3c03e03b4c64c9853b88",
      firstName: "Super",
      lastName: "Manager",
      email: "super@example.com",
      isAdmin: true,
      role: "major_admin",
      permissions: ["manage_users", "manage_events", "manage_media", "manage_team", "manage_donations", "manage_settings", "manage_sliders", "manage_admins"],
    }).returning();

    console.log("Supermanager account restored:", user);
  } catch (error) {
    console.error("Error restoring supermanager account:", error);
  } finally {
    // Close the database connection
    await db.end();
  }
}

restoreSupermanager();