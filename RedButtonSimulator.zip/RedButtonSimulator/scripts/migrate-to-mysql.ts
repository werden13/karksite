#!/usr/bin/env tsx

/**
 * MySQL Migration Script for KARK Website
 * This script migrates data from JSON storage to MySQL database
 */

import { createConnection } from "mysql2/promise";
import * as fs from "fs";
import * as path from "path";
import { drizzle } from "drizzle-orm/mysql2";
import * as schema   from "../shared/schema";

// JSON data paths
const DATA_DIR = path.join(process.cwd(), "data");

const JSON_FILES = {
  users: "users.json",
  events: "events.json", 
  media: "media.json",
  albums: "albums.json",
  team: "team.json",
  contact: "contact.json",
  settings: "settings.json",
  donation_methods: "donation_methods.json",
  donation_campaigns: "donation_campaigns.json",
  hero_sliders: "hero_sliders.json",
  archive_items: "archive_items.json"
};

async function loadJSONData(filename: string) {
  const filepath = path.join(DATA_DIR, filename);
  if (!fs.existsSync(filepath)) {
    console.log(`⚠️  File not found: ${filename}`);
    return [];
  }
  
  try {
    const data = JSON.parse(fs.readFileSync(filepath, "utf-8"));
    return Array.isArray(data) ? data : [];
  } catch (error) {
    console.error(`❌ Error loading ${filename}:`, error);
    return [];
  }
}

async function migrateToMySQL() {
  if (!process.env.DATABASE_URL) {
    console.error("❌ DATABASE_URL environment variable is required");
    process.exit(1);
  }

  console.log("🚀 Starting MySQL migration for KARK website...");

  try {
    // Create MySQL connection
    const connection = await createConnection({
      uri: process.env.DATABASE_URL,
      ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    });

    const db = drizzle(connection, { schema, mode: 'default' });

    console.log("✅ Connected to MySQL database");

    // Load and migrate users
    console.log("📥 Migrating users...");
    const users = await loadJSONData(JSON_FILES.users);
    if (users.length > 0) {
      for (const user of users) {
        try {
          await db.insert(schema.users).values({
            username: user.username,
            password: user.password,
            firstName: user.firstName || user.first_name,
            lastName: user.lastName || user.last_name,
            email: user.email,
            isAdmin: user.isAdmin || false,
            role: user.role || 'user',
            permissions: user.permissions || []
          });
        } catch (error) {
          console.log(`⚠️  User ${user.username} already exists or error:`, error.message);
        }
      }
      console.log(`✅ Migrated ${users.length} users`);
    }

    // Load and migrate events
    console.log("📥 Migrating events...");
    const events = await loadJSONData(JSON_FILES.events);
    if (events.length > 0) {
      for (const event of events) {
        try {
          await db.insert(schema.events).values({
            title: event.title,
            description: event.description,
            date: new Date(event.date),
            location: event.location,
            category: event.category,
            imagePath: event.imagePath || event.image_path,
            createdBy: event.createdBy || event.created_by || 1
          });
        } catch (error) {
          console.log(`⚠️  Event ${event.title} error:`, error.message);
        }
      }
      console.log(`✅ Migrated ${events.length} events`);
    }

    // Load and migrate albums
    console.log("📥 Migrating albums...");
    const albums = await loadJSONData(JSON_FILES.albums);
    if (albums.length > 0) {
      for (const album of albums) {
        try {
          await db.insert(schema.albums).values({
            title: album.title,
            description: album.description,
            coverImageId: album.coverImageId || album.cover_image_id,
            eventId: album.eventId || album.event_id,
            createdBy: album.createdBy || album.created_by || 1
          });
        } catch (error) {
          console.log(`⚠️  Album ${album.title} error:`, error.message);
        }
      }
      console.log(`✅ Migrated ${albums.length} albums`);
    }

    // Load and migrate media
    console.log("📥 Migrating media items...");
    const media = await loadJSONData(JSON_FILES.media);
    if (media.length > 0) {
      for (const item of media) {
        try {
          await db.insert(schema.mediaItems).values({
            title: item.title,
            description: item.description,
            mediaType: item.mediaType || item.media_type || 'photo',
            filePath: item.filePath || item.file_path,
            thumbnailPath: item.thumbnailPath || item.thumbnail_path,
            eventId: item.eventId || item.event_id,
            albumId: item.albumId || item.album_id,
            createdBy: item.createdBy || item.created_by || 1
          });
        } catch (error) {
          console.log(`⚠️  Media ${item.title} error:`, error.message);
        }
      }
      console.log(`✅ Migrated ${media.length} media items`);
    }

    // Load and migrate team members
    console.log("📥 Migrating team members...");
    const team = await loadJSONData(JSON_FILES.team);
    if (team.length > 0) {
      for (const member of team) {
        try {
          await db.insert(schema.teamMembers).values({
            firstName: member.firstName || member.first_name,
            lastName: member.lastName || member.last_name,
            position: member.position,
            imagePath: member.imagePath || member.image_path,
            email: member.email,
            skills: member.skills || [],
            createdBy: member.createdBy || member.created_by || 1
          });
        } catch (error) {
          console.log(`⚠️  Team member ${member.firstName} ${member.lastName} error:`, error.message);
        }
      }
      console.log(`✅ Migrated ${team.length} team members`);
    }

    // Load and migrate contact messages
    console.log("📥 Migrating contact messages...");
    const contacts = await loadJSONData(JSON_FILES.contact);
    if (contacts.length > 0) {
      for (const contact of contacts) {
        try {
          await db.insert(schema.contactMessages).values({
            name: contact.name,
            email: contact.email,
            subject: contact.subject,
            message: contact.message,
            isRead: contact.isRead || contact.is_read || false
          });
        } catch (error) {
          console.log(`⚠️  Contact message error:`, error.message);
        }
      }
      console.log(`✅ Migrated ${contacts.length} contact messages`);
    }

    // Load and migrate settings
    console.log("📥 Migrating settings...");
    const settings = await loadJSONData(JSON_FILES.settings);
    if (settings.length > 0) {
      for (const setting of settings) {
        try {
          await db.insert(schema.settings).values({
            key: setting.key,
            value: setting.value,
            updatedBy: setting.updatedBy || setting.updated_by || 1
          });
        } catch (error) {
          console.log(`⚠️  Setting ${setting.key} error:`, error.message);
        }
      }
      console.log(`✅ Migrated ${settings.length} settings`);
    }

    // Load and migrate donation methods
    console.log("📥 Migrating donation methods...");
    const donationMethods = await loadJSONData(JSON_FILES.donation_methods);
    if (donationMethods.length > 0) {
      for (const method of donationMethods) {
        try {
          await db.insert(schema.donationMethods).values({
            bankName: method.bankName || method.bank_name,
            accountName: method.accountName || method.account_name,
            iban: method.iban,
            branchCode: method.branchCode || method.branch_code,
            accountNumber: method.accountNumber || method.account_number,
            currency: method.currency || 'TRY',
            description: method.description,
            logoUrl: method.logoUrl || method.logo_url,
            createdBy: method.createdBy || method.created_by || 1,
            updatedBy: method.updatedBy || method.updated_by || 1
          });
        } catch (error) {
          console.log(`⚠️  Donation method ${method.bankName} error:`, error.message);
        }
      }
      console.log(`✅ Migrated ${donationMethods.length} donation methods`);
    }

    // Load and migrate donation campaigns
    console.log("📥 Migrating donation campaigns...");
    const campaigns = await loadJSONData(JSON_FILES.donation_campaigns);
    if (campaigns.length > 0) {
      for (const campaign of campaigns) {
        try {
          await db.insert(schema.donationCampaigns).values({
            title: campaign.title,
            description: campaign.description,
            targetAmount: campaign.targetAmount || campaign.target_amount,
            currentAmount: campaign.currentAmount || campaign.current_amount || "0",
            endDate: campaign.endDate ? new Date(campaign.endDate) : null,
            imageUrl: campaign.imageUrl || campaign.image_url,
            isActive: campaign.isActive !== undefined ? campaign.isActive : true,
            createdBy: campaign.createdBy || campaign.created_by || 1,
            updatedBy: campaign.updatedBy || campaign.updated_by || 1
          });
        } catch (error) {
          console.log(`⚠️  Campaign ${campaign.title} error:`, error.message);
        }
      }
      console.log(`✅ Migrated ${campaigns.length} donation campaigns`);
    }

    // Load and migrate hero sliders
    console.log("📥 Migrating hero sliders...");
    const heroSliders = await loadJSONData(JSON_FILES.hero_sliders);
    if (heroSliders.length > 0) {
      for (const slider of heroSliders) {
        try {
          await db.insert(schema.heroSliders).values({
            title: slider.title,
            description: slider.description,
            buttonText: slider.buttonText || slider.button_text,
            buttonLink: slider.buttonLink || slider.button_link,
            imageUrl: slider.imageUrl || slider.image_url,
            order: slider.order || slider.display_order || 0,
            isActive: slider.isActive !== undefined ? slider.isActive : true,
            createdBy: slider.createdBy || slider.created_by || 1,
            updatedBy: slider.updatedBy || slider.updated_by || 1
          });
        } catch (error) {
          console.log(`⚠️  Hero slider ${slider.title} error:`, error.message);
        }
      }
      console.log(`✅ Migrated ${heroSliders.length} hero sliders`);
    }

    // Load and migrate archive items
    console.log("📥 Migrating archive items...");
    const archiveItems = await loadJSONData(JSON_FILES.archive_items);
    if (archiveItems.length > 0) {
      for (const item of archiveItems) {
        try {
          await db.insert(schema.archiveItems).values({
            title: item.title,
            description: item.description,
            content: item.content,
            itemType: item.itemType || item.item_type || 'operation',
            date: new Date(item.date),
            location: item.location,
            participants: item.participants,
            outcome: item.outcome,
            imageUrl: item.imageUrl || item.image_url,
            videoUrl: item.videoUrl || item.video_url,
            documentUrl: item.documentUrl || item.document_url,
            tags: item.tags || [],
            isPublished: item.isPublished !== undefined ? item.isPublished : false,
            isFeatured: item.isFeatured !== undefined ? item.isFeatured : false,
            viewCount: item.viewCount || item.view_count || 0,
            createdBy: item.createdBy || item.created_by || 1,
            updatedBy: item.updatedBy || item.updated_by || 1
          });
        } catch (error) {
          console.log(`⚠️  Archive item ${item.title} error:`, error.message);
        }
      }
      console.log(`✅ Migrated ${archiveItems.length} archive items`);
    }

    await connection.end();
    console.log("🎉 MySQL migration completed successfully!");
    console.log("📋 Next steps:");
    console.log("1. Update your hosting platform to use MySQL");
    console.log("2. Set DATABASE_URL environment variable");
    console.log("3. Update server/db.ts to use MySQL connection");
    console.log("4. Deploy your application");

  } catch (error) {
    console.error("❌ Migration failed:", error);
    process.exit(1);
  }
}

// Run migration
migrateToMySQL().catch(console.error);