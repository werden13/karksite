import { Client } from 'pg';
import crypto from 'crypto';
import { promisify } from 'util';

const scryptAsync = promisify(crypto.scrypt);

async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const buf = await scryptAsync(password, salt, 64);
  return `${buf.toString('hex')}.${salt}`;
}

async function main() {
  try {
    // Create a PostgreSQL client
    const client = new Client({
      connectionString: process.env.DATABASE_URL,
    });
    await client.connect();
    console.log('Connected to PostgreSQL database');

    // Check if users table exists
    const tableCheck = await client.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'users'
      );
    `);

    if (!tableCheck.rows[0].exists) {
      console.error('Users table does not exist. Please run migrations first.');
      await client.end();
      process.exit(1);
    }

    // Hash the admin password
    const adminPassword = await hashPassword('Admin123!');
    
    // Check if admin user already exists
    const adminCheck = await client.query(`
      SELECT * FROM users WHERE username = 'admin';
    `);
    
    if (adminCheck.rows.length > 0) {
      console.log('Admin user already exists, updating...');
      // Update admin user
      await client.query(`
        UPDATE users
        SET 
          password = $1,
          role = 'major_admin',
          is_admin = true,
          permissions = ARRAY['manage_users', 'manage_events', 'manage_media', 'manage_team', 'manage_donations', 'manage_settings', 'manage_sliders', 'manage_admins', 'all']
        WHERE username = 'admin';
      `, [adminPassword]);
      console.log('Admin user updated successfully');
    } else {
      console.log('Creating admin user...');
      // Insert admin user
      await client.query(`
        INSERT INTO users (username, password, first_name, last_name, email, is_admin, role, permissions)
        VALUES ('admin', $1, 'Admin', 'User', 'admin@example.com', true, 'major_admin', 
        ARRAY['manage_users', 'manage_events', 'manage_media', 'manage_team', 'manage_donations', 'manage_settings', 'manage_sliders', 'manage_admins', 'all']);
      `, [adminPassword]);
      console.log('Admin user created successfully');
    }

    // Check if supermanager user already exists
    const superCheck = await client.query(`
      SELECT * FROM users WHERE username = 'supermanager';
    `);
    
    // Hash the supermanager password
    const superPassword = await hashPassword('Admin123!');
    
    if (superCheck.rows.length > 0) {
      console.log('Supermanager user already exists, updating...');
      // Update supermanager user
      await client.query(`
        UPDATE users
        SET 
          password = $1,
          role = 'major_admin',
          is_admin = true,
          permissions = ARRAY['manage_users', 'manage_events', 'manage_media', 'manage_team', 'manage_donations', 'manage_settings', 'manage_sliders', 'manage_admins', 'all']
        WHERE username = 'supermanager';
      `, [superPassword]);
      console.log('Supermanager user updated successfully');
    } else {
      console.log('Creating supermanager user...');
      // Insert supermanager user
      await client.query(`
        INSERT INTO users (username, password, first_name, last_name, email, is_admin, role, permissions)
        VALUES ('supermanager', $1, 'Super', 'Manager', 'super@example.com', true, 'major_admin', 
        ARRAY['manage_users', 'manage_events', 'manage_media', 'manage_team', 'manage_donations', 'manage_settings', 'manage_sliders', 'manage_admins', 'all']);
      `, [superPassword]);
      console.log('Supermanager user created successfully');
    }

    // Close the database connection
    await client.end();
    console.log('Database connection closed');
    
    console.log('\nAdmin users have been set up successfully!');
    console.log('You can now log in with:');
    console.log('Username: admin or supermanager');
    console.log('Password: Admin123!');
    
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

main();