# phpMyAdmin Import Instructions

## Files Created:

1. **export_for_phpmyadmin.sql** - Creates all database tables with proper structure
2. **data_export_for_phpmyadmin.sql** - Contains all your existing data

## Step-by-Step Import Process:

### 1. Prepare Your Database
- Log into your cPanel
- Open phpMyAdmin
- Create a new database (e.g., `archive_system`)
- Select the new database

### 2. Import Table Structure
- Click on the "Import" tab
- Click "Choose File" and select `export_for_phpmyadmin.sql`
- Leave all settings as default
- Click "Go" to create all tables

### 3. Import Your Data
- Stay in the same database
- Click "Import" tab again
- Click "Choose File" and select `data_export_for_phpmyadmin.sql`
- Click "Go" to import all your data

### 4. Update Database Configuration

Create a `.env` file in your project root with your database details:

```
DB_HOST=localhost
DB_USER=your_cpanel_username
DB_PASSWORD=your_database_password
DB_NAME=your_database_name
DB_PORT=3306
```

### 5. Update User Passwords

For security, update the admin passwords after import:

```sql
-- Update supermanager password (use your actual password hash)
UPDATE users SET password = '$2a$10$YourNewHashedPassword' WHERE username = 'supermanager';
```

### 6. Test Connection

Your application will automatically use MySQL when the database environment variables are set.

## Important Notes:

- The export includes all your current data from JSON files
- User passwords are exported as-is, so make sure to update them
- The system will automatically detect and use MySQL when configured
- All your security logs and admin actions are preserved

## Troubleshooting:

If you encounter errors during import:
1. Check that your database character set is `utf8mb4`
2. Ensure you have sufficient privileges
3. Import tables first, then data
4. Check for any foreign key constraints

Your website is ready to use MySQL database through phpMyAdmin!