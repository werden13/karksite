-- KARK Website Data Validation and Verification Script
-- Version: 1.0
-- Date: 2025-01-24
-- Description: Validates all tables, data, and relationships

-- =====================================================
-- STEP 1: DATABASE AND TABLE VALIDATION
-- =====================================================

-- Check if database exists and we're using it
SELECT DATABASE() AS current_database;

-- List all tables with their status
SELECT 
    'Table Validation Report' AS report_type,
    COUNT(*) AS total_tables_found
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = DATABASE();

-- Detailed table check
SELECT 
    CASE 
        WHEN t.TABLE_NAME IS NOT NULL THEN '✓ EXISTS'
        ELSE '✗ MISSING'
    END AS status,
    required.table_name,
    COALESCE(t.TABLE_ROWS, 0) AS row_count,
    CASE 
        WHEN t.TABLE_NAME IS NULL THEN 'Table needs to be created'
        WHEN t.TABLE_ROWS = 0 THEN 'Table exists but is empty'
        ELSE 'Table exists with data'
    END AS notes
FROM (
    SELECT 'users' AS table_name
    UNION ALL SELECT 'events'
    UNION ALL SELECT 'activities'
    UNION ALL SELECT 'media_items'
    UNION ALL SELECT 'albums'
    UNION ALL SELECT 'team_members'
    UNION ALL SELECT 'contact_messages'
    UNION ALL SELECT 'settings'
    UNION ALL SELECT 'donation_methods'
    UNION ALL SELECT 'donation_campaigns'
    UNION ALL SELECT 'archive_items'
    UNION ALL SELECT 'archive_media'
    UNION ALL SELECT 'hero_sliders'
    UNION ALL SELECT 'admin_logs'
    UNION ALL SELECT 'sessions'
) AS required
LEFT JOIN information_schema.TABLES t 
    ON t.TABLE_SCHEMA = DATABASE() 
    AND t.TABLE_NAME = required.table_name
ORDER BY 
    CASE WHEN t.TABLE_NAME IS NULL THEN 0 ELSE 1 END,
    required.table_name;

-- =====================================================
-- STEP 2: COLUMN VALIDATION
-- =====================================================

-- Check critical columns exist
SELECT 
    'Column Validation' AS check_type,
    table_name,
    column_name,
    CASE 
        WHEN COUNT(*) > 0 THEN '✓ EXISTS'
        ELSE '✗ MISSING'
    END AS status
FROM (
    -- Critical columns that must exist
    SELECT 'users' AS table_name, 'username' AS column_name
    UNION ALL SELECT 'users', 'password'
    UNION ALL SELECT 'users', 'role'
    UNION ALL SELECT 'events', 'title'
    UNION ALL SELECT 'events', 'category'
    UNION ALL SELECT 'archive_items', 'item_type'
    UNION ALL SELECT 'archive_items', 'is_published'
    UNION ALL SELECT 'settings', 'key'
    UNION ALL SELECT 'settings', 'value'
    UNION ALL SELECT 'admin_logs', 'user_id'
    UNION ALL SELECT 'admin_logs', 'action'
) AS required
LEFT JOIN information_schema.COLUMNS c
    ON c.TABLE_SCHEMA = DATABASE()
    AND c.TABLE_NAME = required.table_name
    AND c.COLUMN_NAME = required.column_name
GROUP BY table_name, column_name
ORDER BY table_name, column_name;

-- =====================================================
-- STEP 3: FOREIGN KEY VALIDATION
-- =====================================================

-- Check all foreign keys are properly set up
SELECT 
    'Foreign Key Check' AS check_type,
    CONCAT(kcu.TABLE_NAME, '.', kcu.COLUMN_NAME) AS from_column,
    CONCAT(' -> ', kcu.REFERENCED_TABLE_NAME, '.', kcu.REFERENCED_COLUMN_NAME) AS references,
    CASE 
        WHEN kcu.REFERENCED_TABLE_NAME IS NOT NULL THEN '✓ OK'
        ELSE '✗ MISSING'
    END AS status
FROM information_schema.KEY_COLUMN_USAGE kcu
WHERE kcu.TABLE_SCHEMA = DATABASE()
    AND kcu.REFERENCED_TABLE_NAME IS NOT NULL
ORDER BY kcu.TABLE_NAME, kcu.COLUMN_NAME;

-- =====================================================
-- STEP 4: DATA INTEGRITY CHECKS
-- =====================================================

-- Check for admin users
SELECT 
    'Admin User Check' AS check_type,
    COUNT(*) AS admin_count,
    CASE 
        WHEN COUNT(*) = 0 THEN '✗ NO ADMIN USERS - Create admin user immediately!'
        WHEN COUNT(*) < 2 THEN '⚠ Only one admin user found'
        ELSE '✓ Multiple admin users exist'
    END AS status
FROM users 
WHERE role IN ('major_admin', 'admin');

-- Check for essential settings
SELECT 
    'Essential Settings Check' AS check_type,
    required_key,
    CASE 
        WHEN s.value IS NOT NULL THEN '✓ SET'
        ELSE '✗ MISSING'
    END AS status,
    COALESCE(s.value, 'Not configured') AS current_value
FROM (
    SELECT 'general.site_name' AS required_key
    UNION ALL SELECT 'general.footer_text'
    UNION ALL SELECT 'general.contact_email'
    UNION ALL SELECT 'stats.visitor_count'
) AS required
LEFT JOIN settings s ON s.key = required.required_key
ORDER BY required_key;

-- =====================================================
-- STEP 5: API ENDPOINT DATA AVAILABILITY
-- =====================================================

-- Check data availability for each major API endpoint
SELECT 'API Data Availability Check' AS report_type;

-- Visitor count API
SELECT 
    '/api/visitor-count' AS endpoint,
    CASE 
        WHEN COUNT(*) > 0 THEN '✓ Ready'
        ELSE '✗ No data'
    END AS status,
    COALESCE(MAX(value), '0') AS visitor_count
FROM settings 
WHERE `key` = 'stats.visitor_count';

-- Events API
SELECT 
    '/api/events' AS endpoint,
    CASE 
        WHEN COUNT(*) > 0 THEN '✓ Ready'
        ELSE '⚠ No events'
    END AS status,
    COUNT(*) AS total_events,
    SUM(CASE WHEN date >= NOW() THEN 1 ELSE 0 END) AS upcoming_events
FROM events;

-- Activities API
SELECT 
    '/api/activities' AS endpoint,
    CASE 
        WHEN COUNT(*) > 0 THEN '✓ Ready'
        ELSE '⚠ No activities'
    END AS status,
    COUNT(*) AS total_activities,
    SUM(CASE WHEN is_active = true THEN 1 ELSE 0 END) AS active_activities
FROM activities;

-- Archive API
SELECT 
    '/api/archive' AS endpoint,
    CASE 
        WHEN COUNT(*) > 0 THEN '✓ Ready'
        ELSE '⚠ No archive items'
    END AS status,
    COUNT(*) AS total_items,
    SUM(CASE WHEN is_published = true THEN 1 ELSE 0 END) AS published_items
FROM archive_items;

-- Hero Sliders API
SELECT 
    '/api/hero-sliders' AS endpoint,
    CASE 
        WHEN COUNT(*) > 0 THEN '✓ Ready'
        ELSE '⚠ No sliders'
    END AS status,
    COUNT(*) AS total_sliders,
    SUM(CASE WHEN is_active = true THEN 1 ELSE 0 END) AS active_sliders
FROM hero_sliders;

-- =====================================================
-- STEP 6: MISSING REQUIRED DATA
-- =====================================================

-- Identify what initial data needs to be added
SELECT 'Missing Required Data Report' AS report_type;

-- Check if we need to create admin user
SELECT 
    CASE 
        WHEN COUNT(*) = 0 THEN 'CRITICAL: No admin users exist! Run: INSERT INTO users (username, password, first_name, last_name, email, is_admin, role) VALUES ("admin", "$2b$10$YourHashHere", "Admin", "User", "admin@kark.org", true, "major_admin");'
        ELSE CONCAT('✓ ', COUNT(*), ' admin user(s) exist')
    END AS admin_user_status
FROM users 
WHERE role IN ('major_admin', 'admin');

-- Check if we need hero sliders
SELECT 
    CASE 
        WHEN COUNT(*) = 0 THEN 'WARNING: No hero sliders! Website homepage will be empty.'
        ELSE CONCAT('✓ ', COUNT(*), ' hero slider(s) configured')
    END AS hero_slider_status
FROM hero_sliders 
WHERE is_active = true;

-- Check if we need activities
SELECT 
    CASE 
        WHEN COUNT(*) = 0 THEN 'WARNING: No activities! Homepage will show no activities.'
        ELSE CONCAT('✓ ', COUNT(*), ' activity(ies) configured')
    END AS activities_status
FROM activities 
WHERE is_active = true;

-- =====================================================
-- STEP 7: PERFORMANCE INDICATORS
-- =====================================================

SELECT 'Performance Check' AS report_type;

-- Check index usage
SELECT 
    'Index Coverage' AS metric,
    COUNT(DISTINCT INDEX_NAME) AS total_indexes,
    COUNT(DISTINCT TABLE_NAME) AS tables_with_indexes
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
    AND INDEX_NAME != 'PRIMARY';

-- Check table sizes
SELECT 
    'Largest Tables' AS metric,
    TABLE_NAME,
    TABLE_ROWS AS estimated_rows,
    ROUND(((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024), 2) AS size_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_ROWS > 0
ORDER BY DATA_LENGTH + INDEX_LENGTH DESC
LIMIT 5;

-- =====================================================
-- STEP 8: SECURITY VALIDATION
-- =====================================================

SELECT 'Security Check' AS report_type;

-- Check password hash lengths (bcrypt should be 60 chars)
SELECT 
    'Password Security' AS check_type,
    COUNT(*) AS total_users,
    SUM(CASE WHEN LENGTH(password) >= 60 THEN 1 ELSE 0 END) AS secure_passwords,
    SUM(CASE WHEN LENGTH(password) < 60 THEN 1 ELSE 0 END) AS insecure_passwords
FROM users;

-- Check user roles distribution
SELECT 
    'User Roles Distribution' AS check_type,
    role,
    COUNT(*) AS user_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM users), 2) AS percentage
FROM users
GROUP BY role
ORDER BY 
    CASE role 
        WHEN 'major_admin' THEN 1
        WHEN 'admin' THEN 2
        WHEN 'user' THEN 3
        WHEN 'banned' THEN 4
    END;

-- =====================================================
-- STEP 9: FINAL SUMMARY
-- =====================================================

SELECT 'FINAL DATABASE VALIDATION SUMMARY' AS report;

SELECT 
    'Overall Status' AS metric,
    CASE 
        WHEN (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()) < 15 THEN 'INCOMPLETE - Missing tables'
        WHEN (SELECT COUNT(*) FROM users WHERE role IN ('major_admin', 'admin')) = 0 THEN 'CRITICAL - No admin users'
        WHEN (SELECT COUNT(*) FROM settings) = 0 THEN 'WARNING - No settings configured'
        ELSE 'READY - Database properly configured'
    END AS status,
    (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()) AS tables_count,
    (SELECT COALESCE(SUM(TABLE_ROWS), 0) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()) AS total_records;

-- =====================================================
-- STEP 10: ACTION ITEMS
-- =====================================================

SELECT 'Required Actions' AS action_type, 'Priority' AS priority, 'Action Required' AS action
UNION ALL
SELECT 
    'Create Admin User' AS action_type,
    'CRITICAL' AS priority,
    'Run the admin user creation SQL from kark_complete_database.sql' AS action
FROM dual
WHERE (SELECT COUNT(*) FROM users WHERE role IN ('major_admin', 'admin')) = 0
UNION ALL
SELECT 
    'Import Initial Data',
    'HIGH',
    'Run the initial data inserts from kark_complete_database.sql'
FROM dual
WHERE (SELECT COUNT(*) FROM hero_sliders) = 0
UNION ALL
SELECT 
    'Configure Settings',
    'MEDIUM',
    'Update site settings with your organization details'
FROM dual
WHERE (SELECT COUNT(*) FROM settings WHERE `key` = 'general.site_name') = 0;

-- End of validation script