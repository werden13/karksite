const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

// Read JSON data files
const readJsonFile = (filename) => {
  try {
    const filePath = path.join(__dirname, 'data', filename);
    const data = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error reading ${filename}:`, error);
    return [];
  }
};

// Escape SQL strings
const escapeSql = (str) => {
  if (str === null || str === undefined) return 'NULL';
  return "'" + String(str).replace(/'/g, "''").replace(/\\/g, "\\\\") + "'";
};

// Format date for MySQL
const formatDate = (dateStr) => {
  if (!dateStr) return 'NULL';
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return 'NULL';
  return escapeSql(date.toISOString().slice(0, 19).replace('T', ' '));
};

// Generate SQL file
const generateSql = async () => {
  let sql = `-- Data Export from JSON to MySQL
-- Generated on: ${new Date().toISOString()}
-- 
-- IMPORTANT: Update the passwords after import!

SET FOREIGN_KEY_CHECKS = 0;

`;

  // Export users
  const users = readJsonFile('users.json');
  if (users.length > 0) {
    sql += '-- Users data\n';
    sql += 'TRUNCATE TABLE `users`;\n';
    for (const user of users) {
      sql += `INSERT INTO users (id, username, password, first_name, last_name, email, role, permissions, created_at, updated_at) VALUES (`;
      sql += `${user.id}, `;
      sql += `${escapeSql(user.username)}, `;
      sql += `${escapeSql(user.password)}, `;
      sql += `${escapeSql(user.firstName)}, `;
      sql += `${escapeSql(user.lastName)}, `;
      sql += `${escapeSql(user.email)}, `;
      sql += `${escapeSql(user.role || 'user')}, `;
      sql += `${user.permissions ? escapeSql(JSON.stringify(user.permissions)) : 'NULL'}, `;
      sql += `${formatDate(user.createdAt)}, `;
      sql += `${formatDate(user.updatedAt)}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  // Export settings
  const settings = readJsonFile('settings.json');
  if (settings.length > 0) {
    sql += '-- Settings data\n';
    sql += 'TRUNCATE TABLE `settings`;\n';
    for (const setting of settings) {
      sql += `INSERT INTO settings (id, \`key\`, value, type, description) VALUES (`;
      sql += `${setting.id}, `;
      sql += `${escapeSql(setting.key)}, `;
      sql += `${escapeSql(setting.value)}, `;
      sql += `${escapeSql(setting.type || 'string')}, `;
      sql += `${escapeSql(setting.description)}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  // Export events
  const events = readJsonFile('events.json');
  if (events.length > 0) {
    sql += '-- Events data\n';
    sql += 'TRUNCATE TABLE `events`;\n';
    for (const event of events) {
      sql += `INSERT INTO events (id, title, description, event_date, location, image_url, is_active, order_index) VALUES (`;
      sql += `${event.id}, `;
      sql += `${escapeSql(event.title)}, `;
      sql += `${escapeSql(event.description)}, `;
      sql += `${event.date ? escapeSql(event.date) : 'NULL'}, `;
      sql += `${escapeSql(event.location)}, `;
      sql += `${escapeSql(event.imageUrl)}, `;
      sql += `${event.isActive !== false ? 1 : 0}, `;
      sql += `${event.orderIndex || 0}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  // Export media
  const media = readJsonFile('media.json');
  if (media.length > 0) {
    sql += '-- Media data\n';
    sql += 'TRUNCATE TABLE `media`;\n';
    for (const item of media) {
      sql += `INSERT INTO media (id, title, description, type, url, thumbnail_url, category, tags, is_featured, view_count, order_index) VALUES (`;
      sql += `${item.id}, `;
      sql += `${escapeSql(item.title)}, `;
      sql += `${escapeSql(item.description)}, `;
      sql += `${escapeSql(item.type || 'image')}, `;
      sql += `${escapeSql(item.url)}, `;
      sql += `${escapeSql(item.thumbnailUrl)}, `;
      sql += `${escapeSql(item.category)}, `;
      sql += `${item.tags ? escapeSql(JSON.stringify(item.tags)) : 'NULL'}, `;
      sql += `${item.isFeatured ? 1 : 0}, `;
      sql += `${item.viewCount || 0}, `;
      sql += `${item.orderIndex || 0}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  // Export team
  const team = readJsonFile('team.json');
  if (team.length > 0) {
    sql += '-- Team data\n';
    sql += 'TRUNCATE TABLE `team`;\n';
    for (const member of team) {
      sql += `INSERT INTO team (id, name, position, bio, image_url, email, phone, social_links, is_active, order_index) VALUES (`;
      sql += `${member.id}, `;
      sql += `${escapeSql(member.name)}, `;
      sql += `${escapeSql(member.position)}, `;
      sql += `${escapeSql(member.bio)}, `;
      sql += `${escapeSql(member.imageUrl)}, `;
      sql += `${escapeSql(member.email)}, `;
      sql += `${escapeSql(member.phone)}, `;
      sql += `${member.socialLinks ? escapeSql(JSON.stringify(member.socialLinks)) : 'NULL'}, `;
      sql += `${member.isActive !== false ? 1 : 0}, `;
      sql += `${member.orderIndex || 0}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  // Export hero sliders
  const heroSliders = readJsonFile('hero_sliders.json');
  if (heroSliders.length > 0) {
    sql += '-- Hero Sliders data\n';
    sql += 'TRUNCATE TABLE `hero_sliders`;\n';
    for (const slider of heroSliders) {
      sql += `INSERT INTO hero_sliders (id, title, description, image_url, button_text, button_link, is_active, order_index) VALUES (`;
      sql += `${slider.id}, `;
      sql += `${escapeSql(slider.title)}, `;
      sql += `${escapeSql(slider.description)}, `;
      sql += `${escapeSql(slider.imageUrl)}, `;
      sql += `${escapeSql(slider.buttonText)}, `;
      sql += `${escapeSql(slider.buttonLink)}, `;
      sql += `${slider.isActive !== false ? 1 : 0}, `;
      sql += `${slider.orderIndex || 0}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  // Export admin logs
  const adminLogs = readJsonFile('admin_logs.json');
  if (adminLogs.length > 0) {
    sql += '-- Admin Logs data\n';
    sql += 'TRUNCATE TABLE `admin_logs`;\n';
    for (const log of adminLogs) {
      sql += `INSERT INTO admin_logs (id, user_id, action, details, ip_address, user_agent, resource_type, resource_id, timestamp) VALUES (`;
      sql += `${log.id}, `;
      sql += `${log.userId}, `;
      sql += `${escapeSql(log.action)}, `;
      sql += `${escapeSql(log.details)}, `;
      sql += `${escapeSql(log.ipAddress)}, `;
      sql += `${escapeSql(log.userAgent)}, `;
      sql += `${escapeSql(log.resourceType)}, `;
      sql += `${escapeSql(log.resourceId)}, `;
      sql += `${formatDate(log.timestamp)}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  // Export activities
  const activities = readJsonFile('activities.json');
  if (activities.length > 0) {
    sql += '-- Activities data\n';
    sql += 'TRUNCATE TABLE `activities`;\n';
    for (const activity of activities) {
      sql += `INSERT INTO activities (id, title, description, activity_date, category, image_url, location, participant_count, is_featured, is_active, tags) VALUES (`;
      sql += `${activity.id}, `;
      sql += `${escapeSql(activity.title)}, `;
      sql += `${escapeSql(activity.description)}, `;
      sql += `${activity.activityDate ? escapeSql(activity.activityDate) : 'NULL'}, `;
      sql += `${escapeSql(activity.category)}, `;
      sql += `${escapeSql(activity.imageUrl)}, `;
      sql += `${escapeSql(activity.location)}, `;
      sql += `${activity.participantCount || 'NULL'}, `;
      sql += `${activity.isFeatured ? 1 : 0}, `;
      sql += `${activity.isActive !== false ? 1 : 0}, `;
      sql += `${activity.tags ? escapeSql(JSON.stringify(activity.tags)) : 'NULL'}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  // Export contact messages
  const contact = readJsonFile('contact.json');
  if (contact.length > 0) {
    sql += '-- Contact messages data\n';
    sql += 'TRUNCATE TABLE `contact`;\n';
    for (const message of contact) {
      sql += `INSERT INTO contact (id, name, email, subject, message, phone, is_read, admin_notes, created_at) VALUES (`;
      sql += `${message.id}, `;
      sql += `${escapeSql(message.name)}, `;
      sql += `${escapeSql(message.email)}, `;
      sql += `${escapeSql(message.subject)}, `;
      sql += `${escapeSql(message.message)}, `;
      sql += `${escapeSql(message.phone)}, `;
      sql += `${message.isRead ? 1 : 0}, `;
      sql += `${escapeSql(message.adminNotes)}, `;
      sql += `${formatDate(message.createdAt)}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  // Export donation methods
  const donationMethods = readJsonFile('donation_methods.json');
  if (donationMethods.length > 0) {
    sql += '-- Donation Methods data\n';
    sql += 'TRUNCATE TABLE `donation_methods`;\n';
    for (const method of donationMethods) {
      sql += `INSERT INTO donation_methods (id, title, bank_name, account_holder, account_number, iban, swift_code, branch_code, branch_name, currency, description, is_active, order_index) VALUES (`;
      sql += `${method.id}, `;
      sql += `${escapeSql(method.title || method.bankName)}, `;
      sql += `${escapeSql(method.bankName)}, `;
      sql += `${escapeSql(method.accountHolder)}, `;
      sql += `${escapeSql(method.accountNumber)}, `;
      sql += `${escapeSql(method.iban)}, `;
      sql += `${escapeSql(method.swiftCode)}, `;
      sql += `${escapeSql(method.branchCode)}, `;
      sql += `${escapeSql(method.branchName)}, `;
      sql += `${escapeSql(method.currency || 'TRY')}, `;
      sql += `${escapeSql(method.description)}, `;
      sql += `${method.isActive !== false ? 1 : 0}, `;
      sql += `${method.orderIndex || 0}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  // Export donation campaigns
  const donationCampaigns = readJsonFile('donation_campaigns.json');
  if (donationCampaigns.length > 0) {
    sql += '-- Donation Campaigns data\n';
    sql += 'TRUNCATE TABLE `donation_campaigns`;\n';
    for (const campaign of donationCampaigns) {
      sql += `INSERT INTO donation_campaigns (id, title, description, goal_amount, current_amount, start_date, end_date, image_url, is_active, is_featured) VALUES (`;
      sql += `${campaign.id}, `;
      sql += `${escapeSql(campaign.title)}, `;
      sql += `${escapeSql(campaign.description)}, `;
      sql += `${campaign.goalAmount || 'NULL'}, `;
      sql += `${campaign.currentAmount || 0}, `;
      sql += `${campaign.startDate ? escapeSql(campaign.startDate) : 'NULL'}, `;
      sql += `${campaign.endDate ? escapeSql(campaign.endDate) : 'NULL'}, `;
      sql += `${escapeSql(campaign.imageUrl)}, `;
      sql += `${campaign.isActive !== false ? 1 : 0}, `;
      sql += `${campaign.isFeatured ? 1 : 0}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  // Export albums
  const albums = readJsonFile('albums.json');
  if (albums.length > 0) {
    sql += '-- Albums data\n';
    sql += 'TRUNCATE TABLE `albums`;\n';
    for (const album of albums) {
      sql += `INSERT INTO albums (id, title, description, cover_image, images, is_featured, is_active, order_index) VALUES (`;
      sql += `${album.id}, `;
      sql += `${escapeSql(album.title)}, `;
      sql += `${escapeSql(album.description)}, `;
      sql += `${escapeSql(album.coverImage)}, `;
      sql += `${album.images ? escapeSql(JSON.stringify(album.images)) : 'NULL'}, `;
      sql += `${album.isFeatured ? 1 : 0}, `;
      sql += `${album.isActive !== false ? 1 : 0}, `;
      sql += `${album.orderIndex || 0}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  // Export archive items
  const archiveItems = readJsonFile('archive_items.json');
  if (archiveItems.length > 0) {
    sql += '-- Archive Items data\n';
    sql += 'TRUNCATE TABLE `archive_items`;\n';
    for (const item of archiveItems) {
      sql += `INSERT INTO archive_items (id, title, description, content, type, date, location, participants, images, videos, documents, tags, is_featured, is_active, view_count) VALUES (`;
      sql += `${item.id}, `;
      sql += `${escapeSql(item.title)}, `;
      sql += `${escapeSql(item.description)}, `;
      sql += `${escapeSql(item.content)}, `;
      sql += `${escapeSql(item.type)}, `;
      sql += `${item.date ? escapeSql(item.date) : 'NULL'}, `;
      sql += `${escapeSql(item.location)}, `;
      sql += `${item.participants ? escapeSql(JSON.stringify(item.participants)) : 'NULL'}, `;
      sql += `${item.images ? escapeSql(JSON.stringify(item.images)) : 'NULL'}, `;
      sql += `${item.videos ? escapeSql(JSON.stringify(item.videos)) : 'NULL'}, `;
      sql += `${item.documents ? escapeSql(JSON.stringify(item.documents)) : 'NULL'}, `;
      sql += `${item.tags ? escapeSql(JSON.stringify(item.tags)) : 'NULL'}, `;
      sql += `${item.isFeatured ? 1 : 0}, `;
      sql += `${item.isActive !== false ? 1 : 0}, `;
      sql += `${item.viewCount || 0}`;
      sql += ');\n';
    }
    sql += '\n';
  }

  sql += 'SET FOREIGN_KEY_CHECKS = 1;\n';
  sql += '\n-- Export completed successfully!\n';
  sql += '-- Remember to update passwords after import for security.\n';

  // Write to file
  fs.writeFileSync('data_export_for_phpmyadmin.sql', sql);
  console.log('SQL export file created: data_export_for_phpmyadmin.sql');
  console.log('\nNext steps:');
  console.log('1. Upload both SQL files to phpMyAdmin');
  console.log('2. Import export_for_phpmyadmin.sql first (creates tables)');
  console.log('3. Import data_export_for_phpmyadmin.sql second (inserts data)');
  console.log('4. Update user passwords for security');
};

// Run the export
generateSql().catch(console.error);