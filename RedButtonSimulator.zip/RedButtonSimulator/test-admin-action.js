// Test script to create an admin log entry
import fs from 'fs/promises';
import path from 'path';

const ADMIN_LOGS_FILE = path.join(process.cwd(), 'data', 'admin_logs.json');

async function createTestLog() {
  try {
    // Create a test log entry
    const testLog = {
      id: 1,
      userId: 2,
      action: "Güvenlik Sistemi Test",
      details: "Güvenlik kayıtları sisteminin test edilmesi",
      ipAddress: "127.0.0.1",
      userAgent: "Test Script",
      resourceType: "security",
      resourceId: "test-1",
      timestamp: new Date().toISOString()
    };

    // Write to file
    await fs.writeFile(ADMIN_LOGS_FILE, JSON.stringify([testLog], null, 2));
    
    console.log('Test admin log created successfully!');
    console.log('You should now see this log in the Security Logs panel.');
  } catch (error) {
    console.error('Error creating test log:', error);
  }
}

createTestLog();