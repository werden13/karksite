/**
 * This script creates test admin logs to verify the admin logging system
 * is properly recording activities in the database
 */

import { Client } from 'pg';

async function main() {
  try {
    // Connect to the database
    const client = new Client({
      connectionString: process.env.DATABASE_URL,
    });
    await client.connect();
    console.log('Connected to PostgreSQL database');

    // Create test admin log entries for different action types
    await client.query(`
      INSERT INTO admin_logs (
        user_id, 
        action, 
        details, 
        resource_type,
        ip_address
      ) VALUES (
        2, 
        'Bağış yöntemi eklendi', 
        'Yeni bağış yöntemi eklendi: Test Bağış', 
        'donation-methods',
        '127.0.0.1'
      )
    `);
    console.log('Added test log entry for donation method');

    await client.query(`
      INSERT INTO admin_logs (
        user_id, 
        action, 
        details, 
        resource_type,
        ip_address
      ) VALUES (
        2, 
        'Ayarlar kaydedildi', 
        'Ayarlar güncellendi: general.site_title, contact.email', 
        'settings',
        '127.0.0.1'
      )
    `);
    console.log('Added test log entry for settings');

    // Add one more log for events
    await client.query(`
      INSERT INTO admin_logs (
        user_id, 
        action, 
        details, 
        resource_type,
        ip_address
      ) VALUES (
        2, 
        'Yeni etkinlik eklendi', 
        'Yeni etkinlik oluşturuldu: Test Etkinlik', 
        'events',
        '127.0.0.1'
      )
    `);
    console.log('Added test log entry for events');

    // Close the database connection
    await client.end();
    console.log('Database connection closed');

    console.log('\nAdmin log fixes have been applied!');
    console.log('You should now see these test entries in the security logs panel.');
    console.log('From now on, all admin actions will be properly recorded in the logs.');
    
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

main();