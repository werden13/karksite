#!/bin/bash

# KARK Website MySQL Deployment Script
# This script helps deploy your KARK website with MySQL support

echo "🚀 KARK Website MySQL Deployment Script"
echo "========================================"

# Check if MySQL dependencies are installed
echo "📦 Installing MySQL dependencies..."
if [ -f "package-mysql.json" ]; then
    cp package-mysql.json package.json
    npm install mysql2 drizzle-orm
    echo "✅ MySQL dependencies installed"
else
    echo "❌ package-mysql.json not found"
    exit 1
fi

# Check if DATABASE_URL is set
if [ -z "$DATABASE_URL" ]; then
    echo "⚠️  DATABASE_URL environment variable not set"
    echo "Please set your MySQL DATABASE_URL:"
    echo "export DATABASE_URL='mysql://username:password@host:port/database'"
    echo ""
    echo "For hosting platforms:"
    echo "- Railway: Set in environment variables"
    echo "- PlanetScale: Get from dashboard"
    echo "- Heroku: Add ClearDB addon"
    echo ""
    read -p "Continue anyway? (y/N): " continue_deploy
    if [[ $continue_deploy != "y" && $continue_deploy != "Y" ]]; then
        exit 1
    fi
fi

# Generate MySQL migrations
echo "🗄️  Generating MySQL migrations..."
if command -v npx &> /dev/null; then
    mkdir -p migrations-mysql
    npx drizzle-kit generate --config=drizzle.config.mysql.ts
    echo "✅ MySQL migrations generated"
else
    echo "❌ npx not found. Please install Node.js"
    exit 1
fi

# Push database schema
if [ -n "$DATABASE_URL" ]; then
    echo "📊 Pushing database schema..."
    npx drizzle-kit push --config=drizzle.config.mysql.ts
    echo "✅ Database schema created"
fi

# Migrate data if JSON files exist
if [ -d "data" ]; then
    echo "📥 Migrating data from JSON to MySQL..."
    npx tsx scripts/migrate-to-mysql.ts
    echo "✅ Data migration completed"
else
    echo "ℹ️  No JSON data found to migrate"
fi

# Build the application
echo "🔨 Building application..."
npm run build
if [ $? -eq 0 ]; then
    echo "✅ Build completed successfully"
else
    echo "❌ Build failed"
    exit 1
fi

echo ""
echo "🎉 MySQL deployment preparation completed!"
echo ""
echo "📋 Next steps:"
echo "1. Set DATABASE_URL on your hosting platform"
echo "2. Deploy your application files"
echo "3. Ensure the following files are included:"
echo "   - server/mysql-db.ts"
echo "   - scripts/migrate-to-mysql.ts"
echo "   - drizzle.config.mysql.ts"
echo "   - migrations-mysql/"
echo ""
echo "🔧 Hosting platform setup:"
echo "- Railway: railway up"
echo "- Vercel: vercel --prod"
echo "- Heroku: git push heroku main"
echo ""
echo "✅ Your KARK website is ready for MySQL deployment!"