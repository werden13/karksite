# NGINX Deployment Guide for KARK Website

## Prerequisites
- Ubuntu/Debian server with root access
- Domain name pointing to your server IP
- SSL certificate (Let's Encrypt recommended)

## Step 1: Install Required Software

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install nginx
sudo apt install nginx -y

# Install Node.js (if not already installed)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 for process management
sudo npm install -g pm2
```

## Step 2: Prepare Your KARK Application

```bash
# Upload your KARK website files to server
# Example: /var/www/kark/

# Install dependencies
cd /var/www/kark/
npm install

# Build the application
npm run build
```

## Step 3: Create PM2 Configuration

```bash
# Create PM2 ecosystem file
sudo nano /var/www/kark/ecosystem.config.js
```

Add this content:
```javascript
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'npm',
    args: 'start',
    cwd: '/var/www/kark/',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    }
  }]
}
```

## Step 4: Configure NGINX

```bash
# Copy the nginx.conf to sites-available
sudo cp /var/www/kark/nginx.conf /etc/nginx/sites-available/kark

# Edit the configuration file
sudo nano /etc/nginx/sites-available/kark
```

Update these lines in the config:
- Replace `your-domain.com` with your actual domain
- Update SSL certificate paths
- Adjust proxy_pass if your app runs on different port

```bash
# Enable the site
sudo ln -s /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/

# Remove default site
sudo rm /etc/nginx/sites-enabled/default

# Test nginx configuration
sudo nginx -t

# Restart nginx
sudo systemctl restart nginx
```

## Step 5: Set up SSL with Let's Encrypt

```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx -y

# Get SSL certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Auto-renewal (optional)
sudo crontab -e
# Add this line:
# 0 12 * * * /usr/bin/certbot renew --quiet
```

## Step 6: Start Your Application

```bash
# Start with PM2
cd /var/www/kark/
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Set PM2 to start on boot
pm2 startup
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME
```

## Step 7: Configure Firewall

```bash
# Allow HTTP and HTTPS
sudo ufw allow 'Nginx Full'
sudo ufw allow ssh
sudo ufw enable
```

## Useful Commands

```bash
# Check PM2 status
pm2 status

# View logs
pm2 logs kark-website

# Restart application
pm2 restart kark-website

# Check nginx status
sudo systemctl status nginx

# Reload nginx configuration
sudo nginx -s reload

# Test nginx configuration
sudo nginx -t
```

## Troubleshooting

1. **Application not starting:**
   ```bash
   pm2 logs kark-website
   ```

2. **Nginx errors:**
   ```bash
   sudo tail -f /var/log/nginx/error.log
   ```

3. **SSL issues:**
   ```bash
   sudo certbot renew --dry-run
   ```

4. **Port conflicts:**
   ```bash
   sudo netstat -tulpn | grep :5000
   ```

## File Permissions

```bash
# Set correct ownership
sudo chown -R www-data:www-data /var/www/kark/

# Set correct permissions
sudo chmod -R 755 /var/www/kark/
```

Your KARK website will be accessible at https://your-domain.com after completing these steps.