import mysql from 'mysql2/promise';
import { drizzle } from 'drizzle-orm/mysql2';
import * as schema from './shared/schema.js';

// MySQL root connection config
const MYSQL_ROOT_CONFIG = {
  host: 'localhost',
  user: 'root',
  password: '',
  multipleStatements: true
};

// Database config
const DB_NAME = 'kark_db';
const DB_USER = 'kark_user';
const DB_PASSWORD = 'kark_password_2025';

async function setupMySQL() {
  console.log('Setting up MySQL database...');
  
  try {
    // Create root connection
    const rootConnection = await mysql.createConnection(MYSQL_ROOT_CONFIG);
    
    // Create database and user
    await rootConnection.execute(`CREATE DATABASE IF NOT EXISTS ${DB_NAME}`);
    console.log(`✓ Database '${DB_NAME}' created`);
    
    // Create user and grant privileges
    await rootConnection.execute(`CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASSWORD}'`);
    await rootConnection.execute(`GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost'`);
    await rootConnection.execute(`FLUSH PRIVILEGES`);
    console.log(`✓ User '${DB_USER}' created with privileges`);
    
    await rootConnection.end();
    
    // Test connection with new user
    const testConnection = await mysql.createConnection({
      host: 'localhost',
      user: DB_USER,
      password: DB_PASSWORD,
      database: DB_NAME
    });
    
    console.log('✓ Successfully connected to MySQL with new user');
    await testConnection.end();
    
    // Create .env file with database URL
    const fs = await import('fs/promises');
    const envContent = `# MySQL Database Configuration
MYSQL_HOST=localhost
MYSQL_USER=${DB_USER}
MYSQL_PASSWORD=${DB_PASSWORD}
MYSQL_DATABASE=${DB_NAME}
`;
    
    await fs.writeFile('.env', envContent);
    console.log('✓ Created .env file with database configuration');
    
    console.log('\nMySQL setup complete! You can now run migrations.');
    console.log('\nConnection details:');
    console.log(`Host: localhost`);
    console.log(`Database: ${DB_NAME}`);
    console.log(`User: ${DB_USER}`);
    console.log(`Password: ${DB_PASSWORD}`);
    
  } catch (error) {
    console.error('Error setting up MySQL:', error);
    process.exit(1);
  }
}

setupMySQL();