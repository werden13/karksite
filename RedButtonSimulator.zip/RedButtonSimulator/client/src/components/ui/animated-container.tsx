import { ReactNode } from "react";
import { motion } from "framer-motion";

// Animation variants for container elements
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      delayChildren: 0.3,
      staggerChildren: 0.2
    }
  }
};

// Animation variants for individual elements
const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 12
    }
  }
};

// Animation variants for hero section
const heroVariants = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.5,
      ease: "easeOut"
    }
  }
};

// Animation for fade-in content
const fadeInVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      duration: 0.6
    }
  }
};

// Animation for sliding content
const slideInVariants = {
  hidden: { x: -50, opacity: 0 },
  visible: {
    x: 0,
    opacity: 1,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 15
    }
  }
};

// Reusable animated container
export function AnimatedContainer({ 
  children, 
  className = "", 
  delay = 0 
}: { 
  children: ReactNode, 
  className?: string,
  delay?: number 
}) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      transition={{ delay }}
    >
      {children}
    </motion.div>
  );
}

// Reusable animated item
export function AnimatedItem({ 
  children, 
  className = "" 
}: { 
  children: ReactNode, 
  className?: string 
}) {
  return (
    <motion.div
      className={className}
      variants={itemVariants}
    >
      {children}
    </motion.div>
  );
}

// Hero section with animations
export function AnimatedHero({ 
  children, 
  className = "" 
}: { 
  children: ReactNode, 
  className?: string 
}) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      animate="visible"
      variants={heroVariants}
    >
      {children}
    </motion.div>
  );
}

// Fade-in content
export function FadeIn({ 
  children, 
  className = "",
  delay = 0
}: { 
  children: ReactNode, 
  className?: string,
  delay?: number
}) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      animate="visible"
      variants={fadeInVariants}
      transition={{ delay }}
    >
      {children}
    </motion.div>
  );
}

// Slide-in content
export function SlideIn({ 
  children, 
  className = "",
  delay = 0,
  direction = "left"
}: { 
  children: ReactNode, 
  className?: string,
  delay?: number,
  direction?: "left" | "right" | "up" | "down"
}) {
  const directionVariants = {
    left: { x: -50, opacity: 0 },
    right: { x: 50, opacity: 0 },
    up: { y: 50, opacity: 0 },
    down: { y: -50, opacity: 0 }
  };

  const customVariants = {
    hidden: directionVariants[direction],
    visible: {
      x: 0,
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15,
        delay
      }
    }
  };

  return (
    <motion.div
      className={className}
      initial="hidden"
      animate="visible"
      variants={customVariants}
    >
      {children}
    </motion.div>
  );
}