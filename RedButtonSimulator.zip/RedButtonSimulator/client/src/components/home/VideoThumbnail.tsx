import { useState } from "react";
import { Play } from "lucide-react";
import { extractYouTubeID, getYouTubeThumbnail } from "@/lib/utils";

interface VideoThumbnailProps {
  videoUrl: string;
  title: string;
  description: string;
  onPlay: (videoId: string) => void;
}

export default function VideoThumbnail({ 
  videoUrl, 
  title, 
  description, 
  onPlay 
}: VideoThumbnailProps) {
  const [isHovered, setIsHovered] = useState(false);

  const videoId = extractYouTubeID(videoUrl);
  const thumbnailUrl = videoId ? getYouTubeThumbnail(videoId) : 'https://via.placeholder.com/800x450?text=Video';

  const handlePlay = () => {
    if (videoId) {
      onPlay(videoId);
    }
  };

  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
      <div 
        className="relative aspect-video cursor-pointer overflow-hidden"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={handlePlay}
      >
        <img 
          src={thumbnailUrl} 
          alt={title} 
          className={`w-full h-full object-cover transition-transform duration-500 ${
            isHovered ? 'scale-110' : 'scale-100'
          }`}
          loading="lazy"
        />
        <div className={`absolute inset-0 bg-gradient-to-t from-black/60 to-black/20 transition-opacity duration-300 flex items-center justify-center ${
          isHovered ? 'bg-opacity-70' : 'bg-opacity-50'
        }`}>
          <div className={`bg-red-600 w-16 h-16 rounded-full flex items-center justify-center transform transition-transform duration-300 ${
            isHovered ? 'scale-110' : 'scale-100'
          }`}>
            <Play className="h-6 w-6 text-white ml-1" fill="white" />
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
          <p className="text-xs text-white font-medium">Eğitim Videosu</p>
        </div>
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-2 group-hover:text-red-600 transition-colors">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
}
