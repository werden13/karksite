import { useState, useEffect } from "react";
import { Moon, Sun } from "lucide-react";
import { motion } from "framer-motion";

const ThemeToggle = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Initialize theme based on user preference or browser settings
  useEffect(() => {
    // Check if user has already set a preference
    const savedTheme = localStorage.getItem("theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    
    // Set initial theme
    if (savedTheme === "dark" || (savedTheme === null && prefersDark)) {
      setIsDarkMode(true);
      document.documentElement.classList.add("dark");
    } else {
      setIsDarkMode(false);
      document.documentElement.classList.remove("dark");
    }
  }, []);

  const toggleTheme = () => {
    setIsDarkMode(prev => {
      const newTheme = !prev;
      // Save user preference
      localStorage.setItem("theme", newTheme ? "dark" : "light");
      
      // Update DOM
      if (newTheme) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
      
      return newTheme;
    });
  };

  return (
    <motion.button
      className={`relative w-16 h-8 rounded-full transition-all duration-500 ease-in-out shadow-lg hover:shadow-xl overflow-hidden ${
        isDarkMode 
          ? 'bg-gradient-to-br from-indigo-950 via-purple-900 to-blue-950' 
          : 'bg-gradient-to-br from-sky-300 via-blue-300 to-cyan-300'
      }`}
      onClick={toggleTheme}
      whileTap={{ scale: 0.95 }}
      whileHover={{ scale: 1.05 }}
    >
      {/* Background elements */}
      <div className="absolute inset-0">
        {isDarkMode ? (
          <>
            {/* Nebula effect for dark mode */}
            <div className="absolute inset-0 opacity-30">
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-purple-600/20 via-transparent to-blue-600/20" />
              <div className="absolute bottom-0 right-0 w-full h-full bg-gradient-to-tl from-indigo-600/20 via-transparent to-pink-600/10" />
            </div>
            
            {/* Stars for dark mode */}
            <div className="absolute inset-0" style={{
              backgroundImage: `
                radial-gradient(1.5px 1.5px at 15% 20%, white, transparent),
                radial-gradient(1px 1px at 60% 15%, rgba(255,255,255,0.9), transparent),
                radial-gradient(1.5px 1.5px at 75% 35%, white, transparent),
                radial-gradient(1px 1px at 25% 60%, rgba(255,255,255,0.8), transparent),
                radial-gradient(1.5px 1.5px at 85% 25%, white, transparent),
                radial-gradient(1px 1px at 40% 40%, rgba(255,255,255,0.7), transparent),
                radial-gradient(1.5px 1.5px at 20% 80%, white, transparent),
                radial-gradient(1px 1px at 90% 60%, rgba(255,255,255,0.9), transparent),
                radial-gradient(1px 1px at 50% 70%, rgba(255,255,255,0.6), transparent),
                radial-gradient(1.5px 1.5px at 65% 50%, white, transparent),
                radial-gradient(2px 2px at 30% 45%, rgba(147,197,253,0.3), transparent),
                radial-gradient(2px 2px at 70% 65%, rgba(196,181,253,0.3), transparent)
              `
            }} />
            
            {/* Twinkling effect */}
            <div className="absolute top-3 left-4 w-1 h-1 bg-white rounded-full animate-pulse" />
            <div className="absolute bottom-2 right-3 w-0.5 h-0.5 bg-blue-200 rounded-full animate-pulse" style={{ animationDelay: '1s' }} />
            <div className="absolute top-5 right-6 w-0.5 h-0.5 bg-purple-200 rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
          </>
        ) : (
          <>
            {/* Clouds for light mode */}
            <div className="absolute inset-0">
              {/* Cloud 1 - layered */}
              <div className="absolute top-1 left-2">
                <div className="absolute w-3 h-2 bg-white/90 rounded-full" />
                <div className="absolute w-2.5 h-1.5 bg-white/80 rounded-full -left-1 top-0.5" />
                <div className="absolute w-2 h-1.5 bg-white/85 rounded-full left-2.5 top-0.5" />
              </div>
              
              {/* Cloud 2 - fluffy */}
              <div className="absolute top-2.5 right-3">
                <div className="absolute w-2.5 h-1.5 bg-white/95 rounded-full" />
                <div className="absolute w-2 h-1.5 bg-white/90 rounded-full left-1.5 -top-0.5" />
                <div className="absolute w-1.5 h-1 bg-white/85 rounded-full left-0.5 top-1" />
              </div>
              
              {/* Cloud 3 - wispy */}
              <div className="absolute bottom-2 left-6">
                <div className="absolute w-3.5 h-1.5 bg-white rounded-full" />
                <div className="absolute w-2 h-1 bg-white/90 rounded-full -left-1.5 top-0.5" />
                <div className="absolute w-2.5 h-1 bg-white/95 rounded-full left-3 top-0.5" />
                <div className="absolute w-1.5 h-1 bg-white/80 rounded-full left-1 -top-0.5" />
              </div>
              
              {/* Cloud 4 - small detail */}
              <div className="absolute top-4 left-10">
                <div className="absolute w-2 h-1 bg-white/75 rounded-full" />
                <div className="absolute w-1.5 h-1 bg-white/70 rounded-full left-1.5 top-0" />
              </div>
              
              {/* Cloud 5 - tiny accent */}
              <div className="absolute bottom-3 right-5">
                <div className="absolute w-1.5 h-1 bg-white/80 rounded-full" />
                <div className="absolute w-1 h-0.5 bg-white/75 rounded-full left-1 top-0.5" />
              </div>
            </div>
          </>
        )}
      </div>

      {/* Sliding toggle */}
      <motion.div
        className={`absolute top-1 w-6 h-6 rounded-full shadow-lg flex items-center justify-center ${
          isDarkMode ? 'bg-gray-100' : 'bg-white'
        }`}
        animate={{
          x: isDarkMode ? 8 : 32,
        }}
        transition={{
          type: "spring",
          stiffness: 300,
          damping: 30,
        }}
      >
        {isDarkMode ? (
          <motion.div
            initial={{ rotate: -45, scale: 0 }}
            animate={{ rotate: 0, scale: 1 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="text-blue-600"
          >
            <Moon className="h-3.5 w-3.5" strokeWidth={2.5} fill="currentColor" />
          </motion.div>
        ) : (
          <motion.div
            initial={{ rotate: 45, scale: 0 }}
            animate={{ rotate: 0, scale: 1 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="text-yellow-500"
          >
            <Sun className="h-3.5 w-3.5" strokeWidth={2.5} fill="currentColor" />
          </motion.div>
        )}
      </motion.div>
    </motion.button>
  );
};

export default ThemeToggle;