import { useState, ReactNode, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useAuth } from "@/hooks/use-auth";
import { queryClient } from "@/lib/queryClient";
import RefreshableSecurityLogsPanel from "./RefreshableSecurityLogsPanel";
import { 
  LayoutDashboard, 
  Calendar, 
  Film, 
  Image, 
  Users, 
  Settings, 
  LogOut, 
  Menu, 
  X,
  HeartHandshake,
  SlidersHorizontal,
  Mail,
  Shield,
  BarChart,
  Archive,
  Activity
} from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface AdminLayoutProps {
  children: ReactNode;
  title: string;
}

export default function AdminLayout({ children, title }: AdminLayoutProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  console.log("Admin panel user details:", user);
  if (!user || (!user.isAdmin && user.role !== "admin" && user.role !== "major_admin")) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Yetkisiz Erişim</h1>
          <p className="mb-4">Bu sayfaya erişim izniniz bulunmamaktadır.</p>
          <Link href="/">
            <Button>Ana Sayfaya Dön</Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Basic navigation items for all admins
  let navigationItems = [
    { href: "/admin", label: "Dashboard", icon: <LayoutDashboard className="h-5 w-5" /> },
    { href: "/admin/activities", label: "Son Faaliyetler", icon: <Activity className="h-5 w-5" /> },
    { href: "/admin/events", label: "Operasyonlar", icon: <Calendar className="h-5 w-5" /> },
    { href: "/admin/archive", label: "Arşiv Yönetimi", icon: <Archive className="h-5 w-5" /> },
    { href: "/admin/videos", label: "Eğitim Videoları", icon: <Film className="h-5 w-5" /> },
    { href: "/admin/photos", label: "Fotoğraf Galerisi", icon: <Image className="h-5 w-5" /> },
    { href: "/admin/team", label: "Ekip Üyeleri", icon: <Users className="h-5 w-5" /> },
    { href: "/admin/users", label: "Kullanıcı Yönetimi", icon: <Users className="h-5 w-5" /> },
    { href: "/admin/contact-messages", label: "İletişim Mesajları", icon: <Mail className="h-5 w-5" /> },
  ];
  
  // Add additional items based on user permissions
  if (user.permissions?.includes("manage_donations")) {
    navigationItems.push({ href: "/admin/donations", label: "Bağış Yönetimi", icon: <HeartHandshake className="h-5 w-5" /> });
  }
  
  if (user.permissions?.includes("manage_sliders")) {
    navigationItems.push({ href: "/admin/sliders", label: "Ana Sayfa Slider", icon: <SlidersHorizontal className="h-5 w-5" /> });
  }
  
  if (user.permissions?.includes("manage_settings")) {
    navigationItems.push({ href: "/admin/settings", label: "Ayarlar", icon: <Settings className="h-5 w-5" /> });
  }
  
  // Add admin management tab for major admins only
  if (user.permissions?.includes("manage_admins") || user.role === "major_admin") {
    navigationItems.push({ 
      href: "/admin/manage-admins", 
      label: "Admin Yönetimi", 
      icon: <Users className="h-5 w-5" /> 
    });
  }
  
  // Add security logs tab only for major_admin (supermanager)
  if (user.role === "major_admin") {
    navigationItems.push({ 
      href: "/admin/security-logs", 
      label: "Güvenlik Kayıtları", 
      icon: <Shield className="h-5 w-5" /> 
    });
  }

  const Sidebar = () => (
    <>
      <div className="mb-8 px-4">
        <Link href="/" className="text-2xl font-bold flex items-center">
          <div className="flex items-center mr-2">
            <span style={{ 
              color: '#FF0000', 
              textShadow: '2px 2px 0 #000', 
              WebkitTextStroke: '1px #000'
            }}>K</span>
            <span style={{ 
              color: '#FFFFFF', 
              textShadow: '2px 2px 0 #000', 
              WebkitTextStroke: '1px #000'
            }}>A</span>
            <span style={{ 
              color: '#FF0000', 
              textShadow: '2px 2px 0 #000', 
              WebkitTextStroke: '1px #000'
            }}>RK</span>
          </div>
          <span className="text-red-600 ml-1">Arama Kurtarma</span>
        </Link>
      </div>
      
      <div className="space-y-1 px-2">
        {navigationItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium ${
              location === item.href
                ? "bg-secondary text-white dark:bg-blue-700"
                : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
            }`}
          >
            {item.icon}
            {item.label}
          </Link>
        ))}
      </div>
      
      <div className="mt-auto px-2">
        <Separator className="my-4 dark:bg-gray-700" />
        <div className="flex items-center gap-3 rounded-md p-3 dark:bg-gray-800/50 dark:backdrop-blur-sm">
          <Avatar>
            <AvatarFallback className="bg-secondary text-white dark:bg-blue-600 dark:text-white">
              {user.firstName[0]}{user.lastName[0]}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 overflow-hidden">
            <p className="text-sm font-medium dark:text-white">{user.firstName} {user.lastName}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{user.email}</p>
          </div>
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          className="w-full justify-start mt-2 text-red-600 hover:text-red-700 hover:bg-red-50 dark:text-red-400 dark:hover:text-red-300 dark:hover:bg-red-900/20"
          onClick={handleLogout}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Çıkış Yap
        </Button>
      </div>
    </>
  );

  // Only show security logs for major_admin (supermanager)
  const [showSecurityLogs, setShowSecurityLogs] = useState(false);
  
  // Refresh admin logs when security logs panel is opened
  useEffect(() => {
    if (showSecurityLogs) {
      // Force refresh of admin logs data
      queryClient.invalidateQueries({ queryKey: ['/api/admin-logs'] });
    }
  }, [showSecurityLogs]);
  
  const SecurityButton = () => {
    if (user.role !== "major_admin") return null;
    
    return (
      <Button
        variant={showSecurityLogs ? "default" : "outline"}
        size="sm"
        className={`mr-2 ${
          showSecurityLogs 
            ? "bg-red-600 hover:bg-red-700" 
            : "text-red-600 border-red-600 hover:bg-red-50 dark:text-red-400 dark:border-red-400 dark:hover:bg-gray-800 dark:hover:text-red-300"
        }`}
        onClick={() => setShowSecurityLogs(!showSecurityLogs)}
      >
        <Shield className="h-4 w-4 mr-2" />
        {showSecurityLogs ? "Güvenlik Panelini Kapat" : "Güvenlik Kayıtları"}
      </Button>
    );
  };
  
  // Use the RefreshableSecurityLogsPanel component which automatically updates the logs

  return (
    <div className="flex min-h-screen">
      {/* Desktop Sidebar */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 bg-white dark:bg-gray-900 border-r dark:border-gray-800">
        <div className="flex flex-col flex-1 pt-5 pb-4 overflow-y-auto">
          <Sidebar />
        </div>
      </div>
      
      {/* Mobile Sidebar with Trigger */}
      <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
        <SheetTrigger asChild className="md:hidden">
          <Button variant="ghost" size="icon" className="absolute top-5 left-4 z-20 dark:text-gray-200">
            <Menu className="h-6 w-6" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 pt-5 dark:bg-gray-900 admin-scrollbar">
          <Sidebar />
        </SheetContent>
      </Sheet>
      
      {/* Main Content */}
      <div className="md:pl-64 flex flex-col flex-1 admin-scrollbar dark:bg-gray-950">
        <div className="sticky top-0 z-10 flex-shrink-0 h-16 bg-white dark:bg-gray-900 border-b dark:border-gray-800 flex items-center px-4 md:px-6">
          <Button 
            variant="ghost" 
            size="icon" 
            className="md:hidden mr-4 dark:text-gray-300"
            onClick={() => setIsMobileMenuOpen(true)}
          >
            <Menu className="h-6 w-6" />
          </Button>
          
          <h1 className="text-xl font-bold dark:text-white">
            {title}
          </h1>
          
          <div className="ml-auto flex items-center">
            <SecurityButton />
            <Link href="/" className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">
              <Button variant="ghost" size="sm" className="dark:hover:bg-gray-800">
                Siteye Dön
              </Button>
            </Link>
          </div>
        </div>
        
        <main className="flex-1 p-6 overflow-auto admin-scrollbar">
          {showSecurityLogs ? (
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold">Güvenlik Kayıtları Paneli</h2>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    setShowSecurityLogs(false);
                  }}
                >
                  <X className="h-4 w-4 mr-2" />
                  Kapat
                </Button>
              </div>
              <div className="p-4 bg-white dark:bg-gray-900 rounded-lg border dark:border-gray-800 shadow-sm">
                <RefreshableSecurityLogsPanel />
              </div>
            </div>
          ) : null}
          
          {children}
        </main>
      </div>
    </div>
  );
}
