import React, { useEffect, useState } from 'react';
import SecurityLogsPanel from './SecurityLogsPanel';
import { queryClient } from '@/lib/queryClient';
import { RotateCw } from 'lucide-react';

/**
 * This component wraps the SecurityLogsPanel and ensures it refreshes
 * after admin actions are performed
 */
export default function RefreshableSecurityLogsPanel() {
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Force refresh security logs data whenever this component is shown
  useEffect(() => {
    // Immediately refresh on mount
    refreshLogs();
    
    // Set up a timer to refresh logs every second while the panel is visible
    const refreshInterval = setInterval(() => {
      refreshLogs();
    }, 2000); // 2-second refresh interval
    
    // Clean up timer when component unmounts
    return () => clearInterval(refreshInterval);
  }, []);
  
  // Function to handle log refreshing with visual feedback
  const refreshLogs = async () => {
    setIsRefreshing(true);
    try {
      await queryClient.invalidateQueries({ queryKey: ['/api/admin-logs'] });
      await queryClient.refetchQueries({ queryKey: ['/api/admin-logs'] });
    } finally {
      setIsRefreshing(false);
    }
  };
  
  return (
    <div className="relative">
      {isRefreshing && (
        <div className="absolute top-4 right-4 z-10">
          <RotateCw className="h-4 w-4 animate-spin text-secondary" />
        </div>
      )}
      <SecurityLogsPanel />
    </div>
  );
}