import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, formatDistanceToNow } from "date-fns";
import { tr } from "date-fns/locale";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string): string {
  const dateObject = typeof date === "string" ? new Date(date) : date;
  return format(dateObject, "dd MMMM yyyy", { locale: tr });
}

export function formatDateTime(date: Date | string): string {
  const dateObject = typeof date === "string" ? new Date(date) : date;
  return format(dateObject, "dd MMMM yyyy HH:mm", { locale: tr });
}

export function formatRelativeTime(date: Date | string): string {
  const dateObject = typeof date === "string" ? new Date(date) : date;
  return formatDistanceToNow(dateObject, { addSuffix: true, locale: tr });
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return `${text.substring(0, maxLength).trim()}...`;
}

export const categoryColors = {
  rescue: "bg-red-600",
  training: "bg-blue-600",
  donation: "bg-green-600",
  awareness: "bg-yellow-600",
};

export const categoryLabels = {
  rescue: "Arama Kurtarma",
  training: "Eğitim",
  donation: "Bağış",
  awareness: "Farkındalık",
};

export function getCategoryLabel(category: string): string {
  return categoryLabels[category as keyof typeof categoryLabels] || category;
}

export function getCategoryColor(category: string): string {
  return categoryColors[category as keyof typeof categoryColors] || "bg-gray-600";
}

export function extractYouTubeID(url: string): string | null {
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
  const match = url.match(regExp);
  return match && match[2].length === 11 ? match[2] : null;
}

export function getYouTubeThumbnail(videoId: string): string {
  return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
}

export function getYouTubeEmbedUrl(videoId: string): string {
  return `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1`;
}

export function getRandomPlaceholderImage(seed: number, width = 400, height = 300): string {
  // Consistent set of placeholder images based on seed
  const imageIds = [
    "JYFmT3mw1F0", "QeVmJPZT1Cg", "T1Lh0gn3c0c", "y-ETTaWq-yE",
    "Qrspubmq8Sw", "K6-N3CMcIW0", "h8NXhMfJ-G4", "5Ug8cMT29UI"
  ];
  const id = imageIds[seed % imageIds.length];
  return `https://images.unsplash.com/photo-${id}?fit=crop&w=${width}&h=${height}`;
}
