/**
 * Utility functions for dialog/modal handling in the admin interface
 */

/**
 * Closes all open dialogs by simulating a click on close buttons
 */
export function closeAllDialogs(): void {
  // Find all dialog close buttons that are currently open
  const closeButtons = document.querySelectorAll('button[data-state="open"]');
  closeButtons.forEach(button => {
    if (button instanceof HTMLButtonElement) {
      button.click();
    }
  });
  
  // Alternative approach: find and click X buttons in dialogs
  const xButtons = document.querySelectorAll('[role="dialog"] button[aria-label="Close"]');
  xButtons.forEach(button => {
    if (button instanceof HTMLButtonElement) {
      button.click();
    }
  });
}

/**
 * Utility to close a specific dialog by its role or other selector
 */
export function closeDialogBySelector(selector: string): void {
  const dialog = document.querySelector(selector);
  if (dialog) {
    const closeButton = dialog.querySelector('button[data-state="open"], button[aria-label="Close"]');
    if (closeButton instanceof HTMLButtonElement) {
      closeButton.click();
    }
  }
}