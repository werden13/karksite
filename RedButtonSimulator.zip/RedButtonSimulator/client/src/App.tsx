import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { useState, useEffect } from "react";
import { PageLoader } from "@/components/ui/loading-spinner";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import ArchivePage from "@/pages/archive-page";
import ArchiveDetailPage from "@/pages/archive-detail-page";
import AboutPage from "@/pages/about-page";
import KVKKPage from "@/pages/kvkk-page";
import EventsPage from "@/pages/events-page";
import VideosPage from "@/pages/videos-page";
import PhotosPage from "@/pages/photos-page";
import TeamPage from "@/pages/team-page";
import ContactPage from "@/pages/contact-page";
import DonationsPage from "@/pages/donations-page";
import AuthPage from "@/pages/auth-page";
import JumpscarePage from "@/pages/jumpscare-page";
import SecurityTestPage from "@/pages/security-test";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminEvents from "@/pages/admin/events";
import AdminArchive from "@/pages/admin/archive";
import AdminVideos from "@/pages/admin/videos";
import AdminPhotos from "@/pages/admin/photos";
import AdminTeam from "@/pages/admin/team";
import AdminDonations from "@/pages/admin/donations";
import AdminSettings from "@/pages/admin/settings";
import AdminSliders from "@/pages/admin/sliders";
import AdminContactMessages from "@/pages/admin/contact-messages";
import AdminUsers from "@/pages/admin/users";
import ManageAdminsPage from "@/pages/admin/manage-admins";
import SecurityLogsPage from "@/pages/admin/security-logs";
import AdminActivities from "@/pages/admin/activities";

function Router() {
  const [location] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  
  // Show loading animation only when navigating to/from the auth page
  useEffect(() => {
    // Only show loading for auth-related pages
    const isAuthPage = location.includes('/auth');
    
    if (isAuthPage) {
      // Set a very short delay before showing the loader to avoid flashing
      const showLoaderTimeout = setTimeout(() => {
        setIsLoading(true);
      }, 100);
      
      // Hide the loader after content is loaded or after timeout
      const hideLoaderTimeout = setTimeout(() => {
        setIsLoading(false);
      }, 400);
      
      return () => {
        clearTimeout(showLoaderTimeout);
        clearTimeout(hideLoaderTimeout);
      };
    } else {
      // Instantly clear any existing loading state for non-auth pages
      setIsLoading(false);
    }
  }, [location]);
  
  return (
    <>
      {isLoading && <PageLoader />}
      
      <Switch>
        {/* Public Routes */}
        <Route path="/" component={HomePage} />
        <Route path="/archive" component={ArchivePage} />
        <Route path="/archive/:id" component={ArchiveDetailPage} />
        <Route path="/about" component={AboutPage} />
        <Route path="/kvkk" component={KVKKPage} />
        <Route path="/events" component={EventsPage} />
        <Route path="/videos" component={VideosPage} />
        <Route path="/photos" component={PhotosPage} />
        <Route path="/team" component={TeamPage} />
        <Route path="/contact" component={ContactPage} />
        <Route path="/donations" component={DonationsPage} />
        <Route path="/auth" component={AuthPage} />
        <Route path="/security/alert" component={JumpscarePage} />
        <Route path="/security/test" component={SecurityTestPage} />
        
        {/* Admin Routes - Protected and require admin role */}
        <ProtectedRoute path="/admin" component={AdminDashboard} admin />
        <ProtectedRoute path="/admin/activities" component={AdminActivities} admin />
        <ProtectedRoute path="/admin/events" component={AdminEvents} admin />
        <ProtectedRoute path="/admin/archive" component={AdminArchive} admin />
        <ProtectedRoute path="/admin/videos" component={AdminVideos} admin />
        <ProtectedRoute path="/admin/photos" component={AdminPhotos} admin />
        <ProtectedRoute path="/admin/team" component={AdminTeam} admin />
        <ProtectedRoute path="/admin/users" component={AdminUsers} admin />
        <ProtectedRoute path="/admin/contact-messages" component={AdminContactMessages} admin />
        <ProtectedRoute path="/admin/donations" component={AdminDonations} admin />
        <ProtectedRoute path="/admin/sliders" component={AdminSliders} admin />
        <ProtectedRoute path="/admin/settings" component={AdminSettings} admin />
        <ProtectedRoute path="/admin/manage-admins" component={ManageAdminsPage} admin />
        <ProtectedRoute path="/admin/security-logs" component={SecurityLogsPage} admin />
        
        {/* Fallback to 404 */}
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
