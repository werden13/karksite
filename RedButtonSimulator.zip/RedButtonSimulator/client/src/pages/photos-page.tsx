import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import PhotoAlbum from "@/components/gallery/PhotoAlbum";
import PhotoViewer from "@/components/modals/PhotoViewer";
import { Loader2 } from "lucide-react";
import { Album, MediaItem } from "@shared/schema";
import { Helmet } from "react-helmet";

type AlbumWithPhotos = Album & { photos: MediaItem[] };

export default function PhotosPage() {
  const [selectedAlbumId, setSelectedAlbumId] = useState<number | null>(null);
  const [photoIndex, setPhotoIndex] = useState(0);
  const [isPhotoViewerOpen, setIsPhotoViewerOpen] = useState(false);

  const { data: albums, isLoading: isLoadingAlbums } = useQuery<Album[]>({
    queryKey: ["/api/albums"],
  });

  const { data: mediaItems, isLoading: isLoadingMedia } = useQuery<MediaItem[]>({
    queryKey: ["/api/media?type=photo"],
  });

  // Create albums with photos
  const albumsWithPhotos: AlbumWithPhotos[] = albums && mediaItems ? 
    albums.map((album) => ({
      ...album,
      photos: mediaItems.filter((item) => item.albumId === album.id)
    })).filter((album) => album.photos.length > 0) : [];

  const handlePhotoClick = (index: number, albumId: number) => {
    setSelectedAlbumId(albumId);
    setPhotoIndex(index);
    setIsPhotoViewerOpen(true);
  };

  const handleClosePhotoViewer = () => {
    setIsPhotoViewerOpen(false);
  };

  const getSelectedAlbumPhotos = () => {
    if (!selectedAlbumId) return [];
    
    const album = albumsWithPhotos.find((a) => a.id === selectedAlbumId);
    if (!album) return [];
    
    return album.photos.map((photo) => ({
      id: photo.id,
      filePath: photo.filePath,
      title: photo.title
    }));
  };

  const isLoading = isLoadingAlbums || isLoadingMedia;

  return (
    <>
      <Helmet>
        <title>Fotoğraf Galerisi | Etkinlik Platformu</title>
        <meta name="description" content="Etkinliklerimizden fotoğraf albümleri. Kültürel etkinlikler, sanat atölyeleri ve diğer organizasyonlarımızdan görüntüleri keşfedin." />
      </Helmet>
      
      <Navbar />
      
      <main className="content-container">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <div className="flex justify-center">
              <h1 className="section-title">Fotoğraf Galerisi</h1>
            </div>
            <p className="section-description">Etkinliklerimizden fotoğraf albümleri</p>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-12 w-12 animate-spin text-secondary" />
            </div>
          ) : albumsWithPhotos.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {albumsWithPhotos.map((album) => (
                <PhotoAlbum 
                  key={album.id} 
                  album={album} 
                  onPhotoClick={handlePhotoClick} 
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500">Henüz fotoğraf albümü bulunmuyor</p>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
      
      <PhotoViewer 
        isOpen={isPhotoViewerOpen} 
        photos={getSelectedAlbumPhotos()} 
        initialIndex={photoIndex} 
        onClose={handleClosePhotoViewer} 
      />
    </>
  );
}
