import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import VideoThumbnail from "@/components/home/VideoThumbnail";
import VideoPlayer from "@/components/modals/VideoPlayer";
import { Loader2 } from "lucide-react";
import { MediaItem } from "@shared/schema";
import { Helmet } from "react-helmet";

export default function VideosPage() {
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);

  const { data: videos, isLoading } = useQuery<MediaItem[]>({
    queryKey: ["/api/media?type=video"],
  });

  const handlePlayVideo = (videoId: string) => {
    setActiveVideoId(videoId);
    setIsVideoModalOpen(true);
  };

  const handleCloseVideo = () => {
    setIsVideoModalOpen(false);
    setActiveVideoId(null);
  };

  return (
    <>
      <Helmet>
        <title>Video Galerisi | Etkinlik Platformu</title>
        <meta name="description" content="Etkinliklerimizden öne çıkan video içerikler. Kültürel etkinlikler, seminerler, konferanslar ve diğer organizasyonlarımızdan video kayıtlarını izleyin." />
      </Helmet>
      
      <Navbar />
      
      <main className="content-container">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <div className="flex justify-center">
              <h1 className="section-title">Video Galerisi</h1>
            </div>
            <p className="section-description">Etkinliklerimizden öne çıkan video içerikler</p>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-12 w-12 animate-spin text-secondary" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {videos && videos.length > 0 ? (
                videos.map((video) => (
                  <VideoThumbnail 
                    key={video.id}
                    videoUrl={video.filePath}
                    title={video.title}
                    description={video.description || ''}
                    onPlay={handlePlayVideo}
                  />
                ))
              ) : (
                <div className="col-span-1 md:col-span-2 lg:col-span-3 text-center py-12">
                  <p className="text-gray-500">Henüz video bulunmuyor</p>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
      
      <Footer />
      
      <VideoPlayer 
        isOpen={isVideoModalOpen}
        videoId={activeVideoId}
        onClose={handleCloseVideo}
      />
    </>
  );
}
