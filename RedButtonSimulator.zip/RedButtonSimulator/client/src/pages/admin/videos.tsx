import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2, PlusCircle, Edit, Trash2, Search, ExternalLink, Film } from "lucide-react";
import { MediaItem, InsertMediaItem, insertMediaItemSchema } from "@shared/schema";
import { extractYouTubeID, getYouTubeThumbnail } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Helmet } from "react-helmet";

export default function AdminVideos() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const { toast } = useToast();
  
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(searchParams.has("new"));
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<MediaItem | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  
  const { data: videos, isLoading } = useQuery<MediaItem[]>({
    queryKey: ["/api/media?type=video"],
  });
  
  const { data: events } = useQuery({
    queryKey: ["/api/events"],
  });
  
  // Create video schema with validation
  const videoSchema = insertMediaItemSchema.extend({
    filePath: z.string().url("Geçerli bir URL giriniz").refine(
      (value) => extractYouTubeID(value) !== null,
      {
        message: "Geçerli bir YouTube videosu URL'si giriniz",
      }
    ),
  });
  
  // Create video form
  const createForm = useForm<z.infer<typeof videoSchema>>({
    resolver: zodResolver(videoSchema),
    defaultValues: {
      title: "",
      description: "",
      mediaType: "video",
      filePath: "",
      eventId: undefined,
      albumId: undefined,
    },
  });
  
  // Edit video form
  const editForm = useForm<z.infer<typeof videoSchema>>({
    resolver: zodResolver(videoSchema),
    defaultValues: {
      title: "",
      description: "",
      mediaType: "video",
      filePath: "",
      eventId: undefined,
      albumId: undefined,
    },
  });
  
  // Watch for URL changes in the create form to update preview
  useEffect(() => {
    const subscription = createForm.watch((value, { name }) => {
      if (name === "filePath" && value.filePath) {
        const videoId = extractYouTubeID(value.filePath as string);
        setVideoPreview(videoId ? getYouTubeThumbnail(videoId) : null);
      }
    });
    return () => subscription.unsubscribe();
  }, [createForm.watch]);
  
  // Watch for URL changes in the edit form to update preview
  useEffect(() => {
    const subscription = editForm.watch((value, { name }) => {
      if (name === "filePath" && value.filePath) {
        const videoId = extractYouTubeID(value.filePath as string);
        setVideoPreview(videoId ? getYouTubeThumbnail(videoId) : null);
      }
    });
    return () => subscription.unsubscribe();
  }, [editForm.watch]);
  
  // Create video mutation
  const createVideoMutation = useMutation({
    mutationFn: async (video: InsertMediaItem) => {
      const res = await apiRequest("POST", "/api/media", video);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Video eklendi",
        description: "Video başarıyla eklendi.",
      });
      setIsCreateDialogOpen(false);
      createForm.reset();
      setVideoPreview(null);
      queryClient.invalidateQueries({ queryKey: ["/api/media?type=video"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Video eklenirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Update video mutation
  const updateVideoMutation = useMutation({
    mutationFn: async ({ id, video }: { id: number; video: InsertMediaItem }) => {
      const res = await apiRequest("PUT", `/api/media/${id}`, video);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Video güncellendi",
        description: "Video başarıyla güncellendi.",
      });
      setIsEditDialogOpen(false);
      setSelectedVideo(null);
      setVideoPreview(null);
      queryClient.invalidateQueries({ queryKey: ["/api/media?type=video"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Video güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Delete video mutation
  const deleteVideoMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/media/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Video silindi",
        description: "Video başarıyla silindi.",
      });
      setIsDeleteDialogOpen(false);
      setSelectedVideo(null);
      queryClient.invalidateQueries({ queryKey: ["/api/media?type=video"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Video silinirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  function handleCreateVideo() {
    setIsCreateDialogOpen(true);
    setVideoPreview(null);
  }
  
  function handleEditVideo(video: MediaItem) {
    setSelectedVideo(video);
    
    editForm.reset({
      title: video.title,
      description: video.description || "",
      mediaType: "video",
      filePath: video.filePath,
      eventId: video.eventId,
      albumId: video.albumId,
    });
    
    const videoId = extractYouTubeID(video.filePath);
    setVideoPreview(videoId ? getYouTubeThumbnail(videoId) : null);
    
    setIsEditDialogOpen(true);
  }
  
  function handleDeleteVideo(video: MediaItem) {
    setSelectedVideo(video);
    setIsDeleteDialogOpen(true);
  }
  
  function onCreateSubmit(data: z.infer<typeof videoSchema>) {
    createVideoMutation.mutate({
      ...data,
      mediaType: "video",
    });
  }
  
  function onEditSubmit(data: z.infer<typeof videoSchema>) {
    if (selectedVideo) {
      updateVideoMutation.mutate({ 
        id: selectedVideo.id, 
        video: {
          ...data,
          mediaType: "video",
        } 
      });
    }
  }
  
  function confirmDelete() {
    if (selectedVideo) {
      deleteVideoMutation.mutate(selectedVideo.id);
    }
  }
  
  // Filter videos
  const filteredVideos = videos?.filter(video => {
    return searchQuery === "" || 
      video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (video.description && video.description.toLowerCase().includes(searchQuery.toLowerCase()));
  });
  
  return (
    <>
      <Helmet>
        <title>Video Yönetimi | Admin</title>
      </Helmet>
      
      <AdminLayout title="Video Yönetimi">
        <div className="mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex w-full max-w-sm items-center space-x-2">
            <Input
              placeholder="Video ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full"
              prefix={<Search className="h-4 w-4 text-gray-400" />}
            />
          </div>
          <Button onClick={handleCreateVideo}>
            <PlusCircle className="h-4 w-4 mr-2" />
            Video Ekle
          </Button>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Videolar</CardTitle>
            <CardDescription>
              Platform üzerindeki tüm videoları yönetin
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-secondary" />
              </div>
            ) : filteredVideos && filteredVideos.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredVideos.map((video) => {
                  const videoId = extractYouTubeID(video.filePath);
                  const thumbnailUrl = videoId ? getYouTubeThumbnail(videoId) : null;
                  
                  return (
                    <div key={video.id} className="bg-white rounded-lg overflow-hidden shadow-md">
                      <div className="relative aspect-video">
                        {thumbnailUrl ? (
                          <img 
                            src={thumbnailUrl} 
                            alt={video.title} 
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                            <span className="text-gray-400">Önizleme Yok</span>
                          </div>
                        )}
                      </div>
                      <div className="p-4">
                        <h3 className="text-lg font-semibold mb-2">{video.title}</h3>
                        {video.description && (
                          <p className="text-gray-600 mb-4 text-sm line-clamp-2">{video.description}</p>
                        )}
                        <div className="flex justify-between items-center">
                          <a 
                            href={video.filePath} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-blue-600 text-sm flex items-center hover:underline"
                          >
                            <ExternalLink className="h-4 w-4 mr-1" />
                            Videoyu Aç
                          </a>
                          <div className="flex space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditVideo(video)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteVideo(video)}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">Video bulunamadı</p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Create Video Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Yeni Video Ekle</DialogTitle>
              <DialogDescription>
                Yeni bir video eklemek için aşağıdaki formu doldurun.
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <label htmlFor="title" className="text-sm font-medium">Başlık</label>
                  <Input
                    id="title"
                    placeholder="Video başlığı"
                    {...createForm.register("title")}
                  />
                  {createForm.formState.errors.title && (
                    <p className="text-sm text-red-500">{createForm.formState.errors.title.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="description" className="text-sm font-medium">Açıklama (opsiyonel)</label>
                  <Textarea
                    id="description"
                    placeholder="Video açıklaması"
                    rows={3}
                    {...createForm.register("description")}
                  />
                  {createForm.formState.errors.description && (
                    <p className="text-sm text-red-500">{createForm.formState.errors.description.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="filePath" className="text-sm font-medium">YouTube Video URL</label>
                  <Input
                    id="filePath"
                    placeholder="https://www.youtube.com/watch?v=..."
                    {...createForm.register("filePath")}
                  />
                  <p className="text-xs text-gray-500">
                    YouTube video bağlantısını girin (https://www.youtube.com/watch?v=... formatında)
                  </p>
                  {createForm.formState.errors.filePath && (
                    <p className="text-sm text-red-500">{createForm.formState.errors.filePath.message}</p>
                  )}
                </div>
                
                {videoPreview && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Önizleme</label>
                    <div className="aspect-video bg-gray-100 rounded-md overflow-hidden">
                      <img 
                        src={videoPreview} 
                        alt="Video önizleme" 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                )}
                
                <div className="space-y-2">
                  <label htmlFor="eventId" className="text-sm font-medium">İlişkili Etkinlik (opsiyonel)</label>
                  <Select
                    onValueChange={(value) => createForm.setValue("eventId", value ? parseInt(value) : undefined)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Etkinlik seçin (opsiyonel)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Etkinlik seçilmedi</SelectItem>
                      {events?.map((event) => (
                        <SelectItem key={event.id} value={event.id.toString()}>
                          {event.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  İptal
                </Button>
                <Button 
                  type="submit" 
                  disabled={createVideoMutation.isPending}
                >
                  {createVideoMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Ekleniyor...
                    </>
                  ) : (
                    "Video Ekle"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        {/* Edit Video Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Video Düzenle</DialogTitle>
              <DialogDescription>
                Video bilgilerini güncelleyin.
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <label htmlFor="edit-title" className="text-sm font-medium">Başlık</label>
                  <Input
                    id="edit-title"
                    placeholder="Video başlığı"
                    {...editForm.register("title")}
                  />
                  {editForm.formState.errors.title && (
                    <p className="text-sm text-red-500">{editForm.formState.errors.title.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="edit-description" className="text-sm font-medium">Açıklama (opsiyonel)</label>
                  <Textarea
                    id="edit-description"
                    placeholder="Video açıklaması"
                    rows={3}
                    {...editForm.register("description")}
                  />
                  {editForm.formState.errors.description && (
                    <p className="text-sm text-red-500">{editForm.formState.errors.description.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="edit-filePath" className="text-sm font-medium">YouTube Video URL</label>
                  <Input
                    id="edit-filePath"
                    placeholder="https://www.youtube.com/watch?v=..."
                    {...editForm.register("filePath")}
                  />
                  {editForm.formState.errors.filePath && (
                    <p className="text-sm text-red-500">{editForm.formState.errors.filePath.message}</p>
                  )}
                </div>
                
                {videoPreview && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Önizleme</label>
                    <div className="aspect-video bg-gray-100 rounded-md overflow-hidden">
                      <img 
                        src={videoPreview} 
                        alt="Video önizleme" 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                )}
                
                <div className="space-y-2">
                  <label htmlFor="edit-eventId" className="text-sm font-medium">İlişkili Etkinlik (opsiyonel)</label>
                  <Select
                    defaultValue={selectedVideo?.eventId?.toString()}
                    onValueChange={(value) => editForm.setValue("eventId", value ? parseInt(value) : undefined)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Etkinlik seçin (opsiyonel)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Etkinlik seçilmedi</SelectItem>
                      {events?.map((event) => (
                        <SelectItem key={event.id} value={event.id.toString()}>
                          {event.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  İptal
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateVideoMutation.isPending}
                >
                  {updateVideoMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Güncelleniyor...
                    </>
                  ) : (
                    "Güncelle"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Videoyu Sil</DialogTitle>
              <DialogDescription>
                Bu videoyu silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
              </DialogDescription>
            </DialogHeader>
            
            {selectedVideo && (
              <div className="py-4">
                <p className="font-medium">{selectedVideo.title}</p>
              </div>
            )}
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsDeleteDialogOpen(false)}
              >
                İptal
              </Button>
              <Button 
                type="button" 
                variant="destructive" 
                onClick={confirmDelete}
                disabled={deleteVideoMutation.isPending}
              >
                {deleteVideoMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Siliniyor...
                  </>
                ) : (
                  "Evet, Sil"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </AdminLayout>
    </>
  );
}
