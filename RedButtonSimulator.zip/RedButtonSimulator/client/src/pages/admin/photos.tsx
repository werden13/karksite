import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Loader2, PlusCircle, Edit, Trash2, Search, Image, FolderPlus } from "lucide-react";
import { MediaItem, Album, Event, InsertMediaItem, InsertAlbum, insertMediaItemSchema, insertAlbumSchema } from "@shared/schema";
import { formatDate } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Helmet } from "react-helmet";
import ImageUrlHelper from "@/components/admin/ImageUrlHelper";
import ImageWithFallback from "@/components/ImageWithFallback";

export default function AdminPhotos() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState<string>("albums");
  const [isAlbumDialogOpen, setIsAlbumDialogOpen] = useState(searchParams.has("new"));
  const [isPhotoDialogOpen, setIsPhotoDialogOpen] = useState(false);
  const [isEditAlbumDialogOpen, setIsEditAlbumDialogOpen] = useState(false);
  const [isDeleteAlbumDialogOpen, setIsDeleteAlbumDialogOpen] = useState(false);
  const [isDeletePhotoDialogOpen, setIsDeletePhotoDialogOpen] = useState(false);
  const [selectedAlbum, setSelectedAlbum] = useState<Album | null>(null);
  const [selectedPhoto, setSelectedPhoto] = useState<MediaItem | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewAlbumId, setViewAlbumId] = useState<number | null>(null);
  
  const { data: albums, isLoading: isLoadingAlbums } = useQuery<Album[]>({
    queryKey: ["/api/albums"],
  });
  
  const { data: events } = useQuery({
    queryKey: ["/api/events"],
  });
  
  const { data: photos, isLoading: isLoadingPhotos } = useQuery<MediaItem[]>({
    queryKey: viewAlbumId ? [`/api/media?type=photo&albumId=${viewAlbumId}`] : ["/api/media?type=photo"],
  });
  
  // Album form schema
  const albumSchema = insertAlbumSchema.extend({});
  
  // Photo form schema with URL validation
  const photoSchema = insertMediaItemSchema.extend({
    filePath: z.string().url("Geçerli bir URL giriniz"),
    thumbnailPath: z.string().url("Geçerli bir URL giriniz").optional(),
  });
  
  // Create album form
  const albumForm = useForm<z.infer<typeof albumSchema>>({
    resolver: zodResolver(albumSchema),
    defaultValues: {
      title: "",
      description: "",
      eventId: undefined,
    },
  });
  
  // Edit album form
  const editAlbumForm = useForm<z.infer<typeof albumSchema>>({
    resolver: zodResolver(albumSchema),
    defaultValues: {
      title: "",
      description: "",
      eventId: undefined,
    },
  });
  
  // Add photo form
  const photoForm = useForm<z.infer<typeof photoSchema>>({
    resolver: zodResolver(photoSchema),
    defaultValues: {
      title: "",
      description: "",
      mediaType: "photo",
      filePath: "",
      thumbnailPath: "",
      albumId: undefined,
      eventId: undefined,
    },
  });
  
  // Create album mutation
  const createAlbumMutation = useMutation({
    mutationFn: async (album: InsertAlbum) => {
      const res = await apiRequest("POST", "/api/albums", album);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Albüm oluşturuldu",
        description: "Albüm başarıyla oluşturuldu.",
      });
      setIsAlbumDialogOpen(false);
      albumForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/albums"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Albüm oluşturulurken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Update album mutation
  const updateAlbumMutation = useMutation({
    mutationFn: async ({ id, album }: { id: number; album: InsertAlbum }) => {
      const res = await apiRequest("PUT", `/api/albums/${id}`, album);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Albüm güncellendi",
        description: "Albüm başarıyla güncellendi.",
      });
      setIsEditAlbumDialogOpen(false);
      setSelectedAlbum(null);
      queryClient.invalidateQueries({ queryKey: ["/api/albums"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Albüm güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Delete album mutation
  const deleteAlbumMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/albums/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Albüm silindi",
        description: "Albüm başarıyla silindi.",
      });
      setIsDeleteAlbumDialogOpen(false);
      setSelectedAlbum(null);
      queryClient.invalidateQueries({ queryKey: ["/api/albums"] });
      if (selectedAlbum?.id === viewAlbumId) {
        setViewAlbumId(null);
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Albüm silinirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Add photo mutation
  const addPhotoMutation = useMutation({
    mutationFn: async (photo: InsertMediaItem) => {
      const res = await apiRequest("POST", "/api/media", photo);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Fotoğraf eklendi",
        description: "Fotoğraf başarıyla eklendi.",
      });
      setIsPhotoDialogOpen(false);
      photoForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/media?type=photo"] });
      if (viewAlbumId) {
        queryClient.invalidateQueries({ queryKey: [`/api/media?type=photo&albumId=${viewAlbumId}`] });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Fotoğraf eklenirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Delete photo mutation
  const deletePhotoMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/media/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Fotoğraf silindi",
        description: "Fotoğraf başarıyla silindi.",
      });
      setIsDeletePhotoDialogOpen(false);
      setSelectedPhoto(null);
      queryClient.invalidateQueries({ queryKey: ["/api/media?type=photo"] });
      if (viewAlbumId) {
        queryClient.invalidateQueries({ queryKey: [`/api/media?type=photo&albumId=${viewAlbumId}`] });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Fotoğraf silinirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  function handleCreateAlbum() {
    setIsAlbumDialogOpen(true);
  }
  
  function handleEditAlbum(album: Album) {
    setSelectedAlbum(album);
    
    editAlbumForm.reset({
      title: album.title,
      description: album.description || "",
      eventId: album.eventId,
    });
    
    setIsEditAlbumDialogOpen(true);
  }
  
  function handleDeleteAlbum(album: Album) {
    setSelectedAlbum(album);
    setIsDeleteAlbumDialogOpen(true);
  }
  
  function handleAddPhoto(albumId?: number) {
    photoForm.reset({
      title: "",
      description: "",
      mediaType: "photo",
      filePath: "",
      thumbnailPath: "",
      albumId: albumId,
      eventId: undefined,
    });
    
    setIsPhotoDialogOpen(true);
  }
  
  function handleDeletePhoto(photo: MediaItem) {
    setSelectedPhoto(photo);
    setIsDeletePhotoDialogOpen(true);
  }
  
  function handleViewAlbum(albumId: number) {
    setViewAlbumId(albumId);
    // Change to photos tab when viewing an album
    setActiveTab("photos");
  }
  
  function handleBackToAlbums() {
    setViewAlbumId(null);
  }
  
  function onAlbumSubmit(data: z.infer<typeof albumSchema>) {
    createAlbumMutation.mutate(data);
  }
  
  function onEditAlbumSubmit(data: z.infer<typeof albumSchema>) {
    if (selectedAlbum) {
      updateAlbumMutation.mutate({ id: selectedAlbum.id, album: data });
    }
  }
  
  function onPhotoSubmit(data: z.infer<typeof photoSchema>) {
    addPhotoMutation.mutate({
      ...data,
      mediaType: "photo",
    });
  }
  
  function confirmDeleteAlbum() {
    if (selectedAlbum) {
      deleteAlbumMutation.mutate(selectedAlbum.id);
    }
  }
  
  function confirmDeletePhoto() {
    if (selectedPhoto) {
      deletePhotoMutation.mutate(selectedPhoto.id);
    }
  }
  
  // Filter albums
  const filteredAlbums = albums?.filter(album => {
    return searchQuery === "" || 
      album.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (album.description && album.description.toLowerCase().includes(searchQuery.toLowerCase()));
  });
  
  // Filter photos based on selected album and search query
  const filteredPhotos = photos?.filter(photo => {
    const matchesSearch = searchQuery === "" || 
      photo.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (photo.description && photo.description.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesAlbum = viewAlbumId ? photo.albumId === viewAlbumId : true;
    
    return matchesSearch && matchesAlbum;
  });
  
  // Get current album info if viewing specific album
  const currentAlbum = viewAlbumId && albums ? albums.find(album => album.id === viewAlbumId) : null;
  
  return (
    <>
      <Helmet>
        <title>Fotoğraf Yönetimi | Admin</title>
      </Helmet>
      
      <AdminLayout title={viewAlbumId ? `Albüm: ${currentAlbum?.title || ''}` : "Fotoğraf Yönetimi"}>
        <div className="mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex w-full max-w-sm items-center space-x-2">
            <Input
              placeholder={viewAlbumId ? "Fotoğraf ara..." : "Albüm ara..."}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full"
              prefix={<Search className="h-4 w-4 text-gray-400" />}
            />
          </div>
          
          {viewAlbumId ? (
            <div className="flex space-x-3">
              <Button variant="outline" onClick={handleBackToAlbums}>
                Albümlere Dön
              </Button>
              <Button onClick={() => handleAddPhoto(viewAlbumId)}>
                <PlusCircle className="h-4 w-4 mr-2" />
                Fotoğraf Ekle
              </Button>
            </div>
          ) : (
            <div className="flex space-x-3">
              <Button variant={activeTab === "photos" ? "default" : "outline"} onClick={() => setActiveTab("photos")}>
                <Image className="h-4 w-4 mr-2" />
                Fotoğraflar
              </Button>
              <Button variant={activeTab === "albums" ? "default" : "outline"} onClick={() => setActiveTab("albums")}>
                <FolderPlus className="h-4 w-4 mr-2" />
                Albümler
              </Button>
              {activeTab === "albums" ? (
                <Button onClick={handleCreateAlbum}>
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Albüm Ekle
                </Button>
              ) : (
                <Button onClick={() => handleAddPhoto()}>
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Fotoğraf Ekle
                </Button>
              )}
            </div>
          )}
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className={viewAlbumId ? "hidden" : ""}>
          <TabsContent value="albums">
            <Card>
              <CardHeader>
                <CardTitle>Albümler</CardTitle>
                <CardDescription>
                  Fotoğraf albümlerini yönetin
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingAlbums ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-secondary" />
                  </div>
                ) : filteredAlbums && filteredAlbums.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Başlık</TableHead>
                        <TableHead>Açıklama</TableHead>
                        <TableHead>Etkinlik</TableHead>
                        <TableHead>Fotoğraf Sayısı</TableHead>
                        <TableHead className="text-right">İşlemler</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredAlbums.map((album) => {
                        const albumPhotos = photos?.filter(p => p.albumId === album.id) || [];
                        const albumEvent = events?.find(e => e.id === album.eventId);
                        
                        return (
                          <TableRow key={album.id}>
                            <TableCell className="font-medium">
                              <Button 
                                variant="link" 
                                onClick={() => handleViewAlbum(album.id)}
                                className="p-0 h-auto font-medium text-left"
                              >
                                {album.title}
                              </Button>
                            </TableCell>
                            <TableCell>
                              {album.description && album.description.length > 30
                                ? `${album.description.substring(0, 30)}...`
                                : album.description}
                            </TableCell>
                            <TableCell>{albumEvent?.title || "-"}</TableCell>
                            <TableCell>{albumPhotos.length}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleEditAlbum(album)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDeleteAlbum(album)}
                                >
                                  <Trash2 className="h-4 w-4 text-red-500" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Albüm bulunamadı</p>
                    <Button 
                      variant="outline" 
                      className="mt-4" 
                      onClick={handleCreateAlbum}
                    >
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Albüm Ekle
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="photos">
            <Card>
              <CardHeader>
                <CardTitle>{viewAlbumId ? `${currentAlbum?.title} Fotoğrafları` : "Tüm Fotoğraflar"}</CardTitle>
                <CardDescription>
                  {viewAlbumId ? currentAlbum?.description : "Platform üzerindeki tüm fotoğrafları yönetin"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingPhotos ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-secondary" />
                  </div>
                ) : filteredPhotos && filteredPhotos.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {filteredPhotos.map((photo) => (
                      <div key={photo.id} className="bg-white rounded-lg overflow-hidden shadow-md">
                        <div className="relative aspect-square">
                          <img 
                            src={photo.filePath} 
                            alt={photo.title} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="p-4">
                          <h3 className="text-lg font-semibold mb-2 truncate">{photo.title}</h3>
                          {photo.description && (
                            <p className="text-gray-600 mb-4 text-sm line-clamp-2">{photo.description}</p>
                          )}
                          <div className="flex justify-between items-center">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-red-500"
                              onClick={() => handleDeletePhoto(photo)}
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Sil
                            </Button>
                            <a 
                              href={photo.filePath} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-blue-600 text-sm hover:underline"
                            >
                              Görüntüle
                            </a>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Fotoğraf bulunamadı</p>
                    <Button 
                      variant="outline" 
                      className="mt-4" 
                      onClick={() => handleAddPhoto(viewAlbumId || undefined)}
                    >
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Fotoğraf Ekle
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        {/* Album content if viewing a specific album */}
        {viewAlbumId && (
          <Card>
            <CardHeader>
              <CardTitle>{currentAlbum?.title} Fotoğrafları</CardTitle>
              <CardDescription>
                {currentAlbum?.description}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingPhotos ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-secondary" />
                </div>
              ) : filteredPhotos && filteredPhotos.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {filteredPhotos.map((photo) => (
                    <div key={photo.id} className="bg-white rounded-lg overflow-hidden shadow-md">
                      <div className="relative aspect-square">
                        <ImageWithFallback 
                          src={photo.filePath} 
                          alt={photo.title} 
                          className="w-full h-full object-cover"
                          fallbackClassName="w-full h-full"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="text-lg font-semibold mb-2 truncate">{photo.title}</h3>
                        {photo.description && (
                          <p className="text-gray-600 mb-4 text-sm line-clamp-2">{photo.description}</p>
                        )}
                        <div className="flex justify-between items-center">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-red-500"
                            onClick={() => handleDeletePhoto(photo)}
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Sil
                          </Button>
                          <a 
                            href={photo.filePath} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-blue-600 text-sm hover:underline"
                          >
                            Görüntüle
                          </a>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">Bu albümde henüz fotoğraf yok</p>
                  <Button 
                    variant="outline" 
                    className="mt-4" 
                    onClick={() => handleAddPhoto(viewAlbumId)}
                  >
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Fotoğraf Ekle
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}
        
        {/* Create Album Dialog */}
        <Dialog open={isAlbumDialogOpen} onOpenChange={setIsAlbumDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Yeni Albüm Ekle</DialogTitle>
              <DialogDescription>
                Yeni bir fotoğraf albümü oluşturmak için aşağıdaki formu doldurun.
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={albumForm.handleSubmit(onAlbumSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <label htmlFor="title" className="text-sm font-medium">Başlık</label>
                  <Input
                    id="title"
                    placeholder="Albüm başlığı"
                    {...albumForm.register("title")}
                  />
                  {albumForm.formState.errors.title && (
                    <p className="text-sm text-red-500">{albumForm.formState.errors.title.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="description" className="text-sm font-medium">Açıklama (opsiyonel)</label>
                  <Textarea
                    id="description"
                    placeholder="Albüm açıklaması"
                    rows={3}
                    {...albumForm.register("description")}
                  />
                  {albumForm.formState.errors.description && (
                    <p className="text-sm text-red-500">{albumForm.formState.errors.description.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="eventId" className="text-sm font-medium">İlişkili Etkinlik (opsiyonel)</label>
                  <Select
                    onValueChange={(value) => albumForm.setValue("eventId", value ? parseInt(value) : undefined)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Etkinlik seçin (opsiyonel)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Etkinlik seçilmedi</SelectItem>
                      {events?.map((event) => (
                        <SelectItem key={event.id} value={event.id.toString()}>
                          {event.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAlbumDialogOpen(false)}
                >
                  İptal
                </Button>
                <Button 
                  type="submit" 
                  disabled={createAlbumMutation.isPending}
                >
                  {createAlbumMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Oluşturuluyor...
                    </>
                  ) : (
                    "Albüm Oluştur"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        {/* Edit Album Dialog */}
        <Dialog open={isEditAlbumDialogOpen} onOpenChange={setIsEditAlbumDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Albüm Düzenle</DialogTitle>
              <DialogDescription>
                Albüm bilgilerini güncelleyin.
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={editAlbumForm.handleSubmit(onEditAlbumSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <label htmlFor="edit-title" className="text-sm font-medium">Başlık</label>
                  <Input
                    id="edit-title"
                    placeholder="Albüm başlığı"
                    {...editAlbumForm.register("title")}
                  />
                  {editAlbumForm.formState.errors.title && (
                    <p className="text-sm text-red-500">{editAlbumForm.formState.errors.title.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="edit-description" className="text-sm font-medium">Açıklama (opsiyonel)</label>
                  <Textarea
                    id="edit-description"
                    placeholder="Albüm açıklaması"
                    rows={3}
                    {...editAlbumForm.register("description")}
                  />
                  {editAlbumForm.formState.errors.description && (
                    <p className="text-sm text-red-500">{editAlbumForm.formState.errors.description.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="edit-eventId" className="text-sm font-medium">İlişkili Etkinlik (opsiyonel)</label>
                  <Select
                    defaultValue={selectedAlbum?.eventId?.toString()}
                    onValueChange={(value) => editAlbumForm.setValue("eventId", value ? parseInt(value) : undefined)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Etkinlik seçin (opsiyonel)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Etkinlik seçilmedi</SelectItem>
                      {events?.map((event) => (
                        <SelectItem key={event.id} value={event.id.toString()}>
                          {event.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditAlbumDialogOpen(false)}
                >
                  İptal
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateAlbumMutation.isPending}
                >
                  {updateAlbumMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Güncelleniyor...
                    </>
                  ) : (
                    "Güncelle"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        {/* Add Photo Dialog */}
        <Dialog open={isPhotoDialogOpen} onOpenChange={setIsPhotoDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Fotoğraf Ekle</DialogTitle>
              <DialogDescription>
                Yeni bir fotoğraf eklemek için aşağıdaki formu doldurun.
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={photoForm.handleSubmit(onPhotoSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <label htmlFor="photo-title" className="text-sm font-medium">Başlık</label>
                  <Input
                    id="photo-title"
                    placeholder="Fotoğraf başlığı"
                    {...photoForm.register("title")}
                  />
                  {photoForm.formState.errors.title && (
                    <p className="text-sm text-red-500">{photoForm.formState.errors.title.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="photo-description" className="text-sm font-medium">Açıklama (opsiyonel)</label>
                  <Textarea
                    id="photo-description"
                    placeholder="Fotoğraf açıklaması"
                    rows={3}
                    {...photoForm.register("description")}
                  />
                  {photoForm.formState.errors.description && (
                    <p className="text-sm text-red-500">{photoForm.formState.errors.description.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label htmlFor="photo-filePath" className="text-sm font-medium">Fotoğraf URL</label>
                    <ImageUrlHelper />
                  </div>
                  <Input
                    id="photo-filePath"
                    placeholder="https://example.com/photo.jpg"
                    {...photoForm.register("filePath")}
                  />
                  <p className="text-xs text-gray-500">
                    Fotoğraf URL'sini girin (jpeg, jpg, png, webp formatında)
                  </p>
                  {photoForm.formState.errors.filePath && (
                    <p className="text-sm text-red-500">{photoForm.formState.errors.filePath.message}</p>
                  )}
                  {photoForm.watch("filePath") && (
                    <div className="mt-2">
                      <p className="text-xs text-muted-foreground mb-1">Önizleme:</p>
                      <ImageWithFallback
                        src={photoForm.watch("filePath")}
                        alt="Önizleme"
                        className="w-32 h-20 object-cover rounded border"
                        fallbackClassName="w-32 h-20 rounded border"
                      />
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="photo-thumbnailPath" className="text-sm font-medium">Küçük Resim URL (opsiyonel)</label>
                  <Input
                    id="photo-thumbnailPath"
                    placeholder="https://example.com/thumbnail.jpg"
                    {...photoForm.register("thumbnailPath")}
                  />
                  {photoForm.formState.errors.thumbnailPath && (
                    <p className="text-sm text-red-500">{photoForm.formState.errors.thumbnailPath.message}</p>
                  )}
                </div>
                
                {/* Only show album selection if not already in an album view */}
                {!viewAlbumId && (
                  <div className="space-y-2">
                    <label htmlFor="photo-albumId" className="text-sm font-medium">Albüm</label>
                    <Select
                      onValueChange={(value) => photoForm.setValue("albumId", value ? parseInt(value) : undefined)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Albüm seçin (opsiyonel)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Albüm seçilmedi</SelectItem>
                        {albums?.map((album) => (
                          <SelectItem key={album.id} value={album.id.toString()}>
                            {album.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                <div className="space-y-2">
                  <label htmlFor="photo-eventId" className="text-sm font-medium">İlişkili Etkinlik (opsiyonel)</label>
                  <Select
                    onValueChange={(value) => photoForm.setValue("eventId", value ? parseInt(value) : undefined)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Etkinlik seçin (opsiyonel)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Etkinlik seçilmedi</SelectItem>
                      {events?.map((event) => (
                        <SelectItem key={event.id} value={event.id.toString()}>
                          {event.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsPhotoDialogOpen(false)}
                >
                  İptal
                </Button>
                <Button 
                  type="submit" 
                  disabled={addPhotoMutation.isPending}
                >
                  {addPhotoMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Ekleniyor...
                    </>
                  ) : (
                    "Fotoğraf Ekle"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        {/* Delete Album Confirmation Dialog */}
        <Dialog open={isDeleteAlbumDialogOpen} onOpenChange={setIsDeleteAlbumDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Albümü Sil</DialogTitle>
              <DialogDescription>
                Bu albümü silmek istediğinizden emin misiniz? Bu işlem geri alınamaz ve albümdeki tüm fotoğrafları etkileyebilir.
              </DialogDescription>
            </DialogHeader>
            
            {selectedAlbum && (
              <div className="py-4">
                <p className="font-medium">{selectedAlbum.title}</p>
                <p className="text-sm text-gray-500">{selectedAlbum.description}</p>
              </div>
            )}
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsDeleteAlbumDialogOpen(false)}
              >
                İptal
              </Button>
              <Button 
                type="button" 
                variant="destructive" 
                onClick={confirmDeleteAlbum}
                disabled={deleteAlbumMutation.isPending}
              >
                {deleteAlbumMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Siliniyor...
                  </>
                ) : (
                  "Evet, Sil"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        {/* Delete Photo Confirmation Dialog */}
        <Dialog open={isDeletePhotoDialogOpen} onOpenChange={setIsDeletePhotoDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Fotoğrafı Sil</DialogTitle>
              <DialogDescription>
                Bu fotoğrafı silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
              </DialogDescription>
            </DialogHeader>
            
            {selectedPhoto && (
              <div className="py-4">
                <div className="relative aspect-video bg-gray-100 rounded-md overflow-hidden mb-3">
                  <img 
                    src={selectedPhoto.filePath} 
                    alt={selectedPhoto.title} 
                    className="w-full h-full object-contain"
                  />
                </div>
                <p className="font-medium">{selectedPhoto.title}</p>
              </div>
            )}
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsDeletePhotoDialogOpen(false)}
              >
                İptal
              </Button>
              <Button 
                type="button" 
                variant="destructive" 
                onClick={confirmDeletePhoto}
                disabled={deletePhotoMutation.isPending}
              >
                {deletePhotoMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Siliniyor...
                  </>
                ) : (
                  "Evet, Sil"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </AdminLayout>
    </>
  );
}
