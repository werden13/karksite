import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2, PlusCircle, Edit, Trash2, Search } from "lucide-react";
import { Event, InsertEvent, insertEventSchema } from "@shared/schema";
import { formatDate, getCategoryLabel } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Helmet } from "react-helmet";

export default function AdminEvents() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const { toast } = useToast();
  
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(searchParams.has("new"));
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  
  const { data: events, isLoading } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });
  
  // Create event schema with date validation
  const eventSchema = insertEventSchema.extend({
    date: z.string().refine(
      (date) => !isNaN(Date.parse(date)),
      { message: "Geçerli bir tarih giriniz" }
    ),
  });
  
  // Create event form
  const createForm = useForm<z.infer<typeof eventSchema>>({
    resolver: zodResolver(eventSchema),
    defaultValues: {
      title: "",
      description: "",
      date: new Date().toISOString().split("T")[0],
      location: "",
      category: "training",
      imagePath: "",
    },
  });
  
  // Edit event form
  const editForm = useForm<z.infer<typeof eventSchema>>({
    resolver: zodResolver(eventSchema),
    defaultValues: {
      title: "",
      description: "",
      date: new Date().toISOString().split("T")[0],
      location: "",
      category: "training",
      imagePath: "",
    },
  });
  
  // Check if there's an event to edit from URL
  useEffect(() => {
    const editId = searchParams.get("edit");
    if (editId && events) {
      const eventToEdit = events.find(e => e.id === parseInt(editId));
      if (eventToEdit) {
        handleEditEvent(eventToEdit);
      }
    }
  }, [events, searchParams]);
  
  // Create event mutation
  const createEventMutation = useMutation({
    mutationFn: async (event: InsertEvent) => {
      const res = await apiRequest("POST", "/api/events", event);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Etkinlik oluşturuldu",
        description: "Etkinlik başarıyla oluşturuldu.",
      });
      setIsCreateDialogOpen(false);
      createForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Etkinlik oluşturulurken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Update event mutation
  const updateEventMutation = useMutation({
    mutationFn: async ({ id, event }: { id: number; event: InsertEvent }) => {
      const res = await apiRequest("PUT", `/api/events/${id}`, event);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Etkinlik güncellendi",
        description: "Etkinlik başarıyla güncellendi.",
      });
      setIsEditDialogOpen(false);
      setSelectedEvent(null);
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Etkinlik güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Delete event mutation
  const deleteEventMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/events/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Etkinlik silindi",
        description: "Etkinlik başarıyla silindi.",
      });
      setIsDeleteDialogOpen(false);
      setSelectedEvent(null);
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Etkinlik silinirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  function handleCreateEvent() {
    setIsCreateDialogOpen(true);
  }
  
  function handleEditEvent(event: Event) {
    setSelectedEvent(event);
    
    // Format date for input field (YYYY-MM-DD)
    const formattedDate = new Date(event.date).toISOString().split("T")[0];
    
    editForm.reset({
      title: event.title,
      description: event.description,
      date: formattedDate,
      location: event.location,
      category: event.category,
      imagePath: event.imagePath || "",
    });
    
    setIsEditDialogOpen(true);
  }
  
  function handleDeleteEvent(event: Event) {
    setSelectedEvent(event);
    setIsDeleteDialogOpen(true);
  }
  
  function onCreateSubmit(data: z.infer<typeof eventSchema>) {
    // Convert date string to Date object
    const eventData = {
      ...data,
      date: new Date(data.date)
    };
    createEventMutation.mutate(eventData);
  }
  
  function onEditSubmit(data: z.infer<typeof eventSchema>) {
    if (selectedEvent) {
      // Convert date string to Date object
      const eventData = {
        ...data,
        date: new Date(data.date)
      };
      updateEventMutation.mutate({ id: selectedEvent.id, event: eventData });
    }
  }
  
  function confirmDelete() {
    if (selectedEvent) {
      deleteEventMutation.mutate(selectedEvent.id);
    }
  }
  
  // Filter events
  const filteredEvents = events?.filter(event => {
    const matchesSearch = searchQuery === "" || 
      event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.location.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === "all" || event.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  return (
    <>
      <Helmet>
        <title>Etkinlik Yönetimi | Admin</title>
      </Helmet>
      
      <AdminLayout title="Etkinlik Yönetimi">
        <div className="mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex w-full max-w-sm items-center space-x-2">
            <Input
              placeholder="Etkinlik ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full"
              prefix={<Search className="h-4 w-4 text-gray-400" />}
            />
            <Select 
              value={selectedCategory} 
              onValueChange={setSelectedCategory}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Kategori Seç" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tüm Kategoriler</SelectItem>
                <SelectItem value="rescue">Arama Kurtarma</SelectItem>
                <SelectItem value="training">Eğitim</SelectItem>
                <SelectItem value="donation">Bağış</SelectItem>
                <SelectItem value="awareness">Farkındalık</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleCreateEvent}>
            <PlusCircle className="h-4 w-4 mr-2" />
            Etkinlik Ekle
          </Button>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Etkinlikler</CardTitle>
            <CardDescription>
              Platform üzerindeki tüm etkinlikleri yönetin
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-secondary" />
              </div>
            ) : filteredEvents && filteredEvents.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Başlık</TableHead>
                    <TableHead>Tarih</TableHead>
                    <TableHead>Konum</TableHead>
                    <TableHead>Kategori</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEvents.map((event) => (
                    <TableRow key={event.id}>
                      <TableCell className="font-medium">{event.title}</TableCell>
                      <TableCell>{formatDate(event.date)}</TableCell>
                      <TableCell>{event.location}</TableCell>
                      <TableCell>{getCategoryLabel(event.category)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditEvent(event)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteEvent(event)}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">Etkinlik bulunamadı</p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Create Event Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Yeni Etkinlik Ekle</DialogTitle>
              <DialogDescription>
                Yeni bir etkinlik oluşturmak için aşağıdaki formu doldurun.
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <label htmlFor="title" className="text-sm font-medium">Başlık</label>
                  <Input
                    id="title"
                    placeholder="Etkinlik başlığı"
                    {...createForm.register("title")}
                  />
                  {createForm.formState.errors.title && (
                    <p className="text-sm text-red-500">{createForm.formState.errors.title.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="description" className="text-sm font-medium">Açıklama</label>
                  <Textarea
                    id="description"
                    placeholder="Etkinlik açıklaması"
                    rows={4}
                    {...createForm.register("description")}
                  />
                  {createForm.formState.errors.description && (
                    <p className="text-sm text-red-500">{createForm.formState.errors.description.message}</p>
                  )}
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="date" className="text-sm font-medium">Tarih</label>
                    <Input
                      id="date"
                      type="date"
                      {...createForm.register("date", {
                        setValueAs: (value) => value ? value.toString() : value
                      })}
                    />
                    {createForm.formState.errors.date && (
                      <p className="text-sm text-red-500">{createForm.formState.errors.date.message}</p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="category" className="text-sm font-medium">Kategori</label>
                    <Select 
                      defaultValue="training"
                      onValueChange={(value) => createForm.setValue("category", value as any)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Kategori seçin" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="rescue">Arama Kurtarma</SelectItem>
                        <SelectItem value="training">Eğitim</SelectItem>
                        <SelectItem value="donation">Bağış</SelectItem>
                        <SelectItem value="awareness">Farkındalık</SelectItem>
                      </SelectContent>
                    </Select>
                    {createForm.formState.errors.category && (
                      <p className="text-sm text-red-500">{createForm.formState.errors.category.message}</p>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="location" className="text-sm font-medium">Konum</label>
                  <Input
                    id="location"
                    placeholder="Etkinlik konumu"
                    {...createForm.register("location")}
                  />
                  {createForm.formState.errors.location && (
                    <p className="text-sm text-red-500">{createForm.formState.errors.location.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="imagePath" className="text-sm font-medium">Görsel URL (opsiyonel)</label>
                  <Input
                    id="imagePath"
                    placeholder="https://example.com/image.jpg"
                    {...createForm.register("imagePath")}
                  />
                  {createForm.formState.errors.imagePath && (
                    <p className="text-sm text-red-500">{createForm.formState.errors.imagePath.message}</p>
                  )}
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  İptal
                </Button>
                <Button 
                  type="submit" 
                  disabled={createEventMutation.isPending}
                >
                  {createEventMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Oluşturuluyor...
                    </>
                  ) : (
                    "Etkinlik Oluştur"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        {/* Edit Event Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Etkinlik Düzenle</DialogTitle>
              <DialogDescription>
                Etkinlik bilgilerini güncelleyin.
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <label htmlFor="edit-title" className="text-sm font-medium">Başlık</label>
                  <Input
                    id="edit-title"
                    placeholder="Etkinlik başlığı"
                    {...editForm.register("title")}
                  />
                  {editForm.formState.errors.title && (
                    <p className="text-sm text-red-500">{editForm.formState.errors.title.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="edit-description" className="text-sm font-medium">Açıklama</label>
                  <Textarea
                    id="edit-description"
                    placeholder="Etkinlik açıklaması"
                    rows={4}
                    {...editForm.register("description")}
                  />
                  {editForm.formState.errors.description && (
                    <p className="text-sm text-red-500">{editForm.formState.errors.description.message}</p>
                  )}
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="edit-date" className="text-sm font-medium">Tarih</label>
                    <Input
                      id="edit-date"
                      type="date"
                      {...editForm.register("date", {
                        setValueAs: (value) => value ? value.toString() : value
                      })}
                    />
                    {editForm.formState.errors.date && (
                      <p className="text-sm text-red-500">{editForm.formState.errors.date.message}</p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="edit-category" className="text-sm font-medium">Kategori</label>
                    <Select 
                      defaultValue={selectedEvent?.category}
                      onValueChange={(value) => editForm.setValue("category", value as any)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Kategori seçin" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="rescue">Arama Kurtarma</SelectItem>
                        <SelectItem value="training">Eğitim</SelectItem>
                        <SelectItem value="donation">Bağış</SelectItem>
                        <SelectItem value="awareness">Farkındalık</SelectItem>
                      </SelectContent>
                    </Select>
                    {editForm.formState.errors.category && (
                      <p className="text-sm text-red-500">{editForm.formState.errors.category.message}</p>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="edit-location" className="text-sm font-medium">Konum</label>
                  <Input
                    id="edit-location"
                    placeholder="Etkinlik konumu"
                    {...editForm.register("location")}
                  />
                  {editForm.formState.errors.location && (
                    <p className="text-sm text-red-500">{editForm.formState.errors.location.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="edit-imagePath" className="text-sm font-medium">Görsel URL (opsiyonel)</label>
                  <Input
                    id="edit-imagePath"
                    placeholder="https://example.com/image.jpg"
                    {...editForm.register("imagePath")}
                  />
                  {editForm.formState.errors.imagePath && (
                    <p className="text-sm text-red-500">{editForm.formState.errors.imagePath.message}</p>
                  )}
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  İptal
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateEventMutation.isPending}
                >
                  {updateEventMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Güncelleniyor...
                    </>
                  ) : (
                    "Güncelle"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        
        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Etkinliği Sil</DialogTitle>
              <DialogDescription>
                Bu etkinliği silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
              </DialogDescription>
            </DialogHeader>
            
            {selectedEvent && (
              <div className="py-4">
                <p className="font-medium">{selectedEvent.title}</p>
                <p className="text-sm text-gray-500">{formatDate(selectedEvent.date)}</p>
              </div>
            )}
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsDeleteDialogOpen(false)}
              >
                İptal
              </Button>
              <Button 
                type="button" 
                variant="destructive" 
                onClick={confirmDelete}
                disabled={deleteEventMutation.isPending}
              >
                {deleteEventMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Siliniyor...
                  </>
                ) : (
                  "Evet, Sil"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </AdminLayout>
    </>
  );
}
