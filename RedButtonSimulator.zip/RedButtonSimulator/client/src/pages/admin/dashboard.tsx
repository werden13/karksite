import { useQuery } from "@tanstack/react-query";
import AdminLayout from "@/components/admin/AdminLayout";
import DashboardCard from "@/components/admin/DashboardCard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Event, ContactMessage, User } from "@shared/schema";
import { formatRelativeTime } from "@/lib/utils";
import { Calendar, Ticket, Users, Mail, Clock, Film, Image, Ban, BarChart } from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function AdminDashboard() {
  const { data: events } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  const { data: contactMessages } = useQuery<ContactMessage[]>({
    queryKey: ["/api/contact"],
  });
  
  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
    refetchInterval: 10000, // Her 10 saniyede bir yenile
  });
  
  // Gerçek site trafiği verisini API'dan alıyoruz
  const { data: trafficData } = useQuery({
    queryKey: ["/api/analytics/traffic"],
    // Gerçek veri yoksa varsayılan veri kullanıyoruz
    placeholderData: [
      { gün: "Pazartesi", ziyaretçi: 120 },
      { gün: "Salı", ziyaretçi: 145 },
      { gün: "Çarşamba", ziyaretçi: 160 },
      { gün: "Perşembe", ziyaretçi: 130 },
      { gün: "Cuma", ziyaretçi: 200 },
      { gün: "Cumartesi", ziyaretçi: 220 },
      { gün: "Pazar", ziyaretçi: 170 },
    ],
  });

  const upcomingEvents = events
    ? events.filter(event => new Date(event.date) >= new Date()).slice(0, 5)
    : [];

  const recentMessages = contactMessages
    ? contactMessages.slice(0, 5)
    : [];
    
  // Yeni kayıt olan kullanıcılar (son 5 kullanıcı)
  const recentUsers = users
    ? [...users].sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      ).slice(0, 5)
    : [];

  const totalEvents = events?.length || 0;
  const totalUnreadMessages = contactMessages?.filter(msg => !msg.isRead).length || 0;
  const totalUsers = users?.length || 0;

  return (
    <>
      <Helmet>
        <title>Admin Dashboard | Etkinlik Platformu</title>
      </Helmet>
      
      <AdminLayout title="Yönetim Paneli">
        <div className="space-y-6">
          {/* Stats Cards */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <DashboardCard
              title="Toplam Etkinlik"
              value={totalEvents}
              icon={<Calendar className="h-4 w-4" />}
            />
            <DashboardCard
              title="Yaklaşan Etkinlikler"
              value={upcomingEvents.length}
              icon={<Ticket className="h-4 w-4" />}
            />
            <DashboardCard
              title="Kayıtlı Kullanıcılar"
              value={totalUsers.toString()}
              icon={<Users className="h-4 w-4" />}
            />
            <DashboardCard
              title="Okunmamış Mesajlar"
              value={totalUnreadMessages}
              icon={<Mail className="h-4 w-4" />}
            />
          </div>
          
          {/* Trafik Grafiği */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart className="h-5 w-5" />
                Site Trafiği
              </CardTitle>
              <CardDescription>
                Son 7 gündeki site ziyaretleri
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trafficData}>
                    <defs>
                      <linearGradient id="colorVisitors" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#f43f5e" stopOpacity={0.1}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="gün" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => [`${value} ziyaretçi`, 'Toplam']}
                      labelFormatter={(label) => `${label} günü`}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="ziyaretçi" 
                      stroke="#f43f5e" 
                      fillOpacity={1} 
                      fill="url(#colorVisitors)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Yaklaşan Etkinlikler */}
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Yaklaşan Etkinlikler</CardTitle>
                <CardDescription>
                  Önümüzdeki 30 gün içindeki etkinlikler
                </CardDescription>
              </CardHeader>
              <CardContent>
                {upcomingEvents.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Etkinlik Adı</TableHead>
                        <TableHead>Tarih</TableHead>
                        <TableHead>Kategori</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {upcomingEvents.map((event) => (
                        <TableRow key={event.id}>
                          <TableCell className="font-medium">
                            <Link href={`/admin/events?edit=${event.id}`} className="hover:underline">
                              {event.title}
                            </Link>
                          </TableCell>
                          <TableCell>{formatRelativeTime(event.date)}</TableCell>
                          <TableCell className="capitalize">{event.category}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <p className="text-center py-4 text-gray-500">
                    Yaklaşan etkinlik bulunmuyor
                  </p>
                )}
                <div className="mt-4 flex justify-end">
                  <Link href="/admin/events">
                    <Button variant="outline" size="sm">
                      Tümünü Gör
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Recent Messages */}
            <Card>
              <CardHeader>
                <CardTitle>Son Mesajlar</CardTitle>
                <CardDescription>
                  İletişim formundan gelen son mesajlar
                </CardDescription>
              </CardHeader>
              <CardContent>
                {recentMessages.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Gönderen</TableHead>
                        <TableHead>Konu</TableHead>
                        <TableHead>Tarih</TableHead>
                        <TableHead>Durum</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {recentMessages.map((message) => (
                        <TableRow key={message.id}>
                          <TableCell className="font-medium">{message.name}</TableCell>
                          <TableCell>{message.subject}</TableCell>
                          <TableCell>{formatRelativeTime(message.createdAt)}</TableCell>
                          <TableCell>
                            {message.isRead ? (
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                Okundu
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                Okunmadı
                              </span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <p className="text-center py-4 text-gray-500">
                    Henüz mesaj bulunmuyor
                  </p>
                )}
                <div className="mt-4 flex justify-end">
                  <Button variant="outline" size="sm">
                    Tümünü Gör
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>


          
          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Hızlı İşlemler</CardTitle>
              <CardDescription>Sık kullanılan işlemler</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Link href="/admin/events?new=true">
                  <Button variant="outline" className="w-full h-20 flex flex-col items-center justify-center">
                    <Calendar className="h-5 w-5 mb-1" />
                    <span>Etkinlik Ekle</span>
                  </Button>
                </Link>
                <Link href="/admin/videos?new=true">
                  <Button variant="outline" className="w-full h-20 flex flex-col items-center justify-center">
                    <Film className="h-5 w-5 mb-1" />
                    <span>Video Ekle</span>
                  </Button>
                </Link>
                <Link href="/admin/photos?new=true">
                  <Button variant="outline" className="w-full h-20 flex flex-col items-center justify-center">
                    <Image className="h-5 w-5 mb-1" />
                    <span>Albüm Ekle</span>
                  </Button>
                </Link>
                <Link href="/admin/team?new=true">
                  <Button variant="outline" className="w-full h-20 flex flex-col items-center justify-center">
                    <Users className="h-5 w-5 mb-1" />
                    <span>Ekip Üyesi Ekle</span>
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </AdminLayout>
    </>
  );
}
