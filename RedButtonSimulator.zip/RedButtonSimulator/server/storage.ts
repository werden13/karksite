import { 
  users, 
  events, 
  mediaItems, 
  albums, 
  teamMembers, 
  contactMessages, 
  settings,
  donationMethods,
  donationCampaigns,
  heroSliders,
  archiveItems,
  type User, 
  type InsertUser, 
  type Event, 
  type InsertEvent, 
  type MediaItem, 
  type InsertMediaItem, 
  type Album, 
  type InsertAlbum, 
  type TeamMember, 
  type InsertTeamMember,
  type HeroSlider,
  type InsertHeroSlider, 
  type ContactMessage, 
  type InsertContactMessage, 
  type Setting, 
  type InsertSetting,
  type DonationMethod,
  type InsertDonationMethod,
  type DonationCampaign,
  type InsertDonationCampaign,
  type ArchiveItem,
  type InsertArchiveItem
} from "@shared/schema";
import session from "express-session";
import { and, desc, eq, like, or, sql } from "drizzle-orm";
import { db, pool } from "./db";
import connectPg from "connect-pg-simple";

// Storage interface
export interface IStorage {
  // Auth
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  getAllAdmins(): Promise<User[]>;
  updateAdmin(id: number, data: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<void>;
  banUser(id: string): Promise<void>;
  unbanUser(id: string): Promise<void>;
  
  // Events
  getAllEvents(): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  getEventsByCategory(category: string): Promise<Event[]>;
  createEvent(event: InsertEvent & { createdBy: number }): Promise<Event>;
  updateEvent(id: number, event: InsertEvent): Promise<Event | undefined>;
  deleteEvent(id: number): Promise<void>;
  
  // Media
  getAllMedia(): Promise<MediaItem[]>;
  getMediaByType(type: string): Promise<MediaItem[]>;
  getMediaByEvent(eventId: number): Promise<MediaItem[]>;
  getAllVideos(): Promise<MediaItem[]>;
  getPhotosByAlbum(albumId: number): Promise<MediaItem[]>;
  createMediaItem(item: InsertMediaItem & { createdBy: number }): Promise<MediaItem>;
  deleteMediaItem(id: number): Promise<void>;
  
  // Albums
  getAllAlbums(): Promise<Album[]>;
  getAlbum(id: number): Promise<Album | undefined>;
  createAlbum(album: InsertAlbum & { createdBy: number }): Promise<Album>;
  updateAlbum(id: number, album: InsertAlbum): Promise<Album | undefined>;
  deleteAlbum(id: number): Promise<void>;
  
  // Team
  getAllTeamMembers(): Promise<TeamMember[]>;
  createTeamMember(member: InsertTeamMember & { createdBy: number }): Promise<TeamMember>;
  updateTeamMember(id: number, member: InsertTeamMember): Promise<TeamMember | undefined>;
  deleteTeamMember(id: number): Promise<void>;
  
  // Contact
  getAllContactMessages(): Promise<ContactMessage[]>;
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  markContactMessageAsRead(id: number): Promise<ContactMessage | undefined>;
  
  // Settings
  getAllSettings(): Promise<Setting[]>;
  getSetting(key: string): Promise<Setting | undefined>;
  updateSetting(key: string, value: string, userId: number): Promise<Setting>;
  
  // Donation Methods
  getAllDonationMethods(): Promise<DonationMethod[]>;
  getDonationMethod(id: number): Promise<DonationMethod | undefined>;
  createDonationMethod(method: InsertDonationMethod & { createdBy: number; updatedBy: number }): Promise<DonationMethod>;
  updateDonationMethod(id: number, method: InsertDonationMethod & { updatedBy: number }): Promise<DonationMethod | undefined>;
  deleteDonationMethod(id: number): Promise<void>;
  
  // Donation Campaigns
  getAllDonationCampaigns(): Promise<DonationCampaign[]>;
  getDonationCampaign(id: number): Promise<DonationCampaign | undefined>;
  createDonationCampaign(campaign: InsertDonationCampaign & { createdBy: number; updatedBy: number }): Promise<DonationCampaign>;
  updateDonationCampaign(id: number, campaign: InsertDonationCampaign & { updatedBy: number }): Promise<DonationCampaign | undefined>;
  deleteDonationCampaign(id: number): Promise<void>;
  
  // Hero Sliders
  getAllHeroSliders(): Promise<HeroSlider[]>;
  getActiveHeroSliders(): Promise<HeroSlider[]>;
  getHeroSlider(id: number): Promise<HeroSlider | undefined>;
  createHeroSlider(slider: InsertHeroSlider & { createdBy: number; updatedBy: number }): Promise<HeroSlider>;
  updateHeroSlider(id: number, slider: InsertHeroSlider & { updatedBy: number }): Promise<HeroSlider | undefined>;
  deleteHeroSlider(id: number): Promise<void>;
  updateHeroSliderOrder(sliderId: number, newOrder: number): Promise<void>;
  
  // Archive Items  
  getAllArchiveItems(): Promise<ArchiveItem[]>;
  getPublishedArchiveItems(): Promise<ArchiveItem[]>;
  getArchiveItem(id: number): Promise<ArchiveItem | undefined>;
  createArchiveItem(item: InsertArchiveItem & { createdBy: number; updatedBy: number }): Promise<ArchiveItem>;
  updateArchiveItem(id: number, item: InsertArchiveItem & { updatedBy: number }): Promise<ArchiveItem | undefined>;
  deleteArchiveItem(id: number): Promise<void>;
  toggleArchiveItemPublish(id: number, isPublished: boolean): Promise<ArchiveItem | undefined>;
  toggleArchiveItemFeatured(id: number, isFeatured: boolean): Promise<ArchiveItem | undefined>;
  incrementArchiveItemViews(id: number): Promise<void>;
  
  // Session store
  sessionStore: session.Store;
}

// Database implementation
export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    // Create a PostgreSQL session store
    const PostgreSQL = connectPg(session);
    this.sessionStore = new PostgreSQL({
      pool: pool,
      createTableIfMissing: true,
      tableName: 'sessions'
    });
  }

  // Auth
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Ensure we set default values for required fields if not provided
    const userData = {
      ...insertUser,
      isAdmin: insertUser.role === 'admin' || insertUser.role === 'major_admin',
      role: insertUser.role || 'user',
      permissions: insertUser.permissions || null
    };
    
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }
  
  async getAllAdmins(): Promise<User[]> {
    return db.select().from(users).where(eq(users.isAdmin, true));
  }
  
  async updateAdmin(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    console.log("Updating admin with ID:", id);
    console.log("Update data:", JSON.stringify(data));
    
    // Make sure isAdmin is set correctly based on role
    const isAdmin = data.role === 'admin' || data.role === 'major_admin';
    
    const [updatedUser] = await db
      .update(users)
      .set({
        ...data,
        isAdmin,
        // Make sure permissions is properly handled
        permissions: Array.isArray(data.permissions) ? data.permissions : []
      })
      .where(eq(users.id, id))
      .returning();
      
    console.log("Updated user:", JSON.stringify(updatedUser));
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }
  
  async banUser(id: string): Promise<void> {
    // Güvenlik için önce kullanıcıyı bulalım
    const numericId = parseInt(id);
    const [user] = await db.select().from(users).where(eq(users.id, numericId));
    
    if (!user) {
      throw new Error("Kullanıcı bulunamadı");
    }
    
    // Major admin kullanıcıları banlanamaz
    if (user.role === 'major_admin') {
      throw new Error("Major admin kullanıcılar banlanamaz");
    }
    
    console.log(`Banlama işlemi başlatıldı: ${user.username} (ID: ${numericId})`);
    
    // Kullanıcıyı 'banned' rolüne güncelle
    await db.update(users)
      .set({ 
        role: 'banned', 
        isAdmin: false 
      })
      .where(eq(users.id, numericId));
      
    console.log(`Kullanıcı başarıyla banlandı: ${user.username} (ID: ${numericId})`);
    
    // Oturumları temizleyelim (pg-session-store kullanıyoruz)
    try {
      if (pool) {
        // Kullanıcının aktif oturumlarını sil
        await pool.query(`
          DELETE FROM sessions 
          WHERE sess::jsonb->'passport'->>'user' = $1
        `, [numericId.toString()]);
        console.log(`Kullanıcının oturumları silindi: ${user.username}`);
      }
    } catch (error) {
      console.error("Oturumları silerken hata:", error);
      // Ana işlevi etkilememesi için hata fırlatmıyoruz
    }
  }
  
  async unbanUser(id: string): Promise<void> {
    // Güvenlik için önce kullanıcıyı bulalım
    const numericId = parseInt(id);
    const [user] = await db.select().from(users).where(eq(users.id, numericId));
    
    if (!user) {
      throw new Error("Kullanıcı bulunamadı");
    }
    
    // Eğer zaten banlanmamışsa hata fırlatma
    if (user.role !== 'banned') {
      throw new Error("Bu kullanıcı zaten banlanmamış");
    }
    
    console.log(`Ban kaldırma işlemi başlatıldı: ${user.username} (ID: ${numericId})`);
    
    // Kullanıcının yasağını kaldır ve 'user' rolüne geri döndür
    await db.update(users)
      .set({ 
        role: 'user', 
        isAdmin: false // Yasağı kaldırınca normal kullanıcı olarak kalsın
      })
      .where(eq(users.id, numericId));
      
    console.log(`Kullanıcı yasağı başarıyla kaldırıldı: ${user.username} (ID: ${numericId})`);
      
    // Şimdi sessions tablosundan bu kullanıcının aktif oturumlarını silelim
    // Böylece oturumu kapatılacak ve yeniden giriş yapması gerekecek
    try {
      await pool.query('DELETE FROM sessions WHERE sess::json->>\'passport\'::text IS NOT NULL AND (sess::json->>\'passport\')::json->>\'user\' = $1', [numericId.toString()]);
    } catch (error) {
      console.error("Kullanıcının oturumları silinirken hata:", error);
      // Ana işlevi etkilememesi için hata fırlatmıyoruz
    }
  }

  // Events
  async getAllEvents(): Promise<Event[]> {
    try {
      // Add logging to track if events are being retrieved correctly
      console.log("Retrieving all events from database");
      const result = await db.select().from(events).orderBy(desc(events.date));
      console.log(`Retrieved ${result.length} events from database`);
      return result;
    } catch (error) {
      console.error("Error retrieving events:", error);
      // Return empty array instead of throwing to prevent application crashes
      return [];
    }
  }

  async getEvent(id: number): Promise<Event | undefined> {
    try {
      const [event] = await db.select().from(events).where(eq(events.id, id));
      return event;
    } catch (error) {
      console.error(`Error retrieving event with ID ${id}:`, error);
      return undefined;
    }
  }

  async getEventsByCategory(category: string): Promise<Event[]> {
    return db.select()
      .from(events)
      .where(and(
        eq(events.category as any, category)
      ))
      .orderBy(desc(events.date));
  }

  async createEvent(event: InsertEvent & { createdBy: number }): Promise<Event> {
    try {
      console.log("Inserting event into database:", JSON.stringify(event));
      
      // Ensure date is properly formatted
      const eventData = {
        ...event,
        date: event.date instanceof Date ? event.date : new Date(event.date)
      };
      
      const [newEvent] = await db.insert(events).values(eventData).returning();
      console.log("Successfully created event:", JSON.stringify(newEvent));
      return newEvent;
    } catch (error) {
      console.error("Database error creating event:", error);
      throw error;
    }
  }

  async updateEvent(id: number, event: InsertEvent): Promise<Event | undefined> {
    try {
      console.log(`Updating event with ID ${id}:`, JSON.stringify(event));
      
      // Ensure date is properly formatted
      const eventData = {
        ...event,
        date: event.date instanceof Date ? event.date : new Date(event.date)
      };
      
      const [updatedEvent] = await db
        .update(events)
        .set(eventData)
        .where(eq(events.id, id))
        .returning();
      
      console.log("Event updated successfully:", JSON.stringify(updatedEvent));
      return updatedEvent;
    } catch (error) {
      console.error(`Error updating event with ID ${id}:`, error);
      throw error;
    }
  }

  async deleteEvent(id: number): Promise<void> {
    try {
      console.log(`Deleting event with ID ${id}`);
      
      // Get the event to log what's being deleted
      const eventToDelete = await this.getEvent(id);
      if (eventToDelete) {
        console.log("Deleting event:", JSON.stringify(eventToDelete));
      } else {
        console.log(`Event with ID ${id} not found for deletion`);
      }
      
      // Delete the event
      const result = await db.delete(events).where(eq(events.id, id));
      console.log(`Event deletion result:`, result);
      
      // Verify the event was deleted
      const checkEvent = await this.getEvent(id);
      if (!checkEvent) {
        console.log(`Event with ID ${id} successfully deleted`);
      } else {
        console.log(`Warning: Event with ID ${id} still exists after deletion attempt`);
      }
    } catch (error) {
      console.error(`Error deleting event with ID ${id}:`, error);
      throw error;
    }
  }

  // Media
  async getAllMedia(): Promise<MediaItem[]> {
    return db.select().from(mediaItems).orderBy(desc(mediaItems.createdAt));
  }

  async getMediaByType(type: string): Promise<MediaItem[]> {
    return db
      .select()
      .from(mediaItems)
      .where(and(
        eq(mediaItems.mediaType as any, type)
      ))
      .orderBy(desc(mediaItems.createdAt));
  }

  async getMediaByEvent(eventId: number): Promise<MediaItem[]> {
    return db
      .select()
      .from(mediaItems)
      .where(eq(mediaItems.eventId, eventId))
      .orderBy(desc(mediaItems.createdAt));
  }

  async getAllVideos(): Promise<MediaItem[]> {
    return this.getMediaByType('video');
  }

  async getPhotosByAlbum(albumId: number): Promise<MediaItem[]> {
    return db
      .select()
      .from(mediaItems)
      .where(and(
        eq(mediaItems.albumId, albumId),
        eq(mediaItems.mediaType, 'photo')
      ))
      .orderBy(desc(mediaItems.createdAt));
  }

  async createMediaItem(item: InsertMediaItem & { createdBy: number }): Promise<MediaItem> {
    const [newItem] = await db.insert(mediaItems).values(item).returning();
    return newItem;
  }

  async deleteMediaItem(id: number): Promise<void> {
    await db.delete(mediaItems).where(eq(mediaItems.id, id));
  }

  // Albums
  async getAllAlbums(): Promise<Album[]> {
    return db.select().from(albums).orderBy(desc(albums.createdAt));
  }

  async getAlbum(id: number): Promise<Album | undefined> {
    const [album] = await db.select().from(albums).where(eq(albums.id, id));
    return album;
  }

  async createAlbum(album: InsertAlbum & { createdBy: number }): Promise<Album> {
    const [newAlbum] = await db.insert(albums).values(album).returning();
    return newAlbum;
  }

  async updateAlbum(id: number, album: InsertAlbum): Promise<Album | undefined> {
    const [updatedAlbum] = await db
      .update(albums)
      .set(album)
      .where(eq(albums.id, id))
      .returning();
    return updatedAlbum;
  }

  async deleteAlbum(id: number): Promise<void> {
    await db.delete(albums).where(eq(albums.id, id));
  }

  // Team
  async getAllTeamMembers(): Promise<TeamMember[]> {
    return db.select().from(teamMembers);
  }

  async createTeamMember(member: InsertTeamMember & { createdBy: number }): Promise<TeamMember> {
    const [newMember] = await db.insert(teamMembers).values(member).returning();
    return newMember;
  }

  async updateTeamMember(id: number, member: InsertTeamMember): Promise<TeamMember | undefined> {
    const [updatedMember] = await db
      .update(teamMembers)
      .set(member)
      .where(eq(teamMembers.id, id))
      .returning();
    return updatedMember;
  }

  async deleteTeamMember(id: number): Promise<void> {
    await db.delete(teamMembers).where(eq(teamMembers.id, id));
  }

  // Contact
  async getAllContactMessages(): Promise<ContactMessage[]> {
    return db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt));
  }

  async createContactMessage(message: InsertContactMessage): Promise<ContactMessage> {
    const [newMessage] = await db.insert(contactMessages).values(message).returning();
    return newMessage;
  }

  async markContactMessageAsRead(id: number): Promise<ContactMessage | undefined> {
    const [updatedMessage] = await db
      .update(contactMessages)
      .set({ isRead: true })
      .where(eq(contactMessages.id, id))
      .returning();
    return updatedMessage;
  }

  // Settings
  async getAllSettings(): Promise<Setting[]> {
    return db.select().from(settings);
  }

  async getSetting(key: string): Promise<Setting | undefined> {
    const [setting] = await db.select().from(settings).where(eq(settings.key, key));
    return setting;
  }

  async updateSetting(key: string, value: string, userId: number): Promise<Setting> {
    const existingSetting = await this.getSetting(key);
    
    if (existingSetting) {
      const [updated] = await db
        .update(settings)
        .set({ value, updatedAt: new Date(), updatedBy: userId })
        .where(eq(settings.key, key))
        .returning();
      return updated;
    } else {
      const [newSetting] = await db
        .insert(settings)
        .values({ key, value, updatedBy: userId })
        .returning();
      return newSetting;
    }
  }

  // Donation Methods
  async getAllDonationMethods(): Promise<DonationMethod[]> {
    return db.select().from(donationMethods);
  }

  async getDonationMethod(id: number): Promise<DonationMethod | undefined> {
    const [method] = await db.select().from(donationMethods).where(eq(donationMethods.id, id));
    return method;
  }

  async createDonationMethod(method: InsertDonationMethod & { createdBy: number; updatedBy: number }): Promise<DonationMethod> {
    const [newMethod] = await db.insert(donationMethods).values(method).returning();
    return newMethod;
  }

  async updateDonationMethod(id: number, method: InsertDonationMethod & { updatedBy: number }): Promise<DonationMethod | undefined> {
    const [updatedMethod] = await db
      .update(donationMethods)
      .set({ ...method, updatedAt: new Date() })
      .where(eq(donationMethods.id, id))
      .returning();
    return updatedMethod;
  }

  async deleteDonationMethod(id: number): Promise<void> {
    await db.delete(donationMethods).where(eq(donationMethods.id, id));
  }

  // Donation Campaigns
  async getAllDonationCampaigns(): Promise<DonationCampaign[]> {
    return db.select().from(donationCampaigns).orderBy(desc(donationCampaigns.createdAt));
  }

  async getDonationCampaign(id: number): Promise<DonationCampaign | undefined> {
    const [campaign] = await db.select().from(donationCampaigns).where(eq(donationCampaigns.id, id));
    return campaign;
  }

  async createDonationCampaign(campaign: InsertDonationCampaign & { createdBy: number; updatedBy: number }): Promise<DonationCampaign> {
    const [newCampaign] = await db.insert(donationCampaigns).values(campaign).returning();
    return newCampaign;
  }

  async updateDonationCampaign(id: number, campaign: InsertDonationCampaign & { updatedBy: number }): Promise<DonationCampaign | undefined> {
    const [updatedCampaign] = await db
      .update(donationCampaigns)
      .set({ ...campaign, updatedAt: new Date() })
      .where(eq(donationCampaigns.id, id))
      .returning();
    return updatedCampaign;
  }

  async deleteDonationCampaign(id: number): Promise<void> {
    await db.delete(donationCampaigns).where(eq(donationCampaigns.id, id));
  }

  // Hero Sliders
  async getAllHeroSliders(): Promise<HeroSlider[]> {
    const sliders = await db.select().from(heroSliders).orderBy(heroSliders.order);
    return sliders;
  }
  
  async getActiveHeroSliders(): Promise<HeroSlider[]> {
    const sliders = await db.select().from(heroSliders)
      .where(eq(heroSliders.isActive, true))
      .orderBy(heroSliders.order);
    return sliders;
  }
  
  async getHeroSlider(id: number): Promise<HeroSlider | undefined> {
    const [slider] = await db.select().from(heroSliders).where(eq(heroSliders.id, id));
    return slider;
  }
  
  async createHeroSlider(slider: InsertHeroSlider & { createdBy: number; updatedBy: number }): Promise<HeroSlider> {
    // Mevcut tüm sliderları getir
    const allSliders = await this.getAllHeroSliders();
    
    // Eğer özel bir sıra belirtilmemişse, en sona ekle
    if (slider.order === undefined || slider.order === 0) {
      slider.order = allSliders.length > 0 ? allSliders[allSliders.length - 1].order + 1 : 1;
    }
    
    const [result] = await db.insert(heroSliders).values(slider).returning();
    return result;
  }
  
  async updateHeroSlider(id: number, slider: InsertHeroSlider & { updatedBy: number }): Promise<HeroSlider | undefined> {
    const [result] = await db.update(heroSliders)
      .set({ ...slider, updatedAt: new Date() })
      .where(eq(heroSliders.id, id))
      .returning();
    return result;
  }
  
  async deleteHeroSlider(id: number): Promise<void> {
    await db.delete(heroSliders)
      .where(eq(heroSliders.id, id));
      
    // Sliderlar silindiğinde sıralamayı düzelt
    const remainingSliders = await this.getAllHeroSliders();
    
    for (let i = 0; i < remainingSliders.length; i++) {
      await db.update(heroSliders)
        .set({ order: i + 1 })
        .where(eq(heroSliders.id, remainingSliders[i].id));
    }
  }
  
  async updateHeroSliderOrder(sliderId: number, newOrder: number): Promise<void> {
    // İlgili sliderı bul
    const slider = await this.getHeroSlider(sliderId);
    if (!slider) return;
    
    // Tüm sliderları getir
    const allSliders = await this.getAllHeroSliders();
    
    // Geçerli sıranın dışına çıkmasını önle
    const maxOrder = allSliders.length;
    if (newOrder < 1) newOrder = 1;
    if (newOrder > maxOrder) newOrder = maxOrder;
    
    // Sıralama görevini gerçekleştir
    const currentOrder = slider.order;
    
    if (currentOrder < newOrder) {
      // Aşağı taşıma: Aradaki slideları bir yukarı kaydır
      for (const s of allSliders) {
        if (s.order > currentOrder && s.order <= newOrder) {
          await db.update(heroSliders)
            .set({ order: s.order - 1 })
            .where(eq(heroSliders.id, s.id));
        }
      }
    } else if (currentOrder > newOrder) {
      // Yukarı taşıma: Aradaki slideları bir aşağı kaydır
      for (const s of allSliders) {
        if (s.order >= newOrder && s.order < currentOrder) {
          await db.update(heroSliders)
            .set({ order: s.order + 1 })
            .where(eq(heroSliders.id, s.id));
        }
      }
    }
    
    // Seçilen sliderı yeni sırasına yerleştir
    await db.update(heroSliders)
      .set({ order: newOrder })
      .where(eq(heroSliders.id, sliderId));
  }

  // Archive Items Methods
  async getAllArchiveItems(): Promise<ArchiveItem[]> {
    return await db.select().from(archiveItems).orderBy(desc(archiveItems.createdAt));
  }

  async getPublishedArchiveItems(): Promise<ArchiveItem[]> {
    return await db.select()
      .from(archiveItems)
      .where(eq(archiveItems.isPublished, true))
      .orderBy(desc(archiveItems.createdAt));
  }

  async getArchiveItem(id: number): Promise<ArchiveItem | undefined> {
    const [item] = await db.select()
      .from(archiveItems)
      .where(eq(archiveItems.id, id));
    return item;
  }

  async createArchiveItem(item: InsertArchiveItem & { createdBy: number; updatedBy: number }): Promise<ArchiveItem> {
    const [newItem] = await db.insert(archiveItems)
      .values({
        ...item,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();
    return newItem;
  }

  async updateArchiveItem(id: number, item: InsertArchiveItem & { updatedBy: number }): Promise<ArchiveItem | undefined> {
    const [updatedItem] = await db.update(archiveItems)
      .set({
        ...item,
        updatedAt: new Date(),
      })
      .where(eq(archiveItems.id, id))
      .returning();
    return updatedItem;
  }

  async deleteArchiveItem(id: number): Promise<void> {
    await db.delete(archiveItems).where(eq(archiveItems.id, id));
  }

  async toggleArchiveItemPublish(id: number, isPublished: boolean): Promise<ArchiveItem | undefined> {
    const [updatedItem] = await db.update(archiveItems)
      .set({ 
        isPublished,
        updatedAt: new Date(),
      })
      .where(eq(archiveItems.id, id))
      .returning();
    return updatedItem;
  }

  async toggleArchiveItemFeatured(id: number, isFeatured: boolean): Promise<ArchiveItem | undefined> {
    const [updatedItem] = await db.update(archiveItems)
      .set({ 
        isFeatured,
        updatedAt: new Date(),
      })
      .where(eq(archiveItems.id, id))
      .returning();
    return updatedItem;
  }

  async incrementArchiveItemViews(id: number): Promise<void> {
    await db.update(archiveItems)
      .set({ 
        viewCount: sql`${archiveItems.viewCount} + 1`,
      })
      .where(eq(archiveItems.id, id));
  }

  // Activities (for compatibility)
  async getActivities(): Promise<any[]> {
    // Return empty array as we use database, not JSON storage
    return [];
  }

  async saveActivities(activities: any[]): Promise<void> {
    // No-op for database storage
  }
}

// Use DatabaseStorage if DATABASE_URL is set, otherwise use JsonStorage
import { jsonStorage } from "./json-storage";

export const storage = process.env.DATABASE_URL 
  ? new DatabaseStorage() 
  : jsonStorage;
