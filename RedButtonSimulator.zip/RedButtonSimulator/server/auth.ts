import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser, insertUserSchema, adminLogs } from "@shared/schema";
import { db } from "./db";
import { z } from "zod";
import { trackLoginAttempt, recordFailedLogin, clearLoginAttempts } from "./middleware/security";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

export async function hashPassword(password: string) {
  // Use a stronger salt with 32 bytes for better security
  const salt = randomBytes(32).toString("hex");
  // Use scrypt with higher cost parameters for better security
  // N=16384 (2^14), r=8, p=1 are recommended parameters
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `scrypt:${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  // Check if stored password is a bcrypt hash
  if (stored.startsWith('$2b$') || stored.startsWith('$2a$')) {
    // Import bcrypt for proper password comparison
    const bcrypt = await import('bcryptjs');
    return bcrypt.compareSync(supplied, stored);
  }
  
  // Handle new scrypt format (scrypt:hash.salt)
  if (stored.startsWith('scrypt:')) {
    const passwordData = stored.substring(7); // Remove 'scrypt:' prefix
    if (!passwordData.includes('.')) {
      console.error('Password is not in expected format');
      return false;
    }
    
    try {
      const [hashed, salt] = passwordData.split(".");
      const hashedBuf = Buffer.from(hashed, "hex");
      const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
      return timingSafeEqual(hashedBuf, suppliedBuf);
    } catch (error) {
      console.error('Error comparing passwords:', error);
      return false;
    }
  }
  
  // Legacy scrypt passwords (format: hash.salt)
  if (!stored.includes('.')) {
    console.error('Password is not in expected format');
    return false;
  }
  
  try {
    const [hashed, salt] = stored.split(".");
    const hashedBuf = Buffer.from(hashed, "hex");
    const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
    return timingSafeEqual(hashedBuf, suppliedBuf);
  } catch (error) {
    console.error('Error comparing passwords:', error);
    return false;
  }
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "etkinlik-platformu-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        console.log(`Giriş denemesi: ${username}`);
        const user = await storage.getUserByUsername(username);
        
        // Kullanıcı bulunamadı veya şifre eşleşmiyor
        if (!user || !(await comparePasswords(password, user.password))) {
          console.log(`Giriş başarısız: ${username} - Geçersiz kullanıcı adı veya şifre`);
          // Record failed login attempt
          recordFailedLogin(username);
          return done(null, false, { message: "Geçersiz kullanıcı adı veya şifre" });
        } 
        
        // Kullanıcı banlanmış
        if (user.role === 'banned') {
          console.log(`Giriş reddedildi: ${username} - Bu hesap banlanmış`);
          return done(null, false, { message: "Bu hesap banlanmıştır. Giriş yapamazsınız." });
        }
        
        // Giriş başarılı - Clear login attempts
        console.log(`Giriş başarılı: ${username} (Rol: ${user.role})`);
        clearLoginAttempts(username);
        return done(null, user);
      } catch (error) {
        console.error(`Giriş hatası: ${username}`, error);
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      
      // Kullanıcı bulunamadıysa veya kullanıcı banlanmışsa oturumlarını sonlandır
      if (!user) {
        console.log(`Kullanıcı bulunamadı: ID ${id}`);
        return done(null, false);
      }
      
      if (user.role === 'banned') {
        console.log(`Banlanmış kullanıcı erişim denemesi: ${user.username} (ID: ${id})`);
        // Banlanmış kullanıcı için oturumu sonlandır
        return done(null, false);
      }
      
      // Kullanıcı aktif, oturumu devam etsin
      return done(null, user);
    } catch (error) {
      console.error(`Kullanıcı getirilirken hata: ID ${id}`, error);
      return done(error);
    }
  });

  // Extended registration schema with validation
  const registerSchema = insertUserSchema.extend({
    password: z.string()
      .min(8, "Şifre en az 8 karakter olmalıdır")
      .regex(/[A-Z]/, "Şifre en az bir büyük harf içermelidir")
      .regex(/[0-9]/, "Şifre en az bir rakam içermelidir")
      .regex(/[^a-zA-Z0-9]/, "Şifre en az bir özel karakter içermelidir"),
    confirmPassword: z.string(),
  })
  .refine(data => data.password === data.confirmPassword, {
    message: "Şifreler eşleşmiyor",
    path: ["confirmPassword"],
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      console.log("Registration request received:", req.body);
      
      // Extract only the fields we need
      const registrationData = {
        username: req.body.username,
        password: req.body.password,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        role: "user",
        permissions: null
      };
      
      if (req.body.confirmPassword) {
        // Verify password matches confirmation
        if (req.body.password !== req.body.confirmPassword) {
          return res.status(400).json({ message: "Şifreler eşleşmiyor" });
        }
      }
      
      // Validate the password rules manually
      const password = req.body.password;
      if (!password || password.length < 8) {
        return res.status(400).json({ message: "Şifre en az 8 karakter olmalıdır" });
      }
      if (!/[A-Z]/.test(password)) {
        return res.status(400).json({ message: "Şifre en az bir büyük harf içermelidir" });
      }
      if (!/[0-9]/.test(password)) {
        return res.status(400).json({ message: "Şifre en az bir rakam içermelidir" });
      }
      if (!/[^a-zA-Z0-9]/.test(password)) {
        return res.status(400).json({ message: "Şifre en az bir özel karakter içermelidir" });
      }
      
      // Check if required fields are present
      if (!registrationData.username || !registrationData.firstName || 
          !registrationData.lastName || !registrationData.email) {
        return res.status(400).json({ message: "Tüm alanları doldurmanız gerekiyor" });
      }
      
      // Check if username already exists
      const existingUserByUsername = await storage.getUserByUsername(registrationData.username);
      if (existingUserByUsername) {
        return res.status(400).json({ message: "Bu kullanıcı adı zaten kullanımda" });
      }
      
      // Create user with hashed password
      const user = await storage.createUser({
        username: registrationData.username,
        password: await hashPassword(registrationData.password),
        firstName: registrationData.firstName,
        lastName: registrationData.lastName,
        email: registrationData.email,
        role: "user",
        permissions: null
      });

      // Log in the user
      req.login(user, (loginErr: Error | null) => {
        if (loginErr) return next(loginErr);
        res.status(201).json(user);
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Kayıt sırasında bir hata oluştu" });
    }
  });

  app.post("/api/login", trackLoginAttempt, (req, res, next) => {
    // Check if the username is in the protected admin accounts list
    const { username } = req.body;
    
    // Import the security check function - use a dynamic import to avoid circular imports
    // First set default functions that will be replaced after dynamic import
    let isProtectedAccount = (username: string) => {
      return username === 'supermanager' || username === 'admin';
    };
    
    // First check if this is an admin account attempt
    if (username && typeof username === 'string') {
      // Get the user by username to check if it's an admin account
      storage.getUserByUsername(username)
        .then(existingUser => {
          // Check if this is an admin account
          if (existingUser && (existingUser.isAdmin || existingUser.role === 'major_admin' || existingUser.role === 'admin')) {
            // Admin account detected - this username is protected
            console.log(`Admin account detected: ${existingUser.username}`);
          }
          
          // Proceed with authentication
          authenticateUser();
        })
        .catch(err => {
          console.error("Error checking username:", err);
          authenticateUser();
        });
    } else {
      authenticateUser();
    }
    
    async function authenticateUser() {
      // Store client IP and user agent info outside the auth callback for access
      const ipAddress = req.headers['x-forwarded-for'] || req.socket.remoteAddress || req.ip || "unknown";
      const userAgent = req.headers['user-agent'] || "unknown";
      
      // Get all admins to find the supermanager
      let superManager = null;
      try {
        const admins = await storage.getAllAdmins();
        superManager = admins.find(admin => admin.role === 'major_admin') || admins[0];
      } catch (error) {
        console.error("Error finding superManager for logs:", error);
      }
      
      passport.authenticate("local", (err: Error | null, user: SelectUser | false, info: { message: string } | undefined) => {
        if (err) return next(err);
        
        if (!user) {
          // Record failed login attempt
          const identifier = username || req.ip || "unknown";
          recordFailedLogin(identifier);
          
          // If login failed and username was for a protected account, store it in session for jumpscare
          if (username && isProtectedAccount(username)) {
            // Set a flag in the session for the jumpscare redirect
            // Use session with indexer to avoid TypeScript errors
            (req.session as any).adminLoginAttempt = {
              username,
              timestamp: new Date().toISOString()
            };
            
            // Log the unauthorized access attempt with IP and device information
            if (superManager) {
              // Format IP address
              const formattedIp = Array.isArray(ipAddress) ? ipAddress[0] : String(ipAddress);
              
              // Use async function for inserting log to avoid awaiting directly here
              (async () => {
                try {
                  // Import logAdminAction dynamically to avoid circular imports
                  const { logAdminAction } = await import('./admin-logger.js');
                  
                  // Log the unauthorized access attempt
                  await logAdminAction(
                    superManager.id,
                    "Yetkisiz Giriş Denemesi",
                    `Korumalı admin hesabına başarısız giriş denemesi: ${username}`,
                    formattedIp,
                    String(userAgent),
                    "security",
                    "admin-login"
                  );
                  
                  console.log(`Security alert: Unauthorized admin access attempt logged for ${username} from IP ${formattedIp}`);
                } catch (err) {
                  console.error("Error saving security log:", err);
                }
              })();
            }
            
            // Return a special response code for the frontend to trigger jumpscare
            return res.status(403).json({ 
              message: "Unauthorized admin access attempt detected",
              securityAlert: true,
              username
            });
          }
          
          return res.status(401).json({ message: info?.message || "Geçersiz giriş bilgileri" });
        }
        
        req.login(user, (loginErr: Error | null) => {
          if (loginErr) return next(loginErr);
          
          // Clear login attempts on successful login
          const identifier = username || req.ip || "unknown";
          clearLoginAttempts(identifier);
          
          return res.status(200).json(user);
        });
      })(req, res, next);
    }
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
}
