import { Router } from "express";
import { storage } from "../storage";
import { z } from "zod";
import { logAdminAction } from "../admin-logger";
import { requireAdmin } from "../middleware/auth";

const router = Router();

interface Activity {
  id: number;
  title: string;
  description: string;
  category: string;
  imageUrl?: string | null;
  date?: string | null;
  link?: string | null;
  displayOrder: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  createdBy?: number | null;
  updatedBy?: number | null;
}

// Get all activities (public)
router.get("/", async (req, res) => {
  try {
    const activities = await storage.getActivities();
    const activeActivities = activities
      .filter(a => a.isActive)
      .sort((a, b) => a.displayOrder - b.displayOrder);
    
    res.json(activeActivities);
  } catch (error) {
    console.error("Error fetching activities:", error);
    res.status(500).json({ message: "Failed to fetch activities" });
  }
});

// Get all activities including inactive (admin)
router.get("/all", requireAdmin, async (req, res) => {
  try {
    const activities = await storage.getActivities();
    const sortedActivities = activities.sort((a, b) => a.displayOrder - b.displayOrder);
    
    res.json(sortedActivities);
  } catch (error) {
    console.error("Error fetching all activities:", error);
    res.status(500).json({ message: "Failed to fetch activities" });
  }
});

// Get single activity
router.get("/:id", async (req, res) => {
  try {
    const activities = await storage.getActivities();
    const activity = activities.find(a => a.id === parseInt(req.params.id));
    
    if (!activity) {
      return res.status(404).json({ message: "Activity not found" });
    }
    
    res.json(activity);
  } catch (error) {
    console.error("Error fetching activity:", error);
    res.status(500).json({ message: "Failed to fetch activity" });
  }
});

// Create activity schema
const createActivitySchema = z.object({
  title: z.string().min(1).max(255),
  description: z.string().min(1),
  category: z.string().min(1).max(100),
  imageUrl: z.string().url().optional().nullable(),
  date: z.string().optional().nullable(),
  link: z.string().optional().nullable(),
  displayOrder: z.number().optional().default(0),
  isActive: z.boolean().optional().default(true),
});

// Create activity (admin)
router.post("/", requireAdmin, async (req, res) => {
  try {
    const validatedData = createActivitySchema.parse(req.body);
    
    const activities = await storage.getActivities();
    const newId = activities.length > 0 ? Math.max(...activities.map(a => a.id)) + 1 : 1;
    
    const newActivity: Activity = {
      id: newId,
      ...validatedData,
      imageUrl: validatedData.imageUrl || null,
      date: validatedData.date || null,
      link: validatedData.link || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: req.user?.id,
      updatedBy: req.user?.id,
    };
    
    activities.push(newActivity);
    await storage.saveActivities(activities);
    
    await logAdminAction(
      req.user!.id,
      "CREATE",
      `Created activity: ${newActivity.title}`,
      "activities",
      String(newActivity.id),
      req
    );
    
    res.json(newActivity);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Invalid data", errors: error.errors });
    }
    console.error("Error creating activity:", error);
    res.status(500).json({ message: "Failed to create activity" });
  }
});

// Update activity schema
const updateActivitySchema = createActivitySchema.partial();

// Update activity (admin)
router.put("/:id", requireAdmin, async (req, res) => {
  try {
    const validatedData = updateActivitySchema.parse(req.body);
    const activityId = parseInt(req.params.id);
    
    const activities = await storage.getActivities();
    const activityIndex = activities.findIndex(a => a.id === activityId);
    
    if (activityIndex === -1) {
      return res.status(404).json({ message: "Activity not found" });
    }
    
    const oldActivity = activities[activityIndex];
    const updatedActivity: Activity = {
      ...oldActivity,
      ...validatedData,
      imageUrl: validatedData.imageUrl !== undefined ? validatedData.imageUrl || null : oldActivity.imageUrl,
      date: validatedData.date !== undefined ? validatedData.date || null : oldActivity.date,
      link: validatedData.link !== undefined ? validatedData.link || null : oldActivity.link,
      updatedAt: new Date().toISOString(),
      updatedBy: req.user?.id,
    };
    
    activities[activityIndex] = updatedActivity;
    await storage.saveActivities(activities);
    
    await logAdminAction(
      req.user!.id,
      "UPDATE",
      `Updated activity: ${updatedActivity.title}`,
      "activities",
      String(activityId),
      req
    );
    
    res.json(updatedActivity);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Invalid data", errors: error.errors });
    }
    console.error("Error updating activity:", error);
    res.status(500).json({ message: "Failed to update activity" });
  }
});

// Delete activity (admin)
router.delete("/:id", requireAdmin, async (req, res) => {
  try {
    const activityId = parseInt(req.params.id);
    
    const activities = await storage.getActivities();
    const activityIndex = activities.findIndex(a => a.id === activityId);
    
    if (activityIndex === -1) {
      return res.status(404).json({ message: "Activity not found" });
    }
    
    const deletedActivity = activities[activityIndex];
    activities.splice(activityIndex, 1);
    await storage.saveActivities(activities);
    
    await logAdminAction(
      req.user!.id,
      "DELETE",
      `Deleted activity: ${deletedActivity.title}`,
      "activities",
      String(activityId),
      req
    );
    
    res.json({ message: "Activity deleted successfully" });
  } catch (error) {
    console.error("Error deleting activity:", error);
    res.status(500).json({ message: "Failed to delete activity" });
  }
});

export default router;