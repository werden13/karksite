import crypto from 'crypto';
import { promisify } from 'util';

const scryptAsync = promisify(crypto.scrypt);

async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const buf = await scryptAsync(password, salt, 64);
  return `${buf.toString('hex')}.${salt}`;
}

async function main() {
  try {
    const password = 'Admin123!';
    const hashedPassword = await hashPassword(password);
    console.log('Hashed password:', hashedPassword);
    
    // Create a user entry that can be copied to users.json
    const user = {
      id: 1,
      username: 'admin',
      password: hashedPassword,
      firstName: 'Admin',
      lastName: 'User',
      email: 'admin@example.com',
      isAdmin: true,
      createdAt: new Date()
    };
    
    console.log('\nUser object for JSON file:');
    console.log(JSON.stringify([user], null, 2));
  } catch (error) {
    console.error('Error:', error);
  }
}

main();