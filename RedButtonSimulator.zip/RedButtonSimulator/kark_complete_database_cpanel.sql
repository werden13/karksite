-- KARK Website Complete MySQL Database Import File for cPanel
-- Version: 2.0
-- Date: 2025-01-27
-- Description: Complete database structure optimized for cPanel hosting environments
-- 
-- INSTRUCTIONS FOR CPANEL IMPORT:
-- 1. Replace 'kark_' with your actual cPanel database prefix (e.g., 'mysite_kark_')
-- 2. Replace database name references if needed
-- 3. Import this file through cPanel phpMyAdmin
-- 4. Update your .env file with the correct MySQL credentials

-- =====================================================
-- CPANEL CONFIGURATION
-- =====================================================
-- Some cPanel providers don't allow CREATE DATABASE, so it's commented out
-- CREATE DATABASE IF NOT EXISTS your_database_name CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE your_database_name;

-- =====================================================
-- DROP EXISTING TABLES (if any)
-- =====================================================

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `kark_sessions`;
DROP TABLE IF EXISTS `kark_admin_logs`;
DROP TABLE IF EXISTS `kark_archive_media`;
DROP TABLE IF EXISTS `kark_archive_items`;
DROP TABLE IF EXISTS `kark_activities`;
DROP TABLE IF EXISTS `kark_hero_sliders`;
DROP TABLE IF EXISTS `kark_donation_campaigns`;
DROP TABLE IF EXISTS `kark_donation_methods`;
DROP TABLE IF EXISTS `kark_settings`;
DROP TABLE IF EXISTS `kark_contact_messages`;
DROP TABLE IF EXISTS `kark_team_members`;
DROP TABLE IF EXISTS `kark_media_items`;
DROP TABLE IF EXISTS `kark_albums`;
DROP TABLE IF EXISTS `kark_events`;
DROP TABLE IF EXISTS `kark_users`;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================
-- TABLE: kark_users
-- =====================================================

CREATE TABLE `kark_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `is_admin` boolean DEFAULT false NOT NULL,
  `role` enum('major_admin','admin','user','banned') DEFAULT 'user' NOT NULL,
  `permissions` json DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_idx` (`username`),
  UNIQUE KEY `email_idx` (`email`),
  KEY `role_idx` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_events
-- =====================================================

CREATE TABLE `kark_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `date` timestamp NOT NULL,
  `location` varchar(255) NOT NULL,
  `category` enum('rescue','training','donation','awareness') NOT NULL,
  `image_path` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_idx` (`category`),
  KEY `date_idx` (`date`),
  KEY `created_by_idx` (`created_by`),
  CONSTRAINT `fk_events_created_by` FOREIGN KEY (`created_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_albums
-- =====================================================

CREATE TABLE `kark_albums` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `cover_image` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by_idx` (`created_by`),
  CONSTRAINT `fk_albums_created_by` FOREIGN KEY (`created_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_media_items
-- =====================================================

CREATE TABLE `kark_media_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `file_path` text NOT NULL,
  `file_type` enum('image','video','document') NOT NULL,
  `file_size` bigint DEFAULT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `album_id` int DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `file_type_idx` (`file_type`),
  KEY `album_id_idx` (`album_id`),
  KEY `created_by_idx` (`created_by`),
  CONSTRAINT `fk_media_album` FOREIGN KEY (`album_id`) REFERENCES `kark_albums` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_media_created_by` FOREIGN KEY (`created_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_team_members
-- =====================================================

CREATE TABLE `kark_team_members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `bio` text,
  `photo` text,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `social_links` json DEFAULT NULL,
  `is_active` boolean DEFAULT true NOT NULL,
  `sort_order` int DEFAULT 0 NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_active_idx` (`is_active`),
  KEY `sort_order_idx` (`sort_order`),
  KEY `created_by_idx` (`created_by`),
  CONSTRAINT `fk_team_created_by` FOREIGN KEY (`created_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_contact_messages
-- =====================================================

CREATE TABLE `kark_contact_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `subject` varchar(500) NOT NULL,
  `message` text NOT NULL,
  `status` enum('unread','read','replied','archived') DEFAULT 'unread' NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `replied_at` timestamp NULL DEFAULT NULL,
  `replied_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status_idx` (`status`),
  KEY `created_at_idx` (`created_at`),
  KEY `replied_by_idx` (`replied_by`),
  CONSTRAINT `fk_contact_replied_by` FOREIGN KEY (`replied_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_settings
-- =====================================================

CREATE TABLE `kark_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text,
  `description` text,
  `type` enum('string','number','boolean','json','text') DEFAULT 'string' NOT NULL,
  `is_public` boolean DEFAULT false NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_idx` (`key`),
  KEY `is_public_idx` (`is_public`),
  KEY `updated_by_idx` (`updated_by`),
  CONSTRAINT `fk_settings_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_donation_methods
-- =====================================================

CREATE TABLE `kark_donation_methods` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` enum('bank','crypto','paypal','other') NOT NULL,
  `details` json NOT NULL,
  `qr_code` text DEFAULT NULL,
  `is_active` boolean DEFAULT true NOT NULL,
  `sort_order` int DEFAULT 0 NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type_idx` (`type`),
  KEY `is_active_idx` (`is_active`),
  KEY `sort_order_idx` (`sort_order`),
  KEY `created_by_idx` (`created_by`),
  KEY `updated_by_idx` (`updated_by`),
  CONSTRAINT `fk_donation_methods_created_by` FOREIGN KEY (`created_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_donation_methods_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_donation_campaigns
-- =====================================================

CREATE TABLE `kark_donation_campaigns` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `goal_amount` decimal(10,2) DEFAULT NULL,
  `raised_amount` decimal(10,2) DEFAULT 0.00 NOT NULL,
  `currency` varchar(10) DEFAULT 'USD' NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `image` text DEFAULT NULL,
  `is_active` boolean DEFAULT true NOT NULL,
  `is_featured` boolean DEFAULT false NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_active_idx` (`is_active`),
  KEY `is_featured_idx` (`is_featured`),
  KEY `start_date_idx` (`start_date`),
  KEY `end_date_idx` (`end_date`),
  KEY `created_by_idx` (`created_by`),
  KEY `updated_by_idx` (`updated_by`),
  CONSTRAINT `fk_campaigns_created_by` FOREIGN KEY (`created_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_campaigns_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_hero_sliders
-- =====================================================

CREATE TABLE `kark_hero_sliders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image_url` text NOT NULL,
  `button_text` varchar(100) DEFAULT NULL,
  `button_link` text DEFAULT NULL,
  `order` int DEFAULT 0 NOT NULL,
  `is_active` boolean DEFAULT true NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_idx` (`order`),
  KEY `is_active_idx` (`is_active`),
  KEY `created_by_idx` (`created_by`),
  KEY `updated_by_idx` (`updated_by`),
  CONSTRAINT `fk_sliders_created_by` FOREIGN KEY (`created_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_sliders_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_activities
-- =====================================================

CREATE TABLE `kark_activities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image_url` text DEFAULT NULL,
  `category` enum('rescue','training','community','awareness','donation') DEFAULT 'community' NOT NULL,
  `date` date DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `is_featured` boolean DEFAULT false NOT NULL,
  `is_active` boolean DEFAULT true NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_idx` (`category`),
  KEY `date_idx` (`date`),
  KEY `is_featured_idx` (`is_featured`),
  KEY `is_active_idx` (`is_active`),
  KEY `created_by_idx` (`created_by`),
  KEY `updated_by_idx` (`updated_by`),
  CONSTRAINT `fk_activities_created_by` FOREIGN KEY (`created_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_activities_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_archive_items
-- =====================================================

CREATE TABLE `kark_archive_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `content` longtext DEFAULT NULL,
  `type` enum('operation','training','event','report','news','media') NOT NULL,
  `date` date NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `image_url` text DEFAULT NULL,
  `attachments` json DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `is_published` boolean DEFAULT true NOT NULL,
  `is_featured` boolean DEFAULT false NOT NULL,
  `views_count` int DEFAULT 0 NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `published_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type_idx` (`type`),
  KEY `date_idx` (`date`),
  KEY `is_published_idx` (`is_published`),
  KEY `is_featured_idx` (`is_featured`),
  KEY `published_at_idx` (`published_at`),
  KEY `created_by_idx` (`created_by`),
  KEY `updated_by_idx` (`updated_by`),
  KEY `published_by_idx` (`published_by`),
  CONSTRAINT `fk_archive_created_by` FOREIGN KEY (`created_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_archive_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_archive_published_by` FOREIGN KEY (`published_by`) REFERENCES `kark_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_archive_media
-- =====================================================

CREATE TABLE `kark_archive_media` (
  `id` int NOT NULL AUTO_INCREMENT,
  `archive_item_id` int NOT NULL,
  `media_url` text NOT NULL,
  `media_type` enum('image','video','document','audio') NOT NULL,
  `caption` text DEFAULT NULL,
  `sort_order` int DEFAULT 0 NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  PRIMARY KEY (`id`),
  KEY `archive_item_id_idx` (`archive_item_id`),
  KEY `media_type_idx` (`media_type`),
  KEY `sort_order_idx` (`sort_order`),
  CONSTRAINT `fk_archive_media_item` FOREIGN KEY (`archive_item_id`) REFERENCES `kark_archive_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_admin_logs
-- =====================================================

CREATE TABLE `kark_admin_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `action` varchar(255) NOT NULL,
  `target_type` varchar(100) DEFAULT NULL,
  `target_id` varchar(100) DEFAULT NULL,
  `details` json DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id_idx` (`user_id`),
  KEY `action_idx` (`action`),
  KEY `target_type_idx` (`target_type`),
  KEY `created_at_idx` (`created_at`),
  CONSTRAINT `fk_admin_logs_user` FOREIGN KEY (`user_id`) REFERENCES `kark_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: kark_sessions (for Express sessions)
-- =====================================================

CREATE TABLE `kark_sessions` (
  `session_id` varchar(128) NOT NULL,
  `expires` int unsigned NOT NULL,
  `data` mediumtext,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- INITIAL DATA INSERTS
-- =====================================================

-- Insert admin users with bcrypt hashed passwords
INSERT INTO `kark_users` (`id`, `username`, `password`, `first_name`, `last_name`, `email`, `is_admin`, `role`, `permissions`, `created_at`) VALUES
(1, 'supermanager', '$2b$10$Yd9ipAccHnu.ezzIDhPk2.byPUq590FDQIq8fmvQrq7zmyUBLIQ/2', 'Super', 'Manager', 'superadmin@kark.org', 1, 'major_admin', '["manage_users", "manage_events", "manage_media", "manage_team", "manage_donations", "manage_settings", "manage_sliders", "manage_admins", "all"]', '2025-01-27 12:00:00'),
(2, 'admin', '$2b$10$nOUIs5kJ7naTuTFkBy1veuK0kSxUFdOXRBpDTW0YTJTpGhMPUKJJy', 'Admin', 'User', 'admin@kark.org', 1, 'admin', '["manage_events", "manage_media", "manage_team", "manage_donations", "manage_settings", "manage_sliders"]', '2025-01-27 12:00:00');

-- Insert default settings
INSERT INTO `kark_settings` (`key`, `value`, `description`, `type`, `is_public`) VALUES
('general.site_name', 'KARK - Kurtarma ve Arama Derneği', 'Website name', 'string', 1),
('general.site_description', 'Kurtarma ve Arama faaliyetleri yürüten dernek', 'Website description', 'text', 1),
('general.footer_text', 'KARK - Kurtarma ve Arama Derneği © 2025', 'Footer text', 'string', 1),
('contact.email', 'info@kark.org', 'Contact email', 'string', 1),
('contact.phone', '+90 555 123 4567', 'Contact phone', 'string', 1),
('contact.address', 'Ankara, Türkiye', 'Contact address', 'text', 1),
('social.facebook', '', 'Facebook URL', 'string', 1),
('social.twitter', '', 'Twitter URL', 'string', 1),
('social.instagram', '', 'Instagram URL', 'string', 1),
('social.youtube', '', 'YouTube URL', 'string', 1);

-- Insert sample hero sliders
INSERT INTO `kark_hero_sliders` (`title`, `description`, `image_url`, `button_text`, `button_link`, `order`, `is_active`, `created_by`) VALUES
('Kurtarma ve Arama Faaliyetleri', 'Profesyonel ekibimizle 7/24 kurtarma operasyonları gerçekleştiriyoruz', 'https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80', 'Hakkımızda', '/about', 1, 1, 1),
('Eğitim Programları', 'Kurtarma teknikleri ve ilk yardım konularında eğitimler düzenliyoruz', 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80', 'Eğitimler', '/training', 2, 1, 1);

-- Insert sample activities
INSERT INTO `kark_activities` (`title`, `description`, `image_url`, `category`, `date`, `location`, `is_featured`, `created_by`) VALUES
('Dağcı Kurtarma Operasyonu', 'Uludağ\'da kaybolan dağcıların başarıyla kurtarılması', 'https://images.unsplash.com/photo-1551524164-6cf2ac531ce4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80', 'rescue', '2025-01-20', 'Uludağ', 1, 1),
('İlk Yardım Eğitimi', 'Gönüllüler için temel ilk yardım eğitimi', 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80', 'training', '2025-01-15', 'Ankara', 0, 1);

-- Insert sample events
INSERT INTO `kark_events` (`title`, `description`, `date`, `location`, `category`, `image_path`, `created_by`) VALUES
('Kış Kurtarma Eğitimi', 'Kış şartlarında kurtarma teknikleri eğitimi', '2025-02-15 09:00:00', 'Kartalkaya', 'training', 'https://images.unsplash.com/photo-1551524164-6cf2ac531ce4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80', 1),
('Bağış Kampanyası', 'Yeni ekipman alımı için bağış kampanyası', '2025-02-01 10:00:00', 'Ankara', 'donation', 'https://images.unsplash.com/photo-1559526324-c1f275fbfa32?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80', 1);

-- =====================================================
-- END OF FILE
-- =====================================================