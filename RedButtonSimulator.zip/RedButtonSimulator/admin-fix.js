// Using the same algorithm as in server/auth.ts
import crypto from 'crypto';
import fs from 'fs/promises';
import path from 'path';

async function hashPassword(password) {
  return new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16).toString('hex');
    crypto.scrypt(password, salt, 64, (err, derivedKey) => {
      if (err) reject(err);
      resolve(`${derivedKey.toString('hex')}.${salt}`);
    });
  });
}

async function main() {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.join(process.cwd(), 'data');
    await fs.mkdir(dataDir, { recursive: true });
    
    // Hash the password using the exact same algorithm as auth.ts
    const hashedPassword = await hashPassword('Admin123!');
    console.log('Hashed password:', hashedPassword);
    
    // Create admin user
    const adminUser = {
      id: 1,
      username: 'admin',
      password: hashedPassword,
      firstName: 'Admin',
      lastName: 'User',
      email: 'admin@example.com',
      isAdmin: true,
      createdAt: new Date()
    };
    
    // Write directly to the users.json file
    const usersPath = path.join(dataDir, 'users.json');
    await fs.writeFile(usersPath, JSON.stringify([adminUser], null, 2));
    
    console.log('Admin user created successfully in users.json');
  } catch (error) {
    console.error('Error:', error);
  }
}

main();